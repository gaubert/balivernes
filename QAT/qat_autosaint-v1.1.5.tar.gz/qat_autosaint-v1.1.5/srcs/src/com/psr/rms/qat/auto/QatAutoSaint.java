/*
 * QatAuto.java
 */

package com.psr.rms.qat.auto;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.psr.rms.db.FileProduct;
import com.psr.rms.db.GardsProduct;
import com.psr.rms.db.PermissionType;
import com.psr.rms.db.Permissions;
import com.psr.rms.db.QatConfig;
import com.psr.rms.db.SampleData;
import com.psr.rms.db.SampleStatus;
import com.psr.rms.db.Station;
import com.psr.rms.db.StatusHistory;
import com.psr.rms.db.UserEnv;

/**
 * Quality Control (QC) Administrative Tool (QAT) that automatically releases
 * samples and products for export after the QC review time periods end. The
 * review times are retrieved from the data store, unless specified as a command
 * line argument.
 * 
 * @author kpagano
 */
public class QatAutoSaint
{
	
	/** QatAuto usage description. */
	private static final String				USAGE			= "Usage: QatAuto -h | -dl | -l <login> [-t <t_time>] [-q <q_time>] [-e <entry_time>]\n"
																	+ "  -h:  help \n"
																	+ "  -dl: default login read from $RMS_HOME/rms.par \n"
																	+ "  -l:  login \n"
																	+ "  -t:  time since date entered to wait before releasing \n"
																	+ "  -q:  time since date reviewed to wait before releasing \n"
																	+ "  -e:  max time since entry date until sample must be released\n"
																	+ "       Defaults to 24 (1 day)\n";
	
	/** Simple Date format used in log. */
	private static final SimpleDateFormat	LOG_DATE_FORMAT	= new SimpleDateFormat(
																	"MM/dd HH:mm:ss");
	
	/** Constant indicating Time not set. */
	public static final float				TIME_NOT_SET	= -1;
	
	/** Time (in hours), since date entered, to wait before releasing. */
	private float							tTime			= TIME_NOT_SET;
	
	/** Time (in hours), since date reviewed, to wait before releasing. */
	private float							qTime			= TIME_NOT_SET;
	
	private String							login			= null;
	
	private String							password		= null;
	
	/**
	 * Time (in hours), since date reviewed, to wait before sample must be
	 * released
	 */
	private float							eTime			= 24;											// 1
	// day
	
	/** Connection to the data store. */
	private Connection						connection		= null;
	
	static private String					SCACBASE_USER			= "analyst";
	static private String					RRRSSREB_USER			= "rms_qat_auto";
	
	/**
	 * Constructor.
	 * 
	 * 
	 */
	public QatAutoSaint()
	{
		
	} // end Constructor
	
	/**
	 * Releases samples (changes status within the data store) that have
	 * exceeded the specified review times.
	 * 
	 * @param connection
	 *            database connection
	 * @param qTime
	 *            gards_qat_config q_time
	 * @param tTime
	 *            gards_qat_config t_time
	 * @param eTime
	 *            entry time threshold
	 * 
	 */
	public void releaseSamples(Connection connection, float qTime, float tTime,
			float eTime)
	{
		
		/* log times (indicates execution start time) */
		System.out.println();
		System.out.println("Qat Auto Startup   "
				+ LOG_DATE_FORMAT.format(Calendar.getInstance().getTime())
				+ "   " + " q_time: " + qTime + "   t_time: " + tTime
				+ "   e_time: " + eTime);
		
		/* log times (indicates execution start time) */
		System.out.println("SID:"
				+ com.psr.rms.table.TextSpacer.getChars(6, ' ') + "ENTRY:"
				+ com.psr.rms.table.TextSpacer.getChars(10, ' ') + "REVIEW:"
				+ com.psr.rms.table.TextSpacer.getChars(9, ' ') + "CAT:"
				+ com.psr.rms.table.TextSpacer.getChars(1, ' ') + "STAT:"
				+ com.psr.rms.table.TextSpacer.getChars(1, ' ') + "RRR:");
		
		/* samples with a T status and have exceeded tTime */
		List tReleaseSamples = QatConfig.getSamplesForTRelease(connection, tTime);
		
		int numTReleaseSamples = tReleaseSamples.size();
		
		/* for each sample to be released */

		for (int tIndex = 0; tIndex < numTReleaseSamples; tIndex++)
		{
			
			int sampleID = ((Integer) tReleaseSamples.get(tIndex)).intValue();
			releaseSample(connection, sampleID);
			
		}
		
		/* samples with a Q status and have exceeded qTime */
		List qReleaseSamples = QatConfig.getSamplesForQRelease(connection,qTime);
		
		int numQReleaseSamples = qReleaseSamples.size();
		
		/* for each sample to be released */
		for (int qIndex = 0; qIndex < numQReleaseSamples; qIndex++)
		{
			
			int sampleID = ((Integer) qReleaseSamples.get(qIndex)).intValue();
			releaseSample(connection, sampleID);
			
		}
		
		/* samples with a Q or T status and have exceeded 1 day */

		List samplesForQorT1DayRelease = QatConfig
				.getSamplesForQorT1DayRelease(connection, eTime);
		
		int numSamplesForQorT1DayRelease = samplesForQorT1DayRelease.size();
		
		/* for each sample to be released */
		for (int index = 0; index < numSamplesForQorT1DayRelease; index++)
		{
			int sampleID = ((Integer) samplesForQorT1DayRelease.get(index))
					.intValue();
			releaseSample(connection, sampleID);
		}
		
		/* log execution finish time */
		System.out.println("Qat Auto End.  "
				+ LOG_DATE_FORMAT.format(Calendar.getInstance().getTime()));
		
		System.out.println();
		System.out.println();
	}
	
	private void printTableMessage(int sampleID, SampleStatus sampleStatus,
			String filename, String oldStatus)
	{
		
		/* retrieve release date and entry date */
		Calendar entryDate = sampleStatus.getEntryDate();
		
		// Create SID format 10 chars
		DecimalFormat df = new DecimalFormat();
		df.setGroupingUsed(false);
		FieldPosition fp = new FieldPosition(NumberFormat.INTEGER_FIELD);
		StringBuffer sidBudffer = new StringBuffer();
		sidBudffer = df.format(sampleID, sidBudffer, fp);
		int numSpaces = 10 - fp.getEndIndex();
		
		sidBudffer
				.append(com.psr.rms.table.TextSpacer.getChars(numSpaces, ' '));
		
		System.out.println(sidBudffer
				+ LOG_DATE_FORMAT.format(entryDate.getTime())
				+ com.psr.rms.table.TextSpacer.getChars(2, ' ')
				+ LOG_DATE_FORMAT
						.format(sampleStatus.getReviewDate().getTime())
				+ com.psr.rms.table.TextSpacer.getChars(2, ' ')
				+ sampleStatus.getCategory()
				+ com.psr.rms.table.TextSpacer.getChars(4, ' ') + oldStatus
				+ com.psr.rms.table.TextSpacer.getChars(5, ' ')
				+ ((filename == null) ? "" : filename));
	}
	
	/**
	 * Release SCAC and Baseline if necessary
	 * 
	 * @param connection
	 * @param sampleID
	 * @param sampleStatus
	 * @param cleaner cleaner pass the cleaning object which will be populated
	 * @return
	 * @throws Exception
	 */
	private void releaseAutoSaintProducts(Connection connection, int sampleID,
			SampleStatus sampleStatus, String oldStatus, QatCleaner cleaner) throws Exception
	{
		File outputFile = null;
		
		int typeID;
		
		// Insert SCAC and BASELINE file in the FILEPRODUCT Table if necessary
		SimpleDateFormat sdf = new SimpleDateFormat("yy_MMM_dd");
		Calendar today = Calendar.getInstance();
		String date = sdf.format(today.getTime()).toLowerCase();
		
		String separator = System.getProperty("file.separator");
		
		// String errorString = "Error finding RRR typeID. ";
		
		/* new location of file */
		UserEnv userEnv = new UserEnv(connection);
		Properties props = userEnv.getUserEnv();
		String rmsHome = props.getProperty("RMS_HOME");
		String scacDir = props.getProperty("RMS_SCAC_DIR");
		String baselineDir = props.getProperty("RMS_BASE_DIR");
		
		SampleData sampleData = new SampleData(connection, sampleID);
		
		Station station = new Station(connection, sampleData.getStationId());
		
		Calendar cstart = sampleData.getCollectStart();
		Calendar cstop = sampleData.getCollectStop();
		
		/* Deal with BASELINE products */
		GardsProduct gardsProduct = GardsProduct.open(connection, sampleID,
				GardsProduct.BASELINE);
		
		if (gardsProduct != null)
		{
			// we have found a product so now the path needs to be check to see
			// if the file hasn't been reprocessed
			String dir = gardsProduct.getDirectory();
			// if the dir is different from RMS_BASELINE_DIR then it needs to be
			// moved
			if (!dir.equalsIgnoreCase(baselineDir))
			{
				// need to update file product
				String filename = gardsProduct.getFile();
				
				StringBuffer fileproductFilename = new StringBuffer(rmsHome);
				
				// create final path
				fileproductFilename.append(separator);
				fileproductFilename.append(baselineDir);
				fileproductFilename.append(separator);
				fileproductFilename.append(date);
				fileproductFilename.append(separator);
				
				String logicalPath = FileProduct
						.getLogicalFilename(fileproductFilename.toString());
				
				/* copy file */
				File inputFile = new File(dir + separator + filename);
				File outputDir = new File(logicalPath);
				outputFile = new File(logicalPath + filename);
				if (!outputDir.exists())
				{
					outputDir.mkdirs(); // create output dir
				}
				if (!outputFile.exists())
				{
					outputFile.createNewFile(); // create output file
				}
				
				copyFile(inputFile, outputFile);
				
				/* insert entry into file products */

				// errorString =
				// "Error inserting BASELINE into FileProduct table. ";
				typeID = FileProduct.findTypeId(connection,
						FileProduct.BASELINE);
				
				FileProduct.insertFileName(connection, typeID, logicalPath,
						filename, 0, (int) inputFile.length(), station
								.getStationCode(), SCACBASE_USER, 2, 1, cstart
								.getTime().getTime() / 1000, cstop.getTime()
								.getTime() / 1000, Integer.toString(sampleID),
						0);
				
				printTableMessage(sampleID, sampleStatus, filename, oldStatus);
				
				cleaner.addReportToClean(sampleID, typeID, inputFile);
				
			}
			else
			{
				System.out
						.println("No need to add BASELINE product for sample "
								+ sampleID);
			}
		}
		else
		{
			System.out
					.println("...No Baseline Found in GARDS_PRODUCT for sample "
							+ sampleID);
		}
		
		// look for SCAC
		/* Deal with SCAC products */
		gardsProduct = GardsProduct.open(connection, sampleID,
				GardsProduct.SCAC);
		
		if (gardsProduct != null)
		{
			// we have found a product so now the path needs to be check to see
			// if the file hasn't been reprocessed
			String dir = gardsProduct.getDirectory();
			// if the dir is different from RMS_SCAC_DIR then it needs to be
			// moved
			if (!dir.equalsIgnoreCase(scacDir))
			{
				// need to update file product
				String filename = gardsProduct.getFile();
				
				StringBuffer fileproductFilename = new StringBuffer(rmsHome);
				
				// create final path
				fileproductFilename.append(separator);
				fileproductFilename.append(scacDir);
				fileproductFilename.append(separator);
				fileproductFilename.append(date);
				fileproductFilename.append(separator);
				
				String logicalPath = FileProduct
						.getLogicalFilename(fileproductFilename.toString());
				
				/* copy file */
				File inputFile = new File(dir + separator + filename);
				File outputDir = new File(logicalPath);
				outputFile = new File(logicalPath + filename);
				if (!outputDir.exists())
				{
					outputDir.mkdirs(); // create output dir
				}
				if (!outputFile.exists())
				{
					outputFile.createNewFile(); // create output file
				}
				
				copyFile(inputFile, outputFile);
				
				/* insert entry into file products */

				// errorString =
				// "Error inserting SCAC file into FileProduct table. ";
				typeID = FileProduct.findTypeId(connection, FileProduct.SCAC);
				
				FileProduct.insertFileName(connection, typeID, logicalPath,
						filename, 0, (int) inputFile.length(), station
								.getStationCode(), SCACBASE_USER, 2, 1, cstart
								.getTime().getTime() / 1000, cstop.getTime()
								.getTime() / 1000, Integer.toString(sampleID),
						0);
				
				printTableMessage(sampleID, sampleStatus, filename, oldStatus);
				
				cleaner.addReportToClean(sampleID, typeID, inputFile);
			}
			else
			{
				System.out.println("No need to add SCAC product for sample "
						+ sampleID);
			}
		}
		else
		{
			System.out.println("...No SCAC Found in GARDS_PRODUCT for sample "
					+ sampleID);
		}
	}
	
	/**
	 * Release RRR and SSREB files if there are any.
	 * 
	 * @param connection
	 * @param sampleID
	 * @param sampleStatus
	 * @param cleaner pass the cleaning object which will be populated
	 * @return
	 * @throws Exception
	 */
	private void releaseRRR(Connection connection, int sampleID,
			SampleStatus sampleStatus, String oldStatus, QatCleaner cleaner) throws Exception
	{
		/* copy file to appropriate directory and insert entry in file products */
		String input = "INPUT FILE";
		String output = "OUTPUT FILE";
		
		File rrrOutputFile = null;
		int typeID;
		
		// Insert RRR and SSREB into fileproduct table
		SimpleDateFormat sdf = new SimpleDateFormat("yy_MMM_dd");
		Calendar today = Calendar.getInstance();
		String date = sdf.format(today.getTime()).toLowerCase();
		String separator = System.getProperty("file.separator");
		
		typeID = FileProduct.findTypeId(connection, FileProduct.RRR_REPORT);
		
		/* new location of file */
		UserEnv userEnv    = new UserEnv(connection);
		Properties props   = userEnv.getUserEnv();
		String rmsHome     = props.getProperty("RMS_HOME");
		String rmsRRRDir   = props.getProperty("RMS_RRR_DIR");
		String rmsSSREBDir = props.getProperty("RMS_SSREB_DIR");
		
		SampleData sampleData = new SampleData(connection, sampleID);
		
		Station station = new Station(connection, sampleData.getStationId());
		
		Calendar cstart = sampleData.getCollectStart();
		Calendar cstop = sampleData.getCollectStop();
		
		/* current location of file */
		GardsProduct gardsProduct = GardsProduct.open(connection, sampleID,GardsProduct.RRR_REPORT);
		
		if (gardsProduct == null)
		{
			System.out.println("...RRR Not Found in GARDS_PRODUCT for sample " + sampleID + ". Do nothing");
			throw new NoErrorException("...RRR Not Found in GARDS_PRODUCT for sample " + sampleID);
		}
		
		String filename = gardsProduct.getFile();
		String path = gardsProduct.getDirectory();
		
		StringBuffer fileproductFilename = new StringBuffer(rmsHome);
		
		fileproductFilename.append(separator);
		fileproductFilename.append(rmsRRRDir);
		fileproductFilename.append(separator);
		fileproductFilename.append(date);
		fileproductFilename.append(separator);
		String logicalPath = FileProduct.getLogicalFilename(fileproductFilename
				.toString());
		input = path + separator + filename;
		output = logicalPath + filename;
		
		/* copy file */
		File inputFile = new File(input);
		File outputDir = new File(logicalPath);
		rrrOutputFile = new File(output);
		if (!outputDir.exists())
		{
			outputDir.mkdirs(); // create output dir
		}
		if (!rrrOutputFile.exists())
		{
			rrrOutputFile.createNewFile(); // create output file
		}
		
		copyFile(inputFile, rrrOutputFile);
		
		/* insert entry into file products */
		FileProduct.insertFileName(connection, typeID, logicalPath, filename,
				0, (int) inputFile.length(), station.getStationCode(), RRRSSREB_USER,
				1, 1, cstart.getTime().getTime() / 1000, cstop.getTime()
						.getTime() / 1000, Integer.toString(sampleID), 0);
		
		printTableMessage(sampleID, sampleStatus, filename, oldStatus);
		
		// add RRR in cleaner
		cleaner.addReportToClean(sampleID, typeID, inputFile);
		
		/* SSREB */

		// If level >=4 then copy SSREB. In some cases there may be an
		// SSREB,
		// but the Category <4. This can happen when an analyst re-reviews
		// a sample that was originally released with level 4 or 5, but is
		// later released with a 1,2, or 3. The point is that you must check
		// the level instead of blindly copying GardsProduct to fileproduct
		if (sampleStatus.getCategory() >= 4)
		{
			
			/* IDC added May 2003: get typeID of SSREB_REPORT (two lines) */
			typeID = FileProduct.findTypeId(connection,
					FileProduct.SSREB_REPORT);
			
			/* current location of file */
			gardsProduct = GardsProduct.open(connection, sampleID,
					GardsProduct.SSREB_REPORT);
			
			if (gardsProduct != null)
			{
				filename = gardsProduct.getFile();
				path = gardsProduct.getDirectory();
				
				fileproductFilename = new StringBuffer(rmsHome);
				
				fileproductFilename.append(separator);
				fileproductFilename.append(rmsSSREBDir);
				fileproductFilename.append(separator);
				fileproductFilename.append(date);
				fileproductFilename.append(separator);
				logicalPath = FileProduct
						.getLogicalFilename(fileproductFilename.toString());
				input = path + separator + filename;
				output = logicalPath + filename;
				
				/* copy file */
				inputFile = new File(input);
				outputDir = new File(logicalPath);
				File ssrebOutputFile = new File(output);
				if (!outputDir.exists())
				{
					outputDir.mkdirs(); // create output dir
				}
				if (!ssrebOutputFile.exists())
				{
					ssrebOutputFile.createNewFile(); // create output file
				}
				
				copyFile(inputFile, ssrebOutputFile);
				
				/* insert entry into file products */
				FileProduct.insertFileName(connection, typeID, logicalPath,
						filename, 0, (int) inputFile.length(), station
								.getStationCode(), RRRSSREB_USER, 1, 1, cstart
								.getTime().getTime() / 1000, cstop.getTime()
								.getTime() / 1000, Integer.toString(sampleID),
						0);
			
				printTableMessage(sampleID, sampleStatus, filename, oldStatus);
				
				cleaner.addReportToClean(sampleID, typeID, inputFile);
			}
		}
	}
	
	/*
	 * Releases the given sample. The release entails the following: update the
	 * sample status to R, updates the release date, insert entry in history,
	 * insert entry in file products, and logs (outputs) a message.
	 * 
	 * @param connection database connection
	 * 
	 * @param sample ID of the sample to be released.
	 */
	private void releaseSample(Connection connection, int sampleID)
	{
		/* save old status (before updating) */
		SampleStatus sampleStatus = new SampleStatus(connection, sampleID);
		String oldStatus          = sampleStatus.getStatus();
		// create cleaning object
		QatCleaner cleaner        = new QatCleaner(connection);
		
		try
		{
			// remove auto commit to run in a transaction
			connection.setAutoCommit(false);
			
			releaseRRR(connection, sampleID, sampleStatus, oldStatus,cleaner);
			releaseAutoSaintProducts(connection, sampleID, sampleStatus,oldStatus,cleaner);
			
			/* update status to Released and update the release date */
			SampleStatus.updateStatusToReleased(connection, sampleID);
			
			/* insert entry in history */
			StatusHistory.insertStatusUpdate(connection, sampleID, "qat_auto",oldStatus, SampleStatus.RELEASED);
			
			connection.commit();
			
			/* clean the database for this sample */
			cleaner.clean();
			
			/* commit if no error */
			connection.commit();
			
		}
		catch (Exception e)
		{
			if (e instanceof NoErrorException)
			{
			  System.out.println(e.getMessage());
			}
			else
			{
			  System.out.println("Error: RRR not added to FileProduct for " + sampleID + "\n Exception message: " + e.getMessage());
			  e.printStackTrace(System.out);
			}
			
			// roll back transaction
			if (connection != null)
			{
				try
				{
					System.err.print("Transaction is being rolled back");
					connection.rollback();
				}
				catch (SQLException excep)
				{
					System.err.print("SQLException: ");
					System.err.println(excep.getMessage());
				}
			}
		}
	} // end releaseSample
	
	/**
	 * copy file character at a time.
	 */
	public static void copyFile(File src, File dst) throws IOException
	{
		
		InputStream in = new FileInputStream(src);
		OutputStream out = new FileOutputStream(dst);
		
		// Transfer bytes from in to out
		byte[] buf = new byte[2 * 1024];
		int len;
		while ((len = in.read(buf)) > 0)
		{
			out.write(buf, 0, len);
		}
		in.close();
		out.close();
	}
	
	/**
	 * static public method for creating an Oracle JDBC Connection (as it was
	 * defined previously. This is most probably not a clean way)
	 * 
	 * @param aUser
	 *            login
	 * @param aPassword
	 *            password
	 * @return a DB Connection
	 * @throws Exception
	 */
	public static Connection createDBConnection(String aUser, String aPassword)
			throws Exception
	{
		String portString = null;
		String twoTask = null;
		String sid = null;
		String subProtocol = null;
		
		String useServiceName = null;
		String serviceName = null;
		String connectString = null;
		
		Connection connection;
		int port;
		
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		
		twoTask = System.getProperty("TWO_TASK", null);
		
		if (twoTask == null)
		{
			System.out.println("need to set TWO_TASK with -DTWO_TASK=...");
			return null;
		}
		
		sid = System.getProperty("ORACLE_SID", "oracle");
		
		portString = System.getProperty("ORACLE_PORT", "1521");
		
		port = Integer.parseInt(portString);
		
		subProtocol = System.getProperty("PROTOCOL", "oracle:thin");
		
		useServiceName = System.getProperty("USE_ORACLE_SERVICE_NAME", "no");
		
		serviceName = System.getProperty("ORACLE_SERVICE_NAME", null);
		
		if ((useServiceName.equalsIgnoreCase("yes") || useServiceName
				.equalsIgnoreCase("true"))
				&& (serviceName != null))
		{
			// Try to connect with a service name
			connectString = "jdbc:" + subProtocol
					+ ":@(description=(address=(host=" + twoTask
					+ ")(protocol=tcp)(port=" + port
					+ "))(connect_data=(service_name=" + serviceName + ")))";
			
		}
		else
		{
			// USE of method SID
			connectString = "jdbc:" + subProtocol
					+ ":@(description=(address=(host=" + twoTask
					+ ")(protocol=tcp)(port=" + port + "))(connect_data=(sid="
					+ sid + ")))";
		}
		
		try
		{
			
			System.out.println("Try to to login with user (" + aUser
					+ ") and the following JDBC string connection :"
					+ connectString);
			
			connection = DriverManager.getConnection(connectString, aUser,
					aPassword);
			
		}
		catch (java.sql.SQLException e)
		{
			e.printStackTrace(System.err);
			throw new Exception("Error getting DB connection:" + e.getMessage());
			
		}
		
		return connection;
	}
	
	public void run() throws Exception
	{
		this.connection = createDBConnection(this.login, this.password);
		
		// handle to the Qat Config data
		QatConfig qatConfig = new QatConfig(connection);
		
		// if Do Not automatically release samples
		if (!qatConfig.allowRelease())
		{
			System.out.println("QatAuto is not being run.");
			throw new Exception("QatAuto is not being run.");
		}
		
		// retrieve username
		String username = "";
		
		try
		{
			username = connection.getMetaData().getUserName();
		}
		catch (java.sql.SQLException e)
		{
			e.printStackTrace(System.err);
			throw new Exception("Unable to retrieve username from connection."
					+ e.getMessage());
		}
		
		boolean roQatPermissions = Permissions.checkIfUserHasPermission(
				connection, username.toLowerCase(), PermissionType.RO_qat);
		// NOTE: The username in the meta-data is returned in all caps,
		// this made the checkIfUserHasPermission query fail, thus
		// the conversion to lower case.
		
		// if T time was not set or user doesn't have RO-QAT permissions
		if ((tTime == TIME_NOT_SET) || !roQatPermissions)
		{
			// retrieve the value from the data store
			tTime = qatConfig.getTTime();
		}
		// if Q time was not set or user doesn't have RO-QAT permissions
		if ((qTime == TIME_NOT_SET) || !roQatPermissions)
		{
			// retrieve the value from the data store
			qTime = qatConfig.getQTime();
		}
		
		releaseSamples(connection, qTime, tTime, eTime);
		
	}
	
	private static Map readInfoFromParFile()
	{
		Properties p = new Properties();
		String rmsParFilename = System.getProperty("RMS_PAR", null);
		
		String user = null;
		String password = null;
		
		if (rmsParFilename == null)
		{
			throw new IllegalArgumentException(
					"Need -DRMS_PAR=<par file> as  command line option for par file");
		}
		try
		{
			
			p.load(new FileInputStream(rmsParFilename));
			
			if ((user = p.getProperty("RMS_USER", null)) == null)
			{
				throw new IllegalArgumentException(
						"Error. No RMS_USER defined in par file "
								+ rmsParFilename);
			}
			
			if ((password = p.getProperty("RMS_USER_PASS", null)) == null)
			{
				throw new IllegalArgumentException(
						"Error. No RMS_USER_PASS defined in par file "
								+ rmsParFilename);
			}
			
			Map m = new HashMap();
			
			m.put("user", user);
			m.put("password", password);
			
			return m;
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace(System.out);
			
			throw new IllegalArgumentException("Error reading par file: "
					+ rmsParFilename);
		}
	}
	
	/**
	 * parse commandline args and build and return the QAT object
	 * 
	 * @param args
	 *            Command line arguments. Usage: QatAuto -h | -dl | -l <login>
	 *            [-t <t_time>] [-q <q_time>] [-e <e_time>] where -h indicates
	 *            help, -dl indicates the data store's username and password are
	 *            read from rms.par, (this should be used for cron jobs) -l
	 *            indicates the given login should be used, -t indicates the
	 *            sample should be released after the given amount time (in
	 *            hours ) from the date entered, -q indicates the sample should
	 *            be released after the given amount time (in hours) from the
	 *            last date reviewed -e indicates number of hours sample must be
	 *            released after entry time NOTE: Either -h or -dl or -l must be
	 *            specified.
	 * @return
	 */
	public static QatAutoSaint parseArguments(String args[])
	{
		float tTime = TIME_NOT_SET;
		float qTime = TIME_NOT_SET;
		float eTime = 24; // 1 day
		
		String user        = null;
		String password    = null;
		boolean dlOption   = false;
		boolean lOption    = false;
		
		// create QatAuto Object
		QatAutoSaint qat = new QatAutoSaint();
		
		/* read command line arguments */
		for (int index = 0; index < args.length; index++)
		{
			
			//System.out.println("args["+index+"]=["+args[index]+"]");
			
			/* -h option */
			if (args[index].trim().equals("-h"))
			{
				System.out.println(USAGE);
				System.exit(0);
			}
			/* -l option */
			else if (args[index].trim().equals("-l"))
			{
				/* See if user entered username/password on command line */
				if (index < args.length - 1)
				{
					String tempName = args[index + 1];
					
					int indexSeparator = tempName.indexOf('/');
					if (indexSeparator != -1)
					{
						user     = tempName.substring(0, indexSeparator);
						password = tempName.substring(indexSeparator + 1,tempName.length());
					}
					else
					{
						user = tempName;
					}
					
					lOption = true;
				}
				else
				{
					throw new IllegalArgumentException(
							"Error. -l option needs username/password");
				}
			}
			/* -l option */
			else if (args[index].trim().equals("-dl"))
			{
				
				Map m = readInfoFromParFile();
				
				user     = (String) m.get("user");
				password = (String) m.get("password");
				
				dlOption = true;	
			}
			/* -t option */
			else if (args[index].trim().equals("-t"))
			{
				/* if a value was specified */
				if ((index + 1) < args.length)
				{
					if (!(args[index + 1].toString().startsWith("-")))
					{
						/*
						 * increment index to avoid having the value of -t
						 * processed in the for loop logic
						 */
						index++;
						/* retrieve value of -t */
						tTime = new Float(args[index]).floatValue();
					}
					else
					{
						System.out
								.println("A time (in hours) must be specified with the -t option.");
						System.out
								.println("The report will be based on the default value of t_time.");
					}
				}
				else
				{
					System.out
							.println("A time (in hours) must be specified with the -t option.");
					System.out
							.println("The report will be based on the default value of t_time.");
				} // end if a value was specified
			}
			/* -q option */
			else if (args[index].trim().equals("-q"))
			{
				/* if a value was specified */
				if ((index + 1) < args.length)
				{
					if (!(args[index + 1].toString().startsWith("-")))
					{
						/*
						 * increment index to avoid having the value of -q
						 * processed in the for loop logic
						 */
						index++;
						/* retrieve value of -q */
						qTime = new Float(args[index]).floatValue();
					}
					else
					{
						System.out
								.println("A time (in hours) must be specified with the -q option.");
						System.out
								.println("The report will be based on the default value of q_time.");
					}
				}
				else
				{
					System.out
							.println("A time (in hours) must be specified with the -q option.");
					System.out
							.println("The report will be based on the default value of q_time.");
				} // end if a value was specified
			}
			
			/* -e option */
			else if (args[index].trim().equals("-e"))
			{
				
				if ((index + 1) < args.length)
				{
					if (!(args[index + 1].toString().startsWith("-")))
					{
						/*
						 * increment index to avoid having the value of -e
						 * processed in the for loop logic
						 */
						index++;
						/* retrieve value of -e */
						eTime = new Float(args[index]).floatValue();
					}
					else
					{
						System.out
								.println("A time (in hours) must be specified with the -e option.");
						System.out
								.println("The report will be based on the default value of 1 day.");
					}
				}
				else
				{
					System.out
							.println("A time (in hours) must be specified with the -e option.");
					System.out
							.println("The report will be based on the default value of 1 day.");
				} // end if a value was specified
			}
			
		} // end for each command line argument
		
		if ( (dlOption == false) && (lOption == false))
		{
		   // If no -dl and no -l passed then try to read info from the par file
		   System.out.println("Parsing Arguments: No -dl or -l options given. Try to read the user password from the PAR file.\n");
		   Map m = readInfoFromParFile();
		
		   user = (String) m.get("user");
		   password = (String) m.get("password");
		}
		
		// set qat object attributes
		// needs to be set at this stage
		qat.setLogin(user);
		qat.setPassword(password);
		
		// optional
		qat.setETime(eTime);
		qat.setQTime(qTime);
		qat.setTTime(tTime);
		
		return qat;
		
	}
	
	/**
	 * Main method of the Application.
	 * 
	 */
	public static void main(String args[])
	{
		try
		{
			QatAutoSaint qat = parseArguments(args);
			qat.run();
		}
		catch (IllegalArgumentException parsingError)
		{
			System.out.println("Error when parsing command line");
			System.out.println(parsingError.getMessage());
			
			System.out.println(USAGE);
			
			System.exit(-1);
		}
		catch (Throwable e)
		{
			System.out.println("Error:");
			e.printStackTrace(System.out);
			
			System.exit(-2);
		}
		
		System.exit(0);
	}
	
	public float getTTime()
	{
		return tTime;
	}
	
	public void setTTime(float time)
	{
		tTime = time;
	}
	
	public float getQTime()
	{
		return qTime;
	}
	
	public void setQTime(float time)
	{
		qTime = time;
	}
	
	public String getLogin()
	{
		return login;
	}
	
	public void setLogin(String login)
	{
		this.login = login;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	public void setPassword(String password)
	{
		this.password = password;
	}
	
	public float getETime()
	{
		return eTime;
	}
	
	public void setETime(float time)
	{
		eTime = time;
	}
	
	public Connection getConnection()
	{
		return connection;
	}
	
	public void setConnection(Connection connection)
	{
		this.connection = connection;
	}
	
}
