package com.psr.rms.db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NuclIded {

  double activDecay;
  double activDecayErr;
  double activKey;
  double activKeyErr;
  double aveActiv;
  double aveActivErr;
  double compConfid;
  double mda;
  double mdaErr;

  int detectorId;
  int nidFlag;
  int pdModFlag;
  int reportMda;
  int sampleId;
  int stationId;

  String halflife;
  String name;
  String type;

  public NuclIded(int sid, int stid, int dtid, String n, String t, String hl,
                  double aa, double aae, double ak, double ake, double m,
                  double me, int nid, double ad, double ade, double cc,
                  int rmda, int pmf) {

    sampleId      = sid;
    stationId     = stid;
    detectorId    = dtid;
    name          = n;
    type          = t;
    halflife      = hl;
    aveActiv      = aa;
    aveActivErr   = aae;
    activKey      = ak;
    activKeyErr   = ake;
    mda           = m;
    mdaErr        = me;
    nidFlag       = nid;
    activDecay    = ad;
    activDecayErr = ade;
    compConfid    = cc;
    reportMda     = rmda;
    pdModFlag     = pmf;

  }


  public static List getNuclIdedForSample(Connection conn, int sid) {

    List returnList = new ArrayList();

    try {

      String query =
        "SELECT station_id, detector_id, name, type, halflife, ave_activ, " +
               "ave_activ_err, activ_key, activ_key_err, mda, mda_err, " +
               "nid_flag, activ_decay, activ_decay_err, comp_confid, " +
               "report_mda, pd_mod_flag " +
        "FROM gards_nucl_ided " +
        "WHERE sample_id = " + sid;

      Statement stmt = conn.createStatement();
      ResultSet rs   = stmt.executeQuery(query);

      while (rs.next()) {

        int stid  = rs.getInt(1);
        int dtid  = rs.getInt(2);
        String n  = rs.getString(3);
        String t  = rs.getString(4);
        String hl = rs.getString(5);
        double aa = rs.getDouble(6);
        double aae = rs.getDouble(7);
        double ak  = rs.getDouble(8);
        double ake = rs.getDouble(9);
        double m   = rs.getDouble(10);
        double me  = rs.getDouble(11);
        int nid    = rs.getInt(12);
        double ad  = rs.getDouble(13);
        double ade = rs.getDouble(14);
        double cc  = rs.getDouble(15);
        int rmda   = rs.getInt(16);
        int pmf    = rs.getInt(17);

        NuclIded curNI = new NuclIded(sid, stid, dtid, n, t, hl, aa, aae, ak,
                                      ake, m, me, nid, ad, ade, cc, rmda,
                                      pmf);

        returnList.add(curNI);

      }

      rs.close();
      stmt.close();

    } catch (SQLException e) {

      System.out.println("Error getting NuclIded for sample.");
      System.out.println("Exception = " + e + ".");

    }

    return returnList;

  }


  public double getActivDecay() {

    return activDecay;

  }


  public double getActivDecayErr() {

    return activDecayErr;

  }


  public double getActivKey() {

    return activKey;

  }

 
  public double getActivKeyErr() {

    return activKeyErr;

  }


  public double getAveActiv() {

    return aveActiv;

  }


  public double getAveActivErr() {

    return aveActivErr;

  }

  
  public double getCompConfid() {

    return compConfid;

  }

 
  public double getMda() {

    return mda;

  }


  public double getMdaErr() {

    return mdaErr;

  }


  public int getDetectorId() {

    return detectorId;

  }


  public int getNidFlag() {

    return nidFlag;

  }

 
  public int getPdModFlag() {

    return pdModFlag;

  }


  public int getReportMda() {

    return reportMda;

  }


  public int getSampleId() {

    return sampleId;

  }


  public int getStationId() {

    return stationId;

  }


  public String getHalflife() {

    return halflife;

  }


  public String getName() {

    return name;

  }


  public String getType() {

    return type;

  }

}
