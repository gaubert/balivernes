/*
 * SampleCat.java
 */

package com.psr.rms.db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 * This class wraps GARDS_SAMPLE_CAT.  This table records the results of
 * categorization, including the bounds, by station_id and nuclide name.
 *
 * @author  Joshua Holmes
 * @version 1.0
 * @since   RMS4.0
 */
public class SampleCat { 

  private double activity;
  private double centralValue;
  private double delta;
  private double lowerBound;
  private double upperBound;
  private int category;
  private int hold;
  private int sampleId;
  private String name;

  public static final String ACTIVATION   = "ACTIVATION";
  public static final String COSMIC       = "COSMIC";
  public static final String FISSION      = "FISSION (P)";
  public static final String FISSION_GAS  = "FISSION (G)";
  public static final String FISSION_BOTH = "FISSION (P\\G)";
  public static final String NATURAL      = "NATURAL";

  /**
   * Creates a SampleCat by specifying all the fields
   *
   * @param sid id of the sample
   * @param nucl name of the nuclide
   * @param cat category of the nuclide
   * @param up upper bound of permissible activity
   * @param low lower bound of permissible activity
   * @param cent central value of the activity
   * @param del delta factor in EWMA calculations
   * @param activ activity
   * @param hold hold value
   */
  public SampleCat(int sid, String nucl, int cat, double up, double low,
                   double cent, double del, double activ, int hold) {

    sampleId     = sid;
    name         = nucl;
    category     = cat;
    upperBound   = up;
    lowerBound   = low;
    centralValue = cent;
    delta        = del;
    activity     = activ;
    hold         = hold;

  } 
  

  public SampleCat(Connection conn, int sid, String nucl) {

    try {

      String query =
        "SELECT category, upper_bound, lower_bound, central_value, " +
               "delta, activity, hold " +
        "FROM gards_sample_cat " +
        "WHERE sample_id = " + sid + " " +
        "AND   name = '" + nucl + "'";

      Statement stmt = conn.createStatement();
      ResultSet rs   = stmt.executeQuery(query);

      while (rs.next()) {

        sampleId     = sid;
        name         = nucl;
        category     = rs.getInt(1);
        upperBound   = rs.getDouble(2);
        lowerBound   = rs.getDouble(3);
        centralValue = rs.getDouble(4);
        delta        = rs.getDouble(5);
        activity     = rs.getDouble(6);
        hold         = rs.getInt(7);

      }
  
      rs.close();
      stmt.close();

    } catch (SQLException e) {

      System.out.println("Failure to load values into SampleCat");
      System.out.println("Exception = " + e);

    }

  }
  

  /**
   * Gets all SampleCats for a particular sample
   *
   * @param conn the connection to the database
   * @param sampleId value used to compare in the sql where statement
   *
   * @return List the list of SampleCats read in
   */
  public static List readSampleCats(Connection conn, int sampleId) {

    double act;
    double cv;
    double del;
    double lBound;
    double uBound;
    int cat;
    int hold;
    String nucl;

    java.util.List list = new ArrayList();
    
    try {

      String queryString =
        "SELECT name, category, upper_bound, lower_bound, central_value, " +
               "delta, activity, hold " +
        "FROM gards_read_sample_cat " +
        "WHERE sample_id = " + sampleId;
	
      Statement stmt = conn.createStatement();
      ResultSet rs   = stmt.executeQuery(queryString);
	
      while (rs.next()) {

        nucl   = rs.getString(1);
        cat    = rs.getInt(2);
        uBound = rs.getDouble(3);
        lBound = rs.getDouble(4);
        cv     = rs.getDouble(5);
        del    = rs.getDouble(6);
        act    = rs.getDouble(7);
        hold   = rs.getInt(8);

        SampleCat currentSC = new SampleCat(sampleId, nucl, cat, uBound,
                                            lBound, cv, del, act, hold);
        list.add(currentSC);

      }

      rs.close();
      stmt.close();

    } catch (SQLException e) {

      System.out.println("Error in read sample comments " + e);

    }

    return list;

  }


  /**
   * Delete all SampleCat entries for the specified sampleId.
   *
   * @param conn the connection to the database
   * @param sampleId value used to compare in the sql where statement
   */
  public static void deleteTable(Connection conn, int sampleId) { 
  
    try {

      String deleteString =
        "DELETE FROM gards_write_sample_cat " +
        "WHERE sample_id = " + sampleId;

      Statement stat = conn.createStatement();
      int catcher    = stat.executeUpdate(deleteString);

      stat.close();
         
    } catch (Exception e) {

      System.out.println("Error deleting table.");
      System.out.println("Exception = " + e);

    }

  }

  
  
                                         
  /**
   * Insert list of SampleCats into the database.
   * The values inserted will be appended to those already in the database. 
   *
   * @param conn the connection to the database
   * @param list the list of values to insert into database
   */
  public static void insertRows(Connection conn, List list) {

    try {

      Statement stat = conn.createStatement();
      PreparedStatement pstmt = conn.prepareStatement(
        "INSERT into gards_write_sample_cat (sample_id, name, method_id, " +
        "category, upper_bound, lower_bound, central_value, delta, " +
        "activity, hold) " +
        "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");           

      int methodId = -1;
	
      for (int ii = 0; ii < list.size(); ii++) {

        SampleCat sc = (SampleCat) list.get(ii);

        String methodIdQuery = "SELECT gards_method_id_seq.nextval " +
                               "FROM dual";
        ResultSet rs         = stat.executeQuery(methodIdQuery);

        while (rs.next()) {

          methodId = rs.getInt(1);

        }

        rs.close();

        pstmt.setInt(1, sc.getSampleId());
        pstmt.setString(2, sc.getName());
        pstmt.setInt(3, methodId);
        pstmt.setInt(4, sc.getCategory());
        pstmt.setDouble(5, sc.getUpperBound());
        pstmt.setDouble(6, sc.getLowerBound());
        pstmt.setDouble(7, sc.getCentralValue());
        pstmt.setDouble(8, sc.getDelta());
        pstmt.setDouble(9, sc.getActivity());
        pstmt.setInt(10, sc.getHold());
 
        pstmt.executeUpdate();

      }
 
      pstmt.close();

    } catch (SQLException e) {

      System.out.println("Error attempting to insert rows.");
      System.out.println("Exception = " + e);

    }

  }


 /**
  * Find the category of a sample.
  * 
  * @param conn database connection
  * @param sampleType    gsd.sample_type
  * @param sampleCatList sample represented as a list of Sample Cats
  * @param outputFissionList  List of SampleCats that are fission products
  * @param outputActivationList List of SampleCats that are activation products
  *
  * @return sample category
  */
  public static int findSampleCategory(Connection conn,
                                       String     sampleType,
                                       List       sampleCatList,
                                       List       outputFissionList,
                                       List       outputActivationList)
   {

    int activationProduct = 0;
    int fissionProduct    = 0;
    int level             = 1;
    String type           = null;


    if((sampleCatList == null) || (sampleCatList.size() == 0))
     {
       return level;
     }


    for (int ii = 0; ii < sampleCatList.size(); ii++) 
     {

    
      type  = NATURAL;     // Assume it's natual

      SampleCat sc = (SampleCat) sampleCatList.get(ii);

      if (sc.getCategory() == 4)
       {
        if ((sampleType.equals("P")) ||
            (sampleType.equals("G")))
          {
            String nuclLib;

       
            if(sampleType.equals("P"))
             {
               nuclLib = "gards_nucl_lib";
             }
            else
             {
               nuclLib = "gards_xe_nucl_lib";
             }

            try 
             {
              String typeRequest =
                "SELECT type " +
                "FROM " + nuclLib +
                " WHERE name = '" + sc.getName() + "'";

              Statement stmt = conn.createStatement();
              ResultSet rs   = stmt.executeQuery(typeRequest);

              while (rs.next())
               {
                 type = rs.getString(1);
                 if(type.startsWith("FISSION"))
                  {
                     type = FISSION;
                  }
                 else if(type.startsWith("ACT"))
                  {
                     type = ACTIVATION;
                  }
 
               }

              rs.close();
              stmt.close();

             }
            catch (SQLException e)
             {
               System.out.println("Failure to find particulate type.");
               System.out.println("Exception = " + e);
             }

          }
        else if (sampleType.equals("B")) // Beta gamma are always fission
         {

            if (!sc.getName().equals("PB-214"))
             {
               type = FISSION_GAS;
             }
         }
        else if (sampleType.equals("R")) // Arix is always fission
         { 

            if (!sc.getName().equals("PB-214"))
             {
              type = FISSION_GAS;

             }
         }

        if (type.equals(ACTIVATION))
         {
             activationProduct++;
             outputActivationList.add(sc);

         }
        else if ((type.equals(FISSION)) ||
                   (type.equals(FISSION_GAS)) ||
                   (type.equals(FISSION_BOTH)))
         {
             fissionProduct++;
             outputFissionList.add(sc);

         }
       }

      if (sc.getCategory() > level)
       {
         level = sc.getCategory();
       }
     }

    if (((fissionProduct > 0) && (fissionProduct + activationProduct > 1)) ||
         (fissionProduct > 1))
     {
       level = 5;
     }

    return level;

  }

  
  /**
   * Updates the database values in gards_sample_cat
   *
   * @param conn database connection
   * @param sampleCatList list of SampleCats to use for updating
   */
  public static void updateSampleCat(Connection conn, List sampleCatList) {

    try {

      PreparedStatement pstmt = conn.prepareStatement(
        "UPDATE gards_write_sample_cat " +
        "SET upper_bound = ?, " +
            "lower_bound = ?, " +
            "central_value = ?, " +
            "delta = ? " +
        "WHERE sample_id = ? " +
        "AND   name = ?");

      for (int ii = 0; ii < sampleCatList.size(); ii++) {

        SampleCat curSC = (SampleCat) sampleCatList.get(ii);
        pstmt.setDouble(1, curSC.getUpperBound());
        pstmt.setDouble(2, curSC.getLowerBound());
        pstmt.setDouble(3, curSC.getCentralValue());
        pstmt.setDouble(4, curSC.getDelta());    
        pstmt.setInt(5, curSC.getSampleId());
        pstmt.setString(6, curSC.getName());
        pstmt.executeUpdate();

      }

      pstmt.close();

    } catch (SQLException e) {

      System.out.println("Failure updating Sample Cats.");
      System.out.println("Exception = " + e);

    }

  }


  /**
   * Returns the sampleID
   *
   * @return sampleId
   */
  public int getSampleId() {

    return sampleId;

  }


  /**
   * Returns the name
   *
   * @return name of the nuclide
   */
  public String getName() {

    return name;

  }


  /**
   * Returns the activity
   * 
   * @return activity
   */
  public double getActivity() {

    return activity;

  }


  /**
   * Returns the category
   *
   * @return category of a particular nuclide
   */
  public int getCategory() {

    return category;

  }


  /**
   * Set the value of the category - must be between 1-4 inclusive
   *
   * @param newCat new value of the category
   */ 
  private void setCategory(int newCat) {

    switch (newCat) {

      case 1: case 2: case 3: case 4:
  
        category = newCat;
        break;

    }

  }    


  /**
   * Returns the centralValue
   *
   * @return centralValue
   */
  public double getCentralValue() {

    return centralValue;

  }


  /**
   * Returns the ewma adjustment variable delta
   *
   * @return delta
   */
  public double getDelta() {

    return delta;

  }


  /**
   * Returns the lower bounds of acceptable activity for a nuclide
   *
   * @return lowerBound
   */
  public double getLowerBound() {

    return lowerBound;

  }


  /**
   * Returns the upper bounds of acceptable activity for a nuclide
   * 
   * @return upperBound
   */
  public double getUpperBound() {

    return upperBound;

  }

  /**
   * Sets hold value
   *
   */
  public void setHold(int h) {

    hold = h;

  }

  /**
   * Returns the value which tells Categorize
   *
   * @return hold
   */
  public int getHold() {

    return hold;

  }

}


