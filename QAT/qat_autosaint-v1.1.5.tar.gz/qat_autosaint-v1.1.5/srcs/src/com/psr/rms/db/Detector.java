/*
 * Detector.java
 */

package com.psr.rms.db;


import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;




/**
 *  This class wraps  the GARDS_DETECTORS table.
 */
public class Detector
 {


    private    int                     detectorId;
    private    String                  detectorCode;
    private    String                  description;
    private    double                  lat;
    private    double                  lon;
    private    String                  type;
    private    int                     channels; 
    private    String                  status;
    private    Calendar                dateBegin;
    private    Calendar                dateEnd;

    public  Detector(int          detectorId, 
                     String       detectorCode,
                     String       description,
                     double       lat,
                     double       lon,
                     String       type,
                     int          channels,
                     String       status,
                     Calendar     dateBegin,
                     Calendar     dateEnd)
     {
        this.detectorId = detectorId;
        this.detectorCode = detectorCode;
        this.description = description;
        this.lat = lat;
        this.lon = lon;
        this.type = type;
        this.channels = channels;
        this.status = status;
        this.dateBegin = dateBegin;
        this.dateEnd = dateEnd;

     }


/**
 *   Read detector data from database.
 *   If error occurs, detectorId will be set to -1
 */
    public  Detector(Connection conn, int did)
     {
        Timestamp      t;


        try {

          String queryString = "select  detector_code, " +
                        " description, lat, lon, type, channels,  "+
                        " status, date_begin, " +
                        " date_end from gards_detectors  " +
                        " where detector_id = " + did;

          Statement st = conn.createStatement();
	  ResultSet rs = st.executeQuery(queryString);

          while (rs.next() == true)
           {

            detectorId = did;
            detectorCode = rs.getString(1);
            description = rs.getString(2);
            lat = rs.getDouble(3);
            lon = rs.getDouble(4);
            type = rs.getString(5);
            channels = rs.getInt(6);
            status = rs.getString(7);
            t = (java.sql.Timestamp) rs.getTimestamp(8);
	    if (t == null)
             {
               dateBegin = null;
             }
	    else
             {
               dateBegin =new GregorianCalendar(TimeZone.getTimeZone("GMT"));
               dateBegin.setTime(t);
             }
 
            t = (java.sql.Timestamp) rs.getTimestamp(9);
	    if (t == null)
	     {
               dateEnd = null;
	     }
	    else
	     {
               dateEnd = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
               dateEnd.setTime(t);
             }
	   }

          st.close();
          rs.close();

        } catch (Exception e) {

          System.out.println("Error getting detector for detector_id " + did);
          detectorId = -1;

        }

     }

 /**
   *  Read from the gards_detectors  table and populate the
   *  array list with the all the detector codes
   *
   *  @param  conn:  The connection to the database
   *
   *  @return Returns an ArrayList of Detectors sorted by code
   */
  public static ArrayList getAllDetectors(Connection conn)
    {
      ArrayList           list;
      Statement           stmt;
      ResultSet           rs;
      String              detectorCode;
      String              queryString;

      int                 detectorId;
      String              description;
      double              lat;
      double              lon;
      String              type;
      int                 channels;
      String              status;
      Calendar            dateBegin;
      Calendar            dateEnd;
      Timestamp           t;





      try
       {
         list = new ArrayList();

         stmt  = conn.createStatement();

         queryString = "select  detector_code, " +
                        " description, lat, lon, type, channels,  "+
                        " status, date_begin, " +
                        " date_end, detector_id " +
                        " from gards_detectors  " +
                        " order by detector_code ";


         stmt.executeQuery(queryString);

         rs = stmt.getResultSet();

         while (rs.next() == true)
          {

            detectorCode = rs.getString(1);
            description = rs.getString(2);
            lat = rs.getDouble(3);
            lon = rs.getDouble(4);
            type = rs.getString(5);
            channels = rs.getInt(6);
            status = rs.getString(7);
            t = (java.sql.Timestamp) rs.getTimestamp(8);
	    if (t == null)
             {
               dateBegin = null;
             }
	    else
             {
               dateBegin =new GregorianCalendar(TimeZone.getTimeZone("GMT"));
               dateBegin.setTime(t);
             }
 
            t = (java.sql.Timestamp) rs.getTimestamp(9);
	    if (t == null)
	     {
               dateEnd = null;
	     }
	    else
	     {
               dateEnd = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
               dateEnd.setTime(t);
             }
            detectorId = rs.getInt(10);


            Detector d = new Detector(
                                   detectorId,
                                   detectorCode,
                                   description,
                                   lat,
                                   lon,
                                   type,
                                   channels,
                                   status,
                                   dateBegin,
                                   dateEnd);

           // add the value to the array list
             list.add(d);
	   }

         // close out the result set
         rs.close();

         // close out the data base connection

         stmt.close();

       }
    catch(java.sql.SQLException e)
       {
         System.out.println("getAllDetectorCodes error: " + e);
         list = null;
       }

     return list;
    }


    public int     getDetectorId()
     {
        return detectorId;
     }


    public String     getDetectorCode() 
     {
        return detectorCode;
     }

    public String     getDescription() 
     {
        return description;
     }

    public double    getLat() 
     {
        return lat;
     }

    public double     getLon() 
     {
        return lon;
     }

    public String  getType()
     {
        return type;
     }

    public int getChannels()
     {
        return channels;
     }


    public String   getStatus()
     {
        return status;
     }

    public Calendar   getDateBegin()
     {
        return dateBegin;
     }

    public Calendar   getDateEnd()
     {
        return dateEnd;
     }

}

