/*
 * EnergyPairs.java
 */

package com.psr.rms.db;

import java.sql.*;

/**
 *  This class wraps the GARDS_ENERGY_PAIRS and GARDS_B_ENERGY_PAIRS table.
 *
 * @author  Pat Donohoe
 * @version 1.0, 05/30/00
 * @since   RMS3.0
 */
public class EnergyPairs
{

  public     static int         BETA_PAIRS    = 1;
  public     static int         GAMMA_PAIRS   = 2;


  private    int                sampleId;
  private    int                numPairs;

  private    double[]           calEnergy;
  private    double[]           calError;
  private    double[]           channel;

 /** 
  * decayMode applies only to beta energy pairs.  This is null for gamma
  */
  private    String[]           decayMode;

  private    static final int   MAX_EN_PAIRS    = 32;

  /**
   *   Read pairs from DB.
   *   @param   conn   data base connection
   *   @param   sid    sample id to read pairs from.
   *   @param   type   Either BETA_PAIRS or GAMMA_PAIRS
   */
  public  EnergyPairs(Connection conn, int sid, int  type)
   {
      getEnergyPairs(conn, sid, type);
   }




 /**
  *   return sample_id
  */
  public final int        getSampleId()
  {
    return sampleId;
  }


  /**
   *   return decay mode.  This is will be null for GAMMA_PAIRS.
   */
  public final String[]     getDecayMode()
  {
    return decayMode;
  }




  /**
   */
  public double[] getCalError()
  {
    return calError;
  }

  /**
   *  return list of energy calibration data
   */
  public double[] getCalEnergy()
  {
    return calEnergy;
  }


  /**
   *  return list of channels
   */
  public double[]     getChannel()
  {
    return channel;
  }

  /**
   *  return number of pairs
   */
  public int         getNumPairs()
  {
    return numPairs;
  }

  /**
   *  load from a sample id.
   */
  public void getEnergyPairs(Connection conn, int sid, int type)
   {

    Statement            stmt;
    ResultSet            rs;
    String               queryString;


    sampleId = sid;
    numPairs = 0;


    try
     {
      if(type == GAMMA_PAIRS)
       {
         queryString = new String("select cal_energy, channel," +
                   " cal_error from gards_energy_pairs where " +
                   " sample_id = " + sid + " order by cal_energy");
       }
      else if(type == BETA_PAIRS)
       {
         queryString = new String("select cal_energy, channel," +
                   " cal_error, decay_mode  from gards_b_energy_pairs where " +
                   " sample_id = " + sid + " order by cal_energy" );
       }
      else
       {
         calEnergy = null;
         channel = null;
         calError = null;
         decayMode = null;
         return;
       }

  
      calEnergy = new double[MAX_EN_PAIRS];
      channel = new double[MAX_EN_PAIRS];
      calError = new double[MAX_EN_PAIRS];
      decayMode= new String[MAX_EN_PAIRS];

      stmt = conn.createStatement();
      rs = stmt.executeQuery(queryString);
      while(rs.next())
       {
         calEnergy[numPairs] =  rs.getDouble(1);
         channel[numPairs] = rs.getDouble(2);
         calError[numPairs] = rs.getDouble(3);
         if(type == BETA_PAIRS)
          {
            decayMode[numPairs] = rs.getString(4);
          }
         else
          {
            decayMode[numPairs] = null;
          } 

         numPairs++;
       }
 
       stmt.close();
       rs.close();
   
     }
    catch(Exception e)
     {
       System.out.println("Exception in EnergyPairs : " + e);
     }
  }

 }
