/*
 * RoiCount.java
 */


package  com.psr.rms.db;

import java.sql.*;
import java.util.*;




/**
 *  This class maps to the gards_roi_counts database table.  The constructor
 *  <code> RoiCount(DBConnection, sample id, roi number)</code> can be
 *  used to read a single roi for a sample.  The static function
 *  <code> ArrayList getSampleRoiCounts(DBConnection, sample id)</code> can
 *  be used to read all RoiCounts for a sample id.
 *1k
 *
 */
public class RoiCount
 {



    private    int                     sampleId;
    private    int                     roi;
    private    double                  gross;
    private    double                  grossErr;
    private    double                  compton;
    private    double                  comptonErr;
    private    double                  interference;
    private    double                  interferenceErr;
    private    double                  memory;
    private    double                  memoryErr; 
    private    double                  detectorBack; 
    private    double                  detectorBackErr; 
    private    double                  net; 
    private    double                  netErr; 
    private    double                  lc; 


/**
 *  Construct an empty RoiCount.
 */
    public RoiCount()
     {
        sampleId = 0;
        roi = 0;
     }

/**
 *  Construct an RoiCount from a specified sample id and roi number. 
 *  This will call the database to fill in the rest of the information.
 */
    public RoiCount(Connection conn, int sid, int rid)
     {

        sampleId = sid;
        roi = rid;
        getRoiCount(conn, sampleId, roi);

     }



   /**
    * Query the database for gards_roi_counts
    * based on sample id and roi number.
    *  If an error occurs, set sample_id and roi number to 0.
    */
    public void getRoiCount(Connection conn, int sid, int rid) {

        Statement      stmt;
        ResultSet      rs;
        String         queryString;

        sampleId = sid;
        roi = rid;
        try
         {

           stmt  = conn.createStatement();
           queryString = new String("select gross,gross_err, " +
                  " compton,compton_err,interference,interference_err," +
                  " memory,memory_err,detector_back,detector_back_err," +
                  " net ,net_err,lc from gards_roi_counts where sample_id = " +
                  sampleId + " and roi = " + roi);

           stmt.executeQuery(queryString);
           rs = stmt.getResultSet();

           // Fill data in
           rs.next();
           gross = rs.getDouble(1);
           grossErr  = rs.getDouble(2);
           compton = rs.getDouble(3);
           comptonErr = rs.getDouble(4);
           interference = rs.getDouble(5);
           interferenceErr = rs.getDouble(6);
           memory = rs.getDouble(7);
           memoryErr = rs.getDouble(8);
           detectorBack = rs.getDouble(9);
           detectorBackErr = rs.getDouble(10);
           net = rs.getDouble(11);
           netErr = rs.getDouble(12);
           lc = rs.getDouble(13);

           rs.close();
           stmt.close();
         }
        catch(java.sql.SQLException e)
         {
            sampleId = 0;
            roi = 0;
         }
 
     }

    /**
     *  Read all ROIS for a specified sample id. The data in the ArrayList 
     *  will be sorted by Roi number.
     */
  public static ArrayList getSampleRoiCounts(Connection conn, int sid) {

    ArrayList  al = new ArrayList();

    for(int i = 0; i < 6; i++) {

      RoiCount  r = new RoiCount(conn, sid, i+1);
      al.add(r);
    }

    return al;

  }

  /**
   * Insert an array of RoiCounts into the database
   *
   * @param conn database connection
   * @param sampleId the id of the sample
   * @param roiCounts array of RoiCounts to be inserted
   */
  public static void insertRoiCounts(Connection conn, int sampleId,
                                     RoiCount[] roiCounts) {

    String queryString =
      "INSERT INTO gards_roi_counts (sample_id, roi, gross, gross_err, " +
        "compton, compton_err, interference, interference_err, memory, " +
        "memory_err, detector_back, detector_back_err, net, net_err, lc) " +
      "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    int length = roiCounts.length;

    for (int ii = 0; ii < length; ii++) {

      try {

        PreparedStatement pstmt = conn.prepareStatement(queryString);
        pstmt.setInt(1, sampleId);
        pstmt.setInt(2, roiCounts[ii].getRoi());
        pstmt.setDouble(3, roiCounts[ii].getGross());
        pstmt.setDouble(4, roiCounts[ii].getGrossErr());
        pstmt.setDouble(5, roiCounts[ii].getCompton());
        pstmt.setDouble(6, roiCounts[ii].getComptonErr());
        pstmt.setDouble(7, roiCounts[ii].getInterference());
        pstmt.setDouble(8, roiCounts[ii].getInterferenceErr());
        pstmt.setDouble(9, roiCounts[ii].getMemory());
        pstmt.setDouble(10, roiCounts[ii].getMemoryErr());
        pstmt.setDouble(11, roiCounts[ii].getDetectorBack());
        pstmt.setDouble(12, roiCounts[ii].getDetectorBackErr());
        pstmt.setDouble(13, roiCounts[ii].getNet());
        pstmt.setDouble(14, roiCounts[ii].getNetErr());
        pstmt.setDouble(15, roiCounts[ii].getLc());

        pstmt.executeUpdate();
        pstmt.close();

      } catch (SQLException e) {

        System.out.println("Failure to insert Roi Counts");
        System.out.println("Exception = " + e);

      }

    }

  }


  /**
   * Deletes all the rows for a particular sample in gards_roi_counts
   *
   * @param conn database connection
   * @param sampleId the id of the sample
   */
  public static void deleteRoiCountTable(Connection conn, int sampleId) {

    String deleteString =
      "DELETE FROM gards_roi_counts " +
      "WHERE sample_id = " + sampleId;

    try {

      Statement stmt = conn.createStatement();
      int catcher    = stmt.executeUpdate(deleteString);

      stmt.close();

    } catch (SQLException e) {

      System.out.println("Failure to delete Roi Counts");
      System.out.println("Exception = " + e);

    }

  }


  public final int getSampleId()
   {
     return sampleId;
   }


    public final int getRoi() 
     {
        return roi;
     }


  public void setRoi(int r) {

    roi = r;

  }

    public final double  getGross()
     {
        return gross;
     }

    public void setGross(double gross)
     {
        this.gross = gross ;
     }

    public final double getGrossErr()
     {
        return grossErr;
     }

    public void setGrossErr(double grossErr)
     {
        this.grossErr = grossErr;
     }

    public final double getCompton()
     {
        return compton;
     }

    public void setCompton(double compton)
     {
        this.compton = compton;
     }

    public final double getComptonErr()
     {
        return comptonErr;
     }

    public void setComptonErr(double comptonErr)
     {
        this.comptonErr = comptonErr;
     }

    public final double  getMemory()
     {
        return memory;
     }

    public void setMemory(double memory)
     {
        this.memory = memory;
     }

    public final double  getMemoryErr()
     {
        return memoryErr;
     }

    public void setMemoryErr(double memoryErr)
     {
        this.memoryErr = memoryErr;
     }

    public final double  getInterference()
     {
        return interference;
     }

    public void setInterference(double interference)
     {
        this.interference = interference;
     }

    public final double  getInterferenceErr()
     {
        return interferenceErr;
     }

    public void setInterferenceErr(double interferenceErr)
     {
        this.interferenceErr = interferenceErr;
     }

    public final double getDetectorBack()
     {
        return detectorBack;
     }

    public void setDetectorBack(double detectorBack)
     {
        this.detectorBack = detectorBack;
     }

    public final double  getDetectorBackErr()
     {
        return detectorBackErr;
     }

    public void setDetectorBackErr(double detectorBackErr)
     {
        this.detectorBackErr = detectorBackErr;
     }

    public final double getNet()
     {
        return net;
     }

    public void setNet(double net)
     {
        this.net = net;
     }

    public final double getNetErr()
     {
        return netErr;
     }

    public void setNetErr(double netErr)
     {
        this.netErr = netErr;
     }

    public final double getLc()
     {
        return lc;
     }

    public void setLc(double lc)
     {
        this.lc = lc;
     }

}

