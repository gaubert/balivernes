
/*
 * SampleData.java
 */

package com.psr.rms.db;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.List;
import java.sql.*;
import java.util.*;

import com.psr.rms.db.*;

/**
 *@author Jon Fortney
 *@version 7-17-00
 */


public class SampleAux
{

  private    int        sampleId;
  private    String     sampleRefId;
  private    String     measurementId;
  private    String     bkgdMeasurementId;
  private    double     sampleHeight;
  private    double     msgId;  
  private    String     archiveBottleId;
  private    String     gasBkgdMeasurement;
  private    double     xeCollectYield;
  private    double     xeCollectYieldErr; 
  private    double     xeVolumeErr;
  private    double     sampleDiameter;
  private    double     xeVolume;  
  
  /**
   *   Read sample from DB.
   */
  
  public  SampleAux(Connection conn, int sid) 
  {
    sampleId = sid;
    getSampleData(conn, sid);
    
  }//end SampleAux constructor
  
  /**
   *   return sampleRefId
   */
  public final String getSampleRefId()
  {
    return sampleRefId;
  
  }//end getSampleRefId
  
  
  /**
   * return measurement
   */
  public final String getMeasurementId()
  {
    return measurementId;
    
  }//end getMeasurementId
  
  /**
   * return bkgdMeasurementId
   */
  public final String getBkgdMeasurementId()
  {
    return bkgdMeasurementId;

  }//end getbkgdMeasurementId
  
  /**
   * return sampleHeight
   */
  public final double getSampleHeight()
  {
    return sampleHeight;
    
  }//end getSampleHeight

  /**
   * return msgId
   */
  public final double getMsgId()
  {
    return msgId;
    
  }//end getMsgId
  
  /**
   * return archiveBottleId
   */
  public final String getArchiveBottleId()
  {
    return archiveBottleId;
    
  }//end getArchiveBottleId

  /**
   * return gasBkgdMeasurement
   */
  public final String getGasBkgdMeasurement()
  {
    return gasBkgdMeasurement;
    
  }//end getGasBkgdMeasurement
  
  /**
   * return xeCollectYield
   */
  public final double getXeCollectYield()
  {
    return xeCollectYield;
    
  }//end getXeCollectYield
  
  /**
   * return xeCollectYieldErr
   */
  public final double getXeCollectYieldErr()
  {
    return xeCollectYieldErr;

  }//end getXeCollectYieldErr

  /**
   * return xeVolumeErr
   */
  public final double getXeVolumeErr()
  {
    return xeVolumeErr;

  }//end getXeVolumeErr

  /**
   * return sampleDiameter
   */
  public final double getSampleDiameter()
  {
    return sampleDiameter;
    
  }//end getSampleDiameter;


  /**
   * return xeVolume
   */  
  public final double getXeVolume() {

    return xeVolume;

  }


  public void getSampleData(Connection conn, int sid) {

    Statement            stmt;
    ResultSet            rs;
    String               queryString;
    
    sampleId = sid;
    
    try {

	queryString = "select sample_ref_id, measurement_id," +
      " bkgd_measurement_id, sample_height, msg_id, " +
      " archive_bottle_id, gas_bkgd_measurement_id, xe_collect_yield, " +
      " xe_collect_yield_err, xe_volume_err, sample_diameter," +
      " xe_volume from gards_sample_aux where sample_id = " + sampleId;

      stmt = conn.createStatement();
      rs = stmt.executeQuery(queryString);
      rs.next();

      sampleRefId        = rs.getString(1);
      measurementId      = rs.getString(2);
      bkgdMeasurementId  = rs.getString(3);
      sampleHeight       = rs.getDouble(4);
      msgId              = rs.getDouble(5);
      archiveBottleId    = rs.getString(6);
      gasBkgdMeasurement = rs.getString(7);
      xeCollectYield     = rs.getDouble(8);
      xeCollectYieldErr  = rs.getDouble(9);
      xeVolumeErr        = rs.getDouble(10);
      sampleDiameter     = rs.getDouble(11);
      xeVolume           = rs.getDouble(12);

      stmt.close();
      rs.close();

    } catch(Exception e) {

      System.out.println("Exception: " + e);

    }
  
  }//end getSampleData
  
}//end SampleAux class




