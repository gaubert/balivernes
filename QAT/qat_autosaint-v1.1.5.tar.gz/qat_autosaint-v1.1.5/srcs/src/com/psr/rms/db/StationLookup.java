/*
 * StationLookup.java
 */

package com.psr.rms.db;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Provides a station code lookup based on station ID, as well as
 * a station ID lookup based on station code.
 *
 * @author kpagano
 */
public class StationLookup {

  /** Indicates an ID does not exist. */
  public static final int NO_ID = -1;

  /** Single instance of StationLookup. */
  private static StationLookup instance;

  /** Map of station IDs to station codes. The station ID 
   * represents the key. The station code represents the string 
   * name. */
  private Map stationIdToCodeMap = new HashMap();


  /** Map of station codes to station IDs. The station code
   * represents the key. The station ID represents the string 
   * name. */
  private Map stationCodeToIdMap = new HashMap();

  /**
   * Constructor.
   *
   * @param connection Connection to the data store.
   */
  private StationLookup(Connection connection) {
    stationIdToCodeMap.clear();
    stationCodeToIdMap.clear();
    
    try {
      String query = 
        "SELECT DISTINCT station_id, station_code " +
        "FROM gards_stations";
      /* open statement */
      Statement statement = connection.createStatement();
      statement.executeQuery(query);
      /* open result set */
      ResultSet resultSet = statement.getResultSet();
      /* for each result */
      while(resultSet.next()) {
        int id = resultSet.getInt("station_id");
        String code = resultSet.getString("station_code");
        stationIdToCodeMap.put(new Integer(id), code);
        stationCodeToIdMap.put(code, new Integer(id));
      } // end while another result exists
      /* close result set */
      resultSet.close ();
      /* close statement */
      statement.close();
    } catch(SQLException se) {
        System.out.println(
          "Error initializing Station ID to Code Station map.");
        System.out.println("Exception = " + se);
    } // end try    
    
} // end Constructor

  /** 
   * Returns the single static instance of StationLookup. 
   *
   * @return Instance of StationLookup
   */
  public static StationLookup getInstance(Connection connection) {
    /* if the single instance of does not exist */
    if(instance == null) {
      /* create the instance */
      instance = new StationLookup(connection);
    }
    /* return the static instance */
    return instance;
  } // end getInstance
  
  /** 
   * Returns the station code corresponding to the given station ID. 
   *
   * @param id ID for which to retrieve the code.
   * @return Station code corresponding to the given ID.
   */
  public String getCode(int id) {
    String code = new String();
    
    Integer idLong = new Integer(id);
    /* if the given stationId exists within the map */
    if(stationIdToCodeMap.containsKey(idLong)) {
      code = stationIdToCodeMap.get(idLong).toString();
    }
    return code;
  } // end getCode
  

  /** 
   * Returns the first station ID corresponding to the given station
   * code. 
   *
   * @param code Code for which to retrieve the ID.
   * @return Station ID corresponding to the given code.
   */
  public int getID(String code) {
    int id = NO_ID;
    
    if(stationCodeToIdMap.containsKey(code)) {

      Integer temp_id = (Integer) stationCodeToIdMap.get(code);
      id = temp_id.intValue();
    }
 
    return id;
  }
  
} // end StationLookup class
