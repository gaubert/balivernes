/*
 * RoiChannel.java
 */


package  com.psr.rms.db;

import java.sql.*;
import java.util.*;



/**
 *  This class encapsulates the GARDS_ROI_channels table.  To read a specific
 *  Roi from the database, use the constructor
 *
 *  <code>RoiChannel(DBConnection, sample id, roi id)</code>
 *
 *  To read all RoiChannel for a sample use the static function:
 *  
 *  <code>ArrayList  getSampleRoiChannel(DBConnection, sample id)</code>
 *
 */
public class RoiChannel
 {

    private      int         sampleId;
    private      int         roi;
    private      double      betaChanStart;
    private      double      betaChanStop;
    private      double      gammaChanStart;
    private      double      gammaChanStop;


    /**
     * Construct an RoiChannel from sample_id, roi number.  This will query
     * the database for the rest of the data.  If an error occurs,
     * the sampleId and roi will be reset to 0. 
     */
    public RoiChannel(Connection  conn, int sid, int rid)
     {
        int    rc;

        sampleId = sid;
        roi = rid;
        rc = getRoiChannel(conn, sampleId, roi);

        if(rc != 0)
         {
           sid = 0;
           roi = 0;
         }
     }

/**
 *  Construct an RoiChannel with all of its data.
 */
    public  RoiChannel(int      sid,
                     int      rid,
                     double   gstart,
                     double   gstop,
                     double   bstart,
                     double   bstop)
     {
        sampleId = sid;
        roi = rid;
        betaChanStart= bstart;
        betaChanStop = bstop;
        gammaChanStart= gstart;
        gammaChanStop = gstop;
     }



    /**
     *  Read all gards_roi_limit rows for a specified sample id. The
     *  ROIs will be sorted by roi
     *
     *  @return   Returns an ArrayList of RoiChannel.
     */
    public static ArrayList  getSampleRoiChannel(Connection conn, int   sid)
     {
        Statement    stmt;
        ResultSet    rs;
        String       queryString;
        RoiChannel   r;
        ArrayList    list;

        try
         {
           list = new ArrayList();

           stmt  = conn.createStatement();

           queryString = "select roi, g_chan_start,g_chan_stop, " +
                         " b_chan_start, b_chan_stop " +
                         " from gards_roi_channels where sample_id = " +
                         sid + " order by roi";

           stmt.executeQuery(queryString);


           rs = stmt.getResultSet();

           // Put returned data into ArrayList.
           while(rs.next())
            { 
              r = new RoiChannel(
                          sid,
                          rs.getInt(1),
                          rs.getDouble(2),
                          rs.getDouble(3),
                          rs.getDouble(4),
                          rs.getDouble(5));

              list.add(r);
            }

           rs.close();
           stmt.close();
         }
        catch(java.sql.SQLException e)
         {
           list = null;
         }

        return list;
     }


    /**
     *  Read one gards_roi_channels row for a specified sample id.
     *  @return  Returns a 0 on success or  a nonzero DB error code on failure.
     */
    public int getRoiChannel(Connection conn, int sid, int rid) {

        Statement    stmt;
        ResultSet    rs;
        String       queryString;
        int          rc;

        rc = 0;
        try
         {

           stmt  = conn.createStatement();

           queryString = "select  g_chan_start,g_chan_stop, " +
                         " b_chan_start, b_chan_stop " +
                           " from gards_roi_channels where sample_id = " +
                             sid + " and roi = " + rid;

           stmt.executeQuery(queryString);


           rs = stmt.getResultSet();

           rs.next();
           sampleId = sid; 
           roi = rid;
           gammaChanStart = rs.getDouble(1);
           gammaChanStop = rs.getDouble(2);
           betaChanStart = rs.getDouble(3);
           betaChanStop = rs.getDouble(4);

           stmt.close();
           rs.close();
         }
        catch(java.sql.SQLException e)
         {
           rc = e.getErrorCode();  
         }

        return rc;
     }


  /**
   * Insert an array of RoiChannels into the database
   *
   * @param conn database connection
   * @param roiChannels array of RoiChannels to be inserted
   */
  public static void insertRoiChannels(Connection conn,
                                       RoiChannel[] roiChannels) {

    String queryString =
      "INSERT INTO gards_roi_channels (sample_id, roi, b_chan_start, " +
         "b_chan_stop, g_chan_start, g_chan_stop) " +
      "VALUES (?, ?, ?, ?, ?, ?)";

    int length = roiChannels.length;

    for (int ii = 0; ii < length; ii++) {

      try {

        PreparedStatement pstmt = conn.prepareStatement(queryString);
        pstmt.setInt(1, roiChannels[ii].getSampleId());
        pstmt.setInt(2, roiChannels[ii].getRoi());
        pstmt.setDouble(3, roiChannels[ii].getBetaChanStart());
        pstmt.setDouble(4, roiChannels[ii].getBetaChanStop());
        pstmt.setDouble(5, roiChannels[ii].getGammaChanStart());
        pstmt.setDouble(6, roiChannels[ii].getGammaChanStop());

        pstmt.executeUpdate();
        pstmt.close();

      } catch (SQLException e) {

        System.out.println("Failure to insert Roi Channels");
        System.out.println("Exception = " + e);

      }

    }

  }


  /**
   * Deletes all the rows for a particular sample in gards_roi_channels
   *
   * @param conn database connection
   * @param sampleId the id of the sample
   */
  public static void deleteRoiChannelsTable(Connection conn, int sampleId) {

    String deleteString =
      "DELETE FROM gards_roi_channels " +
      "WHERE sample_id = " + sampleId;

    try {

      Statement stmt = conn.createStatement();
      int catcher    = stmt.executeUpdate(deleteString);

      stmt.close();

    } catch (SQLException e) {

      System.out.println("Failure to delete Roi Channels");
      System.out.println("Exception = " + e);

    }

  }


    /** Get sample id for Roi */
    public final int    getSampleId()
     {
        return sampleId;
     }

    /** Set sample id for Roi */
    public void setSampleId(int sid)
     {
        sampleId = sid;
     }


    /** Get roi id for Roi */
    public final int    getRoi() 
     {
        return roi;
     }
    /** Set roi id for Roi */
    public void setRoi(int r) 
     {
        roi = r;
     }



    /** Get Gamma Start for Roi */
    public final double getGammaChanStart()
     {
        return gammaChanStart;
     }

    /** Set Gamma Start for Roi */
    public void setGammaChanStart(double a )
     {
        gammaChanStart = a;
     }

    /** Get Gamma Stop for Roi */
    public final double getGammaChanStop()
     {
        return gammaChanStop;
     }

    /** Set Gamma Stop for Roi */
    public void setGammaChanStop(double ae)
     {
        gammaChanStop = ae;
     }


    /** Get Beta Start for Roi */
    public final double getBetaChanStart()
     {
        return betaChanStart;
     }

    /** Set Beta Start for Roi */
    public void setBetaChanStart(double a )
     {
        betaChanStart = a;
     }

    /** Get Beta Stop for Roi */
    public final double getBetaChanStop()
     {
        return betaChanStop;
     }

    /** Set Beta Stop for Roi */
    public void setBetaChanStop(double ae)
     {
        betaChanStop = ae;
     }


}

