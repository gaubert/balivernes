/*
 *  PermissionType.java
 *
 */

package com.psr.rms.db;


/**
 *
 * @author  donohoe
 * @version R4   added for MAR in Coriant
 */
public class PermissionType
 {

   /** Permission type name */
   private String permissionType;


  /** Creates new PermissionType enumeration.
   * @param  permissionType String for database query.
   */
  private PermissionType(String permissionType)
   {
     this.permissionType = permissionType;
   }

  public static final PermissionType PeakComments =
                              new PermissionType("Comments");
  public static final PermissionType GenComments = 
                              new  PermissionType("Comments");
  public static final PermissionType RelCat1 = 
                              new  PermissionType("Rel_Cat123");
  public static final PermissionType RelCat2 = 
                              new  PermissionType("Rel_Cat123");
  public static final PermissionType RelCat3 = 
                              new  PermissionType("Rel_Cat123");
  public static final PermissionType RelCat4 = 
                              new  PermissionType("Rel_Cat45");
  public static final PermissionType RelCat5 = 
                              new  PermissionType("Rel_Cat45");
  public static final PermissionType Roi = 
                              new  PermissionType("ROI");
  public static final PermissionType RemoveNuclide= 
                              new  PermissionType("Remove_Nuclide");
  public static final PermissionType RelWOCat= 
                              new  PermissionType("Rel_WO_Cat");
  public static final PermissionType PassToRole= 
                              new  PermissionType("Pass_to_role");
  public static final PermissionType MarkOther= 
                              new  PermissionType("Mark_Other");
  public static final PermissionType Reprocess= 
                              new  PermissionType("Reprocess");
  public static final PermissionType MARAdmin= 
                              new  PermissionType("MAR_Admin");
  public static final PermissionType RO_qat = 
                              new  PermissionType("RO_QAT");
  public static final PermissionType UH_qat = 
                              new  PermissionType("UH_QAT");






  /** Getter for property permissionType.  This will return one
   * of the predefined types.
   * @return Value of property permissionType 
   */
  public final  String getPermissionType()
   {
     return permissionType;
   }


} 


