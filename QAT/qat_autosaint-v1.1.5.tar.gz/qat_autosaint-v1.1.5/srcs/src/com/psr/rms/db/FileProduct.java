/*
 * FileProduct.java
 */

package com.psr.rms.db;

import java.io.*;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.*;


public class FileProduct {

  private int foff     = 0;
  private int obsolete = 0;
  private int version  = 1;

  private int dsize;
  private int revision;
  private int sampleId;
  private int typeId;
  private long time;
  private long endtime;
  private String author;
  private String dfile;
  private String dir;
  private String sta;
  private String chan;     // For R4, this holds sample_id



  private static DateFormat dateFormat =
    new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");

  public static final String SSREB_REPORT   = "SSREB";
  public static final String ARR_REPORT     = "ARR";
  public static final String SPECTRUM       = "SPECTRUM";
  public static final String HISTOGRAM      = "HISTOGRAM";
  public static final String RRR_REPORT     = "RRR";
  public static final String SCAC           = "SCAC";
  public static final String BASELINE       = "BASELINE";

  
  public int getRevision() {

    return revision;

  }


  public String getFullFilename() {

    return dir + "/" + dfile;

  }


  /**
   *  Removes consecutive slashes in strings.  Only works
   *  with 2 slashes right now. 
   *  This function should use String.replaceAll() when
   *  java 1.4 is available
   *
   *  Replace "//" with "/".  This happens because some database installs
   *  define gards_userenv data directories with "/data/spectrum" and
   *  some use only "data/spectrum".  
   */
  public static String  removeDuplicateSlash(String s)
    {

       StringBuffer sb = new StringBuffer(s);

       int    i = 0;
       while(i < sb.length()-1)
        {
            if((sb.charAt(i) == '/') &&
              (sb.charAt(i+1) == '/'))
             {
               sb.deleteCharAt(i);
             }
            i++;
        }

       return new String(sb);

    }

  /**
   *  Converts Unix filename to windows 
   */
  public static String getLogicalFilename(String filename) {



    String  unixDataDir = System.getProperty("DATA_DIR_UNIX",
                                               "/home/rmsuser/data");

    String  windowsDataDir = System.getProperty("DATA_DIR_WINDOWS", null);


    filename = removeDuplicateSlash(filename);


    /* Return if DATA_DIR_WINDOWS is not defined on command line */ 
    if(windowsDataDir == null)
     {
         return filename;
     }

     int unixLen = unixDataDir.length();

  // Remove this many characters from unixDataDir string
     String  subUnixString = filename.substring(unixLen, filename.length());

     String newFile = windowsDataDir + "\\" + subUnixString;

     newFile = newFile.replace('/','\\');
     return  newFile;
   }



  /**
   *  Returns full filename when on unix, otherwise
   *  replaces the RMS_HOME data dir with the
   *  windows prefix for that directory.
   */
  public String getLogicalFilename() {


    String   fullFile = getFullFilename();

    String  unixDataDir = System.getProperty("DATA_DIR_UNIX",
                                               "/home/rmsuser/data");

    String  windowsDataDir = System.getProperty("DATA_DIR_WINDOWS", null);

    if(windowsDataDir == null)
     {
         return fullFile;
     }

    int unixLen = unixDataDir.length();

   // Remove this many characters from unixDataDir string

     String  subUnixString = fullFile.substring(unixLen, fullFile.length());

     String newFile = windowsDataDir + "\\" + subUnixString;

     newFile = newFile.replace('/','\\');
     return  newFile;
  }


  public String getFile() {

    return dfile;

  }

  public int getOffset() {

    return foff;

  }


  public String getDirectory() {

    return dir;

  }


  public void setDirectory(String f) {

    dir = f;

  }


  public void setFile(String f) {

    dfile = f;

  }


  public void setSize(int size) {

    dsize = size;

  }

  public int getSize() {

    return dsize;

  }


  public int getVersion() {

    return version;

  }


  public void setAuthor(String a) {

    author = a;

  }

  public void setChan(String c) {

    chan = c;

  }

  public String getChan() {

    return chan;

  }
 
  /**
   * Updates revision number and filename
   */ 
  public void updateRevision() {

    String baseFileName = dfile;
    int    indexOfDot   = baseFileName.indexOf(".");

    if (indexOfDot != -1) {

      baseFileName = baseFileName.substring(indexOfDot+1,
                                            baseFileName.length());
    }

    revision++;
    dfile = revision + "." + baseFileName;

  }


  /** 
   * 
   */
  public void insert(Connection conn) {

    insertFileName(conn, typeId, dir, dfile, foff, dsize, sta, author,
                   version, revision, time, endtime, chan, obsolete);

  }


  /** 
   * 
   */
  public static void insertFileName(Connection conn, int typeId, String dir,
                                    String dfile, int foff, int dsize,
                                    String sta, String author, int version,
                                    int revision, long time, long endtime,
                                    String chan, int obsolete) {

    int fpid;
    int rc;
    ResultSet rs;
    Statement stmt;
    String lddate;
    String queryString;
    String updateString;
  
    try 
    { 

      stmt        = conn.createStatement();
      queryString = "Select keyvalue from lastid where keyname = 'fpid' " +
                    "for update";
    
      rs = stmt.executeQuery(queryString);
      rs.next();

      fpid = rs.getInt(1);
      fpid++;

      updateString = "update lastid set keyvalue = " + fpid + " where " + 
                     "keyname = 'fpid'";
    
      rc = stmt.executeUpdate(updateString);
     
      lddate = "to_date('" + dateFormat.format(new Date()) + "', " +
               "'YYYY.MM.DD HH24:MI:SS')";
    
      updateString = "insert into fileproduct(fpid, typeid, dir, dfile, " +
                     "foff, dsize, sta, author, version, revision, " +
                     "obsolete, lddate, time, endtime, chan) values(" + fpid + 
                     ", " + typeId + ", '" + dir + "', '" + dfile +
                     "', " + foff + ", " + dsize + ", '" + sta +
                     "', '" + author + "', " + version + ", " + revision +
                     ", " + obsolete + ", " + lddate + ", " + time +
                     ", " + endtime + "," + chan + ")";


      rc = stmt.executeUpdate(updateString);
    
      stmt.close();
      rs.close();

    } catch (java.sql.SQLException e) {

      System.out.println("Exception in FileProdcut.insertFileName() : " + e);
      rc = e.getErrorCode();
      System.out.println("error code " + rc);

    }
  }


  /**
   * Read typeid from FPDESCRIPTION table.
   * @param prodType   prodtype from FPDESCRIPTION
   */
  public static int findTypeId(Connection   conn,
                               String       prodType) throws Exception
   {

    int typeId = -1;

    Statement stmt;
    ResultSet rs;
    String queryString;

    try
     {

      stmt        = conn.createStatement();
      queryString = "select typeid from fpdescription where prodtype = '" +
                    prodType + "'";
      
      rs = stmt.executeQuery(queryString);
      rs.next();
      typeId = rs.getInt(1);

      rs.close();
      stmt.close();

     }
    catch(java.sql.SQLException e)
     {
      throw new Exception("Error getting typeid from fpdescription for " +
                          prodType +  "\n" + e);
    
     }  
    return typeId;
   }



  /**
   * Read specified type from from disk. This will get the latest revision
   * @param sid         sample_id 
   * @param prodType    prodtype from FPDESCRIPTION
   */
  public void open(Connection conn, int sid, String prodType) {


    Statement stmt;
    ResultSet rs;
    String    queryString;

    sampleId = sid;
    try {

      stmt        = conn.createStatement();

      typeId = findTypeId(conn, prodType);

      queryString = "select dir, dfile, revision, time, endtime, sta, " +
                    "dsize, author, obsolete, foff, chan from fileproduct " +
                    "where typeid = " + typeId  + " and chan = '" + 
                     sid  + "' order by revision desc";

      rs = stmt.executeQuery(queryString);
      if(rs.next())
       {
         dir      = rs.getString(1);
         dfile    = rs.getString(2);
         revision = rs.getInt(3);
         time     = rs.getLong(4);
         endtime  = rs.getLong(5);
         sta      = rs.getString(6);
         dsize    = rs.getInt(7);
         author   = rs.getString(8);
         obsolete = rs.getInt(9);
         foff     = rs.getInt(10);
         chan     = rs.getString(11);
        }
       else
        { 
          System.out.println("No data in fileproduct table  ");
        }

      stmt.close();
      rs.close();

    }
    catch(java.sql.SQLException e)
     {
      System.out.println("SQL Exception in FileProduct.open(): " + e);
     }
    catch(Exception e)
     {
      System.out.println("Exception in FileProduct.open(): " + e);

    }
  }




  /**
   * Read specified type from from disk. This does not look at
   * version numnbers.  dir and dfile are loaded exactly as
   * stored in the fileproduct table.
   *
   * @param sid         sample_id 
   * @param prodType    defined in constants section
   * @return            returns 0 on success, otherwise non-zero
   */
 public int getSpectrumFilename(Connection conn,
                                           int        sampleId,
                                           String     prodType) 
  {



    Statement stmt;
    ResultSet rs;
    String    queryString;
    int       rc  = 0;

    try {

      stmt        = conn.createStatement();

      int typeId = findTypeId(conn, prodType);

      queryString = "select dir, dfile , time, endtime, sta, " +
                    "dsize, author, foff from fileproduct " +
                    "where typeid = " + typeId  + " and chan = '" + sampleId + "' ";

      rs = stmt.executeQuery(queryString);
      if(rs.next())
       {
         dir      = rs.getString(1);
         dfile    = rs.getString(2);
         time     = rs.getLong(3);
         endtime  = rs.getLong(4);
         sta      = rs.getString(5);
         dsize    = rs.getInt(6);
         author   = rs.getString(7);
         foff     = rs.getInt(8);
        }
       else
        {
          System.out.println("No data in fileproduct table  ");
        }

      stmt.close();
      rs.close();

    }
    catch(java.sql.SQLException e)
     {
      System.out.println("SQL Exception in FileProduct.open(): " + e);
      rc = -1;
     }
    catch(Exception e)
     {
      System.out.println("Exception in FileProduct.open(): " + e);
      rc = -1;

    }
   return rc;
  }










}

