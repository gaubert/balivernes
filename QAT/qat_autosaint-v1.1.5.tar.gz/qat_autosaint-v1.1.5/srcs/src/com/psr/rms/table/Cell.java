/*
 * Cell.java
 *
 * Created on May 25, 2000, 11:25 AM
 * Brett Pettigrew, Pacific-Sierra Research
 */

package com.psr.rms.table;

/** interface for StringTable cells
 * @author Brett Pettigrew
 */
public abstract class Cell {

  private String cont; //the content of the cell

  /** Creates a new Cell containing a String
   * @param content the String to be placed in the cell
   */
  public Cell(String content) {
    cont = content;
  }
  
  /** Returns the unformatted contents of the Cell.
   * @return the contents of the cell.
   */
  public String getContent() {
    return cont;
  }

  /** returns a String representation of the cell.
   * @return a String representation of the cell.
   */
  public String toString() {
    return cont;
  }


  /** returns the content of the string, formatted.
   * @param width how many characters wide the cell should be displayed at
   * @return the formatted cell
   */
  public abstract String getFormatted(int width);
  
}
