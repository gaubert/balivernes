/*
 * StatusHistory.java
 * author  Mark Erickson
 * Date 04/03/02
 *
 */

package com.psr.rms.db;

import java.sql.*;
import java.util.*;
import java.text.SimpleDateFormat;

/**
 *
 * This class provides utilities to the gards_status_history table
 *
 *
 */ 
public class StatusHistory 
 {

  /** Java format of query dates. */ 
  private static final SimpleDateFormat SIMPLE_DATE_FORMAT = 
                              new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 
  
  /** Corresponding SQL format of dates for previous Java format. */
  private static final String DB_DATE_FORMAT = 
                              "'YYYY/MM/DD HH24:MI:SS'";

  
   private    String            oldStatus;
   private    String            newStatus;
   private    java.util.Date    dtg;
   private    int               sampleId;
   private    String            user;



   /**
    *
    *  Constructor which builds a StatusHistory initialized with data.
    *
    *  @param old_status The status for this sample before QAT change
    *  @param new_status The status for this sample after QAT change
    *  @param dtg        The date (SYSDATE) of the change in status
    *  @param sample_id  The sample id effected by the change
    *  @param user       The qat_user who made the change
    *
    */
   public  StatusHistory(String            old_status,
                         String            new_status,
                         java.util.Date    dtg,
                         int               sample_id,
                         String            user)

    {
      this.oldStatus = old_status;
      this.newStatus = new_status;
      this.dtg = dtg;
      this.sampleId = sample_id;
      this.user = user;
    }

    
   /**
    *  Read from the gards_status_history table and populate the
    *  array list with database values for a particular sample_id
    *
    *  @param  conn      The connection to the database
    *  @param  sampleId  The sample id to query values for
    *
    *  @return Returns an List of StatusHistory or null if no
    *                  values returned from query.
    *  @throws A java.sql.SQLException
    *
    */
   public static List getStatusHistoryForSample(Connection  conn,
                                                int         sampleId)
    {
      List           list;
      Statement           stmt;
      ResultSet           rs;
      StatusHistory       sh;
      String              queryString;

      try
       {
         list = new ArrayList();

         stmt  = conn.createStatement();

         queryString =
            "select " +
            "old_status, " +
            "new_status, " +
            "dtg, " +
            "sample_id, " +
            "user_name " +
            "from gards_status_history " +
            "where sample_id = " + sampleId +
            " order by dtg";

         stmt.executeQuery(queryString);

         rs = stmt.getResultSet();

         // load data into list as long as there are rows
         while(rs.next() == true)
           {
             // create a new list in the array for each row returned
             sh  = new StatusHistory(rs.getString(1),   // old status
                                     rs.getString(2),   // new status
                                     rs.getTimestamp(3),   // date
                                     rs.getInt(4),      // sample id
                                     rs.getString(5));  // user

              // add the row to the array list
              list.add(sh);

            }

         // close out the result set
         rs.close();

         // close out the data base connection
         stmt.close();

       }
     catch(java.sql.SQLException e)
       {
         System.out.println("Status History error: " + e);
         list = null;
       }

     return list;

    }

  /** 
   * Returns the StatusHistory data object representing the last
   * record entered for the given sample ID.
   *
   * @param connection Connection to the data store.
   * @param sampleID Sample ID for which to retrieve the last status
   * history.
   * @return Last status history entered corresponding to the given
   * sample ID.
   */
  public static StatusHistory getLastEntry(Connection connection,
                                           int        sampleID)
   {

    /* last status history entered corresponding to the sample ID */
    StatusHistory lastEntry =  null;
    
    List statusHistories =
      StatusHistory.getStatusHistoryForSample(connection, sampleID);
    int numStatusHistories = statusHistories.size();  

    /* if atleast 1 StatusHistory exists */
    if(numStatusHistories != 0) {
      lastEntry = (StatusHistory)Collections.max(
        StatusHistory.getStatusHistoryForSample(connection, sampleID),
          new Comparator() {
            public int compare(Object obj1, Object obj2) {
              StatusHistory statusHistory1 = (StatusHistory)obj1;
              StatusHistory statusHistory2 = (StatusHistory)obj2;
              return statusHistory1.getDate().compareTo(
                statusHistory2.getDate());
            } // end actionPerformed
          } // end new Comparator
        );
    } // end if atleast 1 StatusHistory exists
      
    return lastEntry;    
  } // end getLastEntry

   /**
    *  Inserts to the gards_status_history table values of user,
    *  old_status, new_status, SYSDATE for a particular sample_id
    *
    *  @param  conn  The connection to the database
    *  @param  sampleId The sample id with the status change
    *  @param  user The qat_user making the change in status 
    *  @param  oldStatus The value of the status that has changed
    *  @param  newStatus The value of the new status
    *
    *  @return An int value (0 if success, non-zero if failure)
    *  @throws A java.sql.SQLException
    *
    */
   public static int insertStatusUpdate(Connection  conn,
                                        int         sampleId,
                                        String      user,
                                        String      oldStatus,
                                        String      newStatus)
    {

        Statement   stmt;
        String      insertString;
        int         rc = 0;

        try
         {
            insertString = 
                      "insert into gards_status_history " +
                      "(OLD_STATUS,NEW_STATUS,DTG,SAMPLE_ID,USER_NAME) " + 
                      "values('"+ oldStatus +"', " +
                              "'"+ newStatus +"', "  +
                                "SYSDATE, " +
                                + sampleId + ", " +
                              "'"+ user+ "')";

            stmt = conn.createStatement();
            rc = stmt.executeUpdate(insertString);
            stmt.close();

         }
        catch(java.sql.SQLException  e)
         {

           System.out.println("gards_status_history Error:   " + e);
           rc = e.getErrorCode();
         }

        return rc;
    }


  /**
   *  Method that retrieves the oldStatus from a StatusHistory 
   *  @returns The old status value from a row in the gards_status_history
   */
   public final String getOldStatus()
      {
        return oldStatus;
      }

  /**
   *  Method that retrieves the newStatus from a StatusHistory 
   *  @returns The new status value from a row in the gards_status_history
   */
   public final String getNewStatus()
      {
        return newStatus;
      }

  /**
   *  Method that retrieves the date from a StatusHistory 
   *  @returns The date value from a row in the gards_status_history
   */
   public final java.util.Date getDate()
      {
        return dtg;
      }

  /**
   *  Method that retrieves the sample id from a StatusHistory 
   *  @returns The sample id value from a row in the gards_status_history
   */
   public final int getSampleId()
      {
        return sampleId;
      }

  /**
   *  Method that retrieves the user from a StatusHistory 
   *  @returns The qat user value from a row in the gards_status_history
   */
   public final String getQatUser()
      {
        return user;
      }
      
//////////////////////////////////////
// Queries used by rms_QAT_report   //
//////////////////////////////////////
  /**
   * Returns the number of samples being held for QC Review
   * (status change from Q to T) between the given dates for the given 
   * station IDs.  
   *
   * @param conn Data store connection.
   * @param begin Begin date of the time range to be queried.
   * @param end End date of the time range to be queried.
   * @param stationIDs List of station IDs to be queried.
   * NOTE: List of Station IDs contains Integer objects.
   * @return Number of samples held for QC Review during the given 
   * dates for the given station IDs.  
   */
  public static int getNumSamplesHeldForQCReview(Connection   conn,
                                                 Calendar     begin,                                                             Calendar     end,
                                                 List         stationIDs)
   {
     
    /* format dates for query  */
    String beginDate = SIMPLE_DATE_FORMAT.format(begin.getTime());
    String endDate = SIMPLE_DATE_FORMAT.format(end.getTime());

    /* number of samples held for QC review */
    int numSamplesHeldForQCReview = 0;    
    try {
      StringBuffer query = new StringBuffer(
        "SELECT COUNT(*) " +
        "FROM gards_status_history, gards_sample_data " +
        "WHERE ((old_status = 'Q') AND (new_status = 'T') AND " +
        "(dtg >= " +
        "to_date('" + beginDate + "', " + DB_DATE_FORMAT + ")) AND " +
        "(dtg <= " +
        "to_date('" + endDate + "', " + DB_DATE_FORMAT + ")) " +
        "AND (gards_status_history.sample_id = gards_sample_data.sample_id) ");


        int numStationIDs = stationIDs.size();
        if(numStationIDs > 0) {

           query.append("AND station_id IN(");


           for(int index = 0; index < numStationIDs; index++) {

             query.append(((Integer)stationIDs.get(index)).toString());

             if(index != numStationIDs-1) {

               query.append(", ");

             }
           }
          query.append("))");

        } else {

          query.append(")");

        }

      Statement stmt = conn.createStatement();
      ResultSet  rs = stmt.executeQuery(query.toString());
      if(rs.next()) {
        numSamplesHeldForQCReview = rs.getInt(1);
      } 

      rs.close();
      stmt.close();

    } catch (SQLException e) {
      System.out.println(
        "Error retrieving number of samples held for QC review.");
      System.out.println("Exception = " + e);
    }
      
    return numSamplesHeldForQCReview;
  } // end getNumSamplesHeldForQCReview

  /**
   * Returns the number of samples put on hold (status change from 
   * T to H) between the given dates for the given station IDs.  
   *
   * @param conn Data store connection.
   * @param begin Begin date of the time range to be queried.
   * @param end End date of the time range to be queried.
   * @param stationIDs List of station IDs to be queried.
   * NOTE: List of Station IDs contains Integer objects.
   * @return Number of samples put on hold during the given dates  
   * for the given station IDs.  
   */
  public static int getNumSamplesPutOnHold(Connection  conn,
                                           Calendar    begin,
                                           Calendar    end,
                                           List        stationIDs) 
  {

    /* format dates for query  */
    String beginDate = SIMPLE_DATE_FORMAT.format(begin.getTime());
    String endDate = SIMPLE_DATE_FORMAT.format(end.getTime());
   
    /* number of samples put on hold */
    int numSamplesPutOnHold = 0;    
    try {
      StringBuffer query = new StringBuffer(
        "SELECT COUNT(*) " +
        "FROM gards_status_history, gards_sample_data " +
        "WHERE ((old_status = 'T') AND (new_status = 'H') AND " +
        "(dtg >= " +
        "to_date('" + beginDate + "', " + DB_DATE_FORMAT + ")) AND " +
        "(dtg <= " +
        "to_date('" + endDate + "', " + DB_DATE_FORMAT + ")) " +
        "AND (gards_status_history.sample_id = gards_sample_data.sample_id) ");


        int numStationIDs = stationIDs.size();
        if(numStationIDs > 0) {

           query.append("AND station_id IN(");


           for(int index = 0; index < numStationIDs; index++) {

             query.append(((Integer)stationIDs.get(index)).toString());

             if(index != numStationIDs-1) {

               query.append(", ");

             }
           }
          query.append("))");

        } else {

          query.append(")");

        }
      
      Statement stmt = conn.createStatement();
      ResultSet  rs = stmt.executeQuery(query.toString());
      if(rs.next()) {
        numSamplesPutOnHold = rs.getInt(1);
      } 

      rs.close();
      stmt.close();

    } catch (SQLException e) {
      System.out.println(
        "Error retrieving number of samples held for QC review.");
      System.out.println("Exception = " + e);
    }
      
    return numSamplesPutOnHold;
  } // end getNumSamplesPutOnHold
  

} // end StatusHistory class
