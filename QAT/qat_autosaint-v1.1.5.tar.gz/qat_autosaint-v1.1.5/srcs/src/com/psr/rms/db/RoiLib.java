/*
 * RoiLib.java
 */


package  com.psr.rms.db;

import java.sql.*;
import java.util.*;



/**
 *  This class wraps  the GARDS_ROI_LIB table.
 *
 * @author  Pat Donohoe
 * @version 1.0, 05/30/00
 * @since   RMS3.0
 */
public class RoiLib
 {

    private    int                     roi;
    private    String                  name;
    private    String                  halflife;
    private    String                  halflifeErr;
    private    double                  abundance;
    private    double                  abundanceErr;
    private    double                  halflifeSec;



/**
 *  Construct an RoiLib from a specified roi number. 
 *  This will call the database to fill in the rest of the information.
 */
    public RoiLib(Connection conn, int rid) {

        roi = rid;
        getRoiLib(conn, roi);

     }



/**
 *  Query the database for gards_roi_lib based roi number.
 *  If an error occurs, set roi number to 0.
 */
    public void getRoiLib(Connection conn, int rid) {

        Statement      stmt;
        ResultSet      rs;
        String         queryString;

        roi = rid;
        try
         {

           stmt  = conn.createStatement();
           queryString = "select name, halflife, " +
                  " halflife_err,abundance,abundance_err, halflife_sec " +
                  " from gards_roi_lib where roi = " + roi;

           stmt.executeQuery(queryString);
           rs = stmt.getResultSet();

           // Fill data in
           rs.next();
           name = rs.getString(1);
           halflife = rs.getString(2);
           halflifeErr= rs.getString(3);
           abundance= rs.getDouble(4);
           abundanceErr= rs.getDouble(5);
           halflifeSec = rs.getDouble(6);

           stmt.close();
           rs.close();

         }
        catch(java.sql.SQLException e)
         {
            roi = 0;
         }
 
     }


    /**
     *  Read whole ROI library 
     */
    public static ArrayList getRoiLib(Connection conn) {

       ArrayList  al = new ArrayList();

       for(int i =0;i<6;i++)
        {
          RoiLib r = new RoiLib(conn, i+1);
          al.add(r);
        }
       return al;
     }


    /**
     * get nuclide name occuring in ROI
     */
    public final String   getName()
     {
        return name;
     }


    /**
     * get roi number.  This will be 1..6 or 0 on error.
     */
    public final int getRoi() 
     {
        return roi;
     }


    /**
     * get halflife string.
     */
    public final String  getHalflife()
     {
        return halflife;
     }

    /**
     * get halflife_err string.
     */
    public final String getHalflifeErr()
     {
        return halflifeErr;
     }

    /**
     * get halflife in seconds.
     */
    public final double  getHalflifeSec()
     {
        return halflifeSec;
     }

    /**
     * get abundance
     */
    public final double getAbundance()
     {
        return abundance;
     }


   /**
    * get abundance_err
    */
  public final double getAbundanceErr() {

    return abundanceErr;

  }

}

