/*
 * AssignmentTableModel
 */


package com.psr.rms.db;



import javax.swing.*;
import javax.swing.table.*;
import java.util.*;
import java.text.*;


 public class AssignmentTableModel extends AbstractTableModel
  {

   private   List         assignmentList = new ArrayList();
   private   DateFormat   df = new SimpleDateFormat();
     

   public void addEntry(int sampleId, Calendar collectStop,
                        int  autoCat, String station, String status)
    {
      AssignmentHolder ah = new AssignmentHolder(sampleId,
                                        collectStop, autoCat, station, status);
      assignmentList.add(ah);
    }


   public int getSampleId(int  row)
    {
      Integer  sid = (Integer)getValueAt(row, 0);
      return sid.intValue();
    }


   public int getRowCount()
    {
      return assignmentList.size();
    }

   public int getColumnCount()
    {
      return 5;
    }

   public String getColumnName(int  col)
    {
       switch(col)
        {
         case 0:   return "Sample Id";
         case 1:   return "Collect Stop";
         case 2:   return "Priority";
         case 3:   return "Station";
         case 4:   return "Status";

         default:  return "None";
       }

    }

   public Object getValueAt(int row, int col)
    {

      AssignmentHolder ah = (AssignmentHolder)assignmentList.get(row);

      switch(col)
       {

         case 0:   return new Integer(ah.sampleId);

         case 1:   if(ah.collectStop == null)
                    {
                      return "";
                    }
                   else
                    {
                      return df.format(ah.collectStop.getTime());
                    }

         case 2:   return new Integer(ah.autoCat);
         case 3:   return ah.station;
         case 4:   return ah.status;


         default:  return new String("None");
       }

    }
 
   }


 class AssignmentHolder
  {
     public  int        sampleId;
     public  Calendar   collectStop;
     public  int        autoCat;
     public  String     station;
     public  String     status;

     public AssignmentHolder(int sampleId,
                       Calendar collectStop, int  autoCat, String station,
                       String status)
      {
         this.sampleId = sampleId;
         this.collectStop = collectStop;
         this.autoCat = autoCat;
         this.station = station;
         this.status = status;
      }
  }

