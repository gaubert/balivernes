package com.psr.rms.db;

import java.sql.*;

public class EnergyCal {

  private int sampleId;

  private double betaCoeff1;
  private double betaCoeff2;
  private double betaCoeff3;
  private double gammaCoeff1;
  private double gammaCoeff2;
  private double gammaCoeff3;

  public static final int SUCCESS =  0;
  public static final int FAILURE = -1;

  /**
   * Empty constructor
   */
  public EnergyCal() {}


  /**
   * Constructs an EnergyCal by filling all its fields
   *
   * @param sid id of the sample
   * @param b1 gain of the beta ECR equation
   * @param b2 linear coefficient of the beta ECR equation
   * @param b3 quadratic coefficient of the beta ECR equation
   * @param g1 gain of the gamma ECR equation
   * @param g2 linear coefficient of the gamma ECR equation
   * @param g3 quadratic coefficient of the gamma ECR equation
   */
  public EnergyCal(int sid, double b1, double b2, double b3, double g1,
                   double g2, double g3) {

    sampleId    = sid;
    betaCoeff1  = b1;
    betaCoeff2  = b2;
    betaCoeff3  = b3;
    gammaCoeff1 = g1;
    gammaCoeff2 = g2;
    gammaCoeff3 = g3;
  
  }


  /**
   * Functions as an EnergyCal constructor, but returns a success value
   *
   * @param conn database connection
   * @param sampleId id of the sample
   */
  public int getEnergyCal(Connection conn, int sampleId) {

    int returnValue = FAILURE;

    String queryString =
      "SELECT beta_coeff1, beta_coeff2, beta_coeff3, " +
             "gamma_coeff1, gamma_coeff2, gamma_coeff3 " +
      "FROM gards_bg_energy_cal " +
      "WHERE sample_id = " + sampleId;

    Statement stmt;

    try {

      stmt           = conn.createStatement();
      ResultSet rs   = stmt.executeQuery(queryString);

      rs.next();
   
      betaCoeff1  = rs.getDouble(1);
      betaCoeff2  = rs.getDouble(2);
      betaCoeff3  = rs.getDouble(3);
      gammaCoeff1 = rs.getDouble(4);
      gammaCoeff2 = rs.getDouble(5);
      gammaCoeff3 = rs.getDouble(6);

      returnValue = SUCCESS;

      stmt.close();

    } catch (SQLException e) {

      System.out.println("Failure to get EnergyCal values");
      System.out.println("Exception = " + e);

    }

    return returnValue;

  }


  /**
   * Deletes an Energy Cal record from the database
   *
   * @param conn database connection
   * @param sampleId id of the sample
   */
  public static void deleteEnergyCalTable(Connection conn, int sampleId) {

    String deleteString = 
      "DELETE FROM gards_bg_energy_cal " +
      "WHERE sample_id = " + sampleId;

    try {

      Statement stmt = conn.createStatement();
      int catcher    = stmt.executeUpdate(deleteString);

      stmt.close();

    } catch (SQLException e) {

      System.out.println("Failure to delete Energy Cal record");
      System.out.println("Exception = " + e);

    }

  }
  

  /**
   * Inserts an Energy Cal record into the database
   *
   * @param conn database connection
   * @param ec Energy Cal record to be put in the database
   */
  public static void insertRow(Connection conn, EnergyCal ec) {

    String insertString = 
      "INSERT INTO gards_bg_energy_cal (sample_id, beta_coeff1, " +
                                       "beta_coeff2, beta_coeff3, " +
                                       "gamma_coeff1, gamma_coeff2, " +
                                       "gamma_coeff3) " +
      "VALUES (?, ?, ?, ?, ?, ?, ?)";

    try {

      PreparedStatement pstmt = conn.prepareStatement(insertString);
      pstmt.setInt(1, ec.getSampleId());
      pstmt.setDouble(2, ec.getBetaCoeff1());
      pstmt.setDouble(3, ec.getBetaCoeff2());
      pstmt.setDouble(4, ec.getBetaCoeff3());
      pstmt.setDouble(5, ec.getGammaCoeff1());
      pstmt.setDouble(6, ec.getGammaCoeff2());
      pstmt.setDouble(7, ec.getGammaCoeff3());
 
      pstmt.executeUpdate();
      pstmt.close();

    } catch (SQLException e) {

      System.out.println("Failure to insert Energy Cal record");
      System.out.println("Exeception = " + e);

    }

  }


  /**
   * Returns the sampleId value
   *
   * @return id of the sample
   */
  public int getSampleId() {

    return sampleId;

  }


  /**
   * Sets the sampleId value
   *
   * @param newId new id of the sample
   */
  public void setSampleId(int newId) {

    sampleId = newId;

  }


  /**
   * Returns the value of the first beta coefficient (the gain)
   *
   * @return value of betaCoeff1
   */ 
  public double getBetaCoeff1() {

    return betaCoeff1;

  }


  /**
   * Sets the value of the first beta coefficient (the gain)
   *
   * @param new value of betaCoeff1
   */  
  public void setBetaCoeffs1(double newBetaCoeff1) {

    betaCoeff1 = newBetaCoeff1;

  }


  /**
   * Returns the value of the linear beta coefficient)
   *
   * @return value of betaCoeff2
   */ 
  public double getBetaCoeff2() {

    return betaCoeff2;

  }


  /**
   * Sets the value of the linear beta coefficient
   *
   * @param new value of betaCoeff2
   */  
  public void setBetaCoeffs2(double newBetaCoeff2) {

    betaCoeff2 = newBetaCoeff2;

  }


  /**
   * Returns the value of the quadratic beta coefficient
   *
   * @return value of betaCoeff3
   */ 
  public double getBetaCoeff3() {

    return betaCoeff3;

  }


  /**
   * Sets the value of the quadratic beta coefficient
   *
   * @param new value of betaCoeff3
   */  
  public void setBetaCoeffs3(double newBetaCoeff3) {

    betaCoeff3 = newBetaCoeff3;

  }


  /**
   * Returns the value of the first gamma coefficient (the gain)
   *
   * @return value of gammaCoeff1
   */ 
  public double getGammaCoeff1() {

    return gammaCoeff1;

  }


  /**
   * Sets the value of the first gamma coefficient (the gain)
   *
   * @param new value of gammaCoeff1
   */  
  public void setGammaCoeffs1(double newGammaCoeff1) {

    gammaCoeff1 = newGammaCoeff1;

  }


  /**
   * Returns the value of the linear gamma coefficient
   *
   * @return value of gammaCoeff2
   */ 
  public double getGammaCoeff2() {

    return gammaCoeff2;

  }


  /**
   * Sets the value of the linear gamma coefficient
   *
   * @param new value of gammaCoeff2
   */    
  public void setGammaCoeffs2(double newGammaCoeff2) {

    gammaCoeff2 = newGammaCoeff2;

  }


  /**
   * Returns the value of the quadratic gamma coefficient
   *
   * @return value of gammaCoeff3
   */ 
  public double getGammaCoeff3() {

    return gammaCoeff3;

  }


  /**
   * Sets the value of the quadratic gamma coefficient
   *
   * @param new value of gammaCoeff3
   */  
  public void setGammaCoeffs3(double newGammaCoeff3) {

    gammaCoeff3 = newGammaCoeff3;

  }

}

