/*
 * TableCellCentered.java
 *
 * Created on May 25, 2000, 3:55 PM
 * Brett Pettigrew, Pacific-Soerra Research
 */

package com.psr.rms.table;

/** a StringTable cell that displays its contents right-justified
 * @author Brett Pettigrew
 */
public class CellRight extends Cell {

  /** Creates a new CellRight
   * @param content the contents of the cell
   */
  public CellRight(String content) {
    super(content);
  }

  /** returns the cell in the proper display format
   * @param width how wide the cell will be displayed
   * @return the contents of the cell, right-justified
   */
  public String getFormatted(int width) {
    return TextSpacer.right(super.getContent(), width);
  }
}
