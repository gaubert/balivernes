/*
 * RoiParams.java
 */
package  com.psr.rms.db;

import java.sql.*;
import java.util.*;


/**
 * This class wraps the GARDS_XE_PROC_PARAMS_TEMPLATE.
 *
 * @author  Pat Donohoe
 * @version 2.0, 11/30/00
 * @since   RMS4.0
 */
public class RoiParams {

  private double lcAbscissa;
  private int detectorId;
  private int roi;

  private int betaEcrOrder;
  private int gammaEcrOrder;

  private int compton;
  private int detBackUsed;
  private int gasBackUsed;

  public final static int USED    = 1;
  public final static int SKIPPED = 0;
  
  public final static int LINEAR    = 1;
  public final static int QUADRATIC = 2;
  public final static int MANUAL    = 3; 
 

  /**
   * Empty constructor
   */
  public RoiParams() {}


  /**
   * Construct an RoiParams from its constituent parts
   */
  public RoiParams(int dId, int r, double lc, int bOrder, int gOrder,
                   int comp, int det, int gas) {

    detectorId    = dId;
    roi           = r;
    lcAbscissa    = lc;
    betaEcrOrder  = bOrder;
    gammaEcrOrder = gOrder;
    compton       = comp;
    detBackUsed   = det;
    gasBackUsed   = gas;

  }
  

  /**
   * Construct an RoiParams from a specified roi number and detector. 
   * This will call the database to fill in the rest of the information.
   */
  public RoiParams(Connection conn, int detectorId, int rid) {

    this.detectorId = detectorId;
    roi             = rid;

    getRoiParams(conn, detectorId, roi);

  }


  /**
   *  Retrieve all gards_sample_xe_proc_params for a sample id.
   */

  public static RoiParams[] getSampleRoiParams(Connection conn,
                                               int sampleId,
                                               int detectorId) {

    RoiParams[] returnValue = new RoiParams[6];
    boolean     valid = false;   // indicates that we found RoiParams in DB

    String queryString =
      "SELECT lc_abscissa, beta_ecr_order, gamma_ecr_order, compton, " +
             "det_back_used, gas_back_used " +
      "FROM gards_sample_xe_proc_params " +
      "WHERE sample_id = " + sampleId + " " +
      "AND   roi = ?";

    try {

      PreparedStatement pstmt = conn.prepareStatement(queryString);

      for (int ii = 1; ii <= 6; ii++) {

        pstmt.setInt(1, ii);

        ResultSet rs = pstmt.executeQuery();
     
        while (rs.next()) {

          valid = true;

          RoiParams curRP = new RoiParams(detectorId, ii, rs.getDouble(1),
                                          rs.getInt(2), rs.getInt(3),
                                          rs.getInt(4), rs.getInt(5),
                                          rs.getInt(6));
          returnValue[ii - 1] = curRP;

        }

        rs.close();

      }

      pstmt.close();

    } catch (SQLException e) {

      returnValue = null;

      System.out.println("Failure on gards_xe_proc_params_template select");
      System.out.println("Exception = " + e);

    }

    if(valid == false)
      return null;

    return returnValue;

  }  


  /**
   * Insert an array of RoiParams for a particular sample into the database
   *
   * @param conn database connection
   * @param sampleId identification number of the sample to insert
   * @param roiParams array of RoiParams to be inserted
   */
  public static void insertRoiParams(Connection conn, int sampleId,
                                     RoiParams[] roiParams) {

    String queryString =
      "INSERT INTO gards_sample_xe_proc_params (sample_id, roi, " +
         "lc_abscissa, beta_ecr_order, gamma_ecr_order, compton, " +
         "det_back_used, gas_back_used) " +
      "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    int length = roiParams.length;

    for (int ii = 0; ii < length; ii++) {

      try {

        PreparedStatement pstmt = conn.prepareStatement(queryString);
        pstmt.setInt(1, sampleId);
        pstmt.setInt(2, roiParams[ii].getRoi());
        pstmt.setDouble(3, roiParams[ii].getLcAbscissa());
        pstmt.setInt(4, roiParams[ii].getBetaEcrOrder());
        pstmt.setInt(5, roiParams[ii].getGammaEcrOrder());
        pstmt.setInt(6, roiParams[ii].getCompton());
        pstmt.setInt(7, roiParams[ii].getDetBackUsed());
        pstmt.setInt(8, roiParams[ii].getGasBackUsed());

        pstmt.executeUpdate();
        pstmt.close();

      } catch (SQLException e) {

        System.out.println("Failure on gards_sample_xe_proc_params insert");
        System.out.println("Exception = " + e);

      }

    }

  }


  /**
   * Deletes all the rows for a particular sample in
   * gards_sample_xe_proc_params
   *
   * @param conn database connection
   * @param sampleId the id of the sample
   */
  public static void deleteRoiParamsTable(Connection conn, int sampleId) {

    String deleteString =
      "DELETE FROM gards_sample_xe_proc_params " +
      "WHERE sample_id = " + sampleId;

    try {

      Statement stmt = conn.createStatement();
      int catcher    = stmt.executeUpdate(deleteString);

      stmt.close();

    } catch (SQLException e) {

      System.out.println("Failure on gards_sample_xe_proc_params delete");
      System.out.println("Exception = " + e);

    }

  }


  /**
   * Returns the value of the Region of Interest of this parameter
   */
  public final int getRoi() {

    return roi;

  }


  /**
   * Returns the identification number of the detector
   */
  public final int getDetectorId() {

    return detectorId;

  }


  /**
   * Returns the value of the critical limit abscissa
   */
  public final double getLcAbscissa() {

    return lcAbscissa;

  }


  /**
   * Returns the order of the beta energy-to-channel ratio
   */
  public final int getBetaEcrOrder() {

    return betaEcrOrder;

  }


  /**
   * Returns the order of the gamma energy-to-channel ratio
   */
  public final int getGammaEcrOrder() {

    return gammaEcrOrder;

  }


  /**
   * Gets your number Straight Outta Compton
   */
  public final int getCompton() {

    return compton;

  }


  /**
   * Returns a 1 if the detector background was used in analysis, else 0
   */
  public final int getDetBackUsed() {

    return detBackUsed;

  }


  /**
   * Returns a 1 if the gas background was used in analysis, else 0
   */
  public final int getGasBackUsed() {

    return gasBackUsed;

  }


  /**
   * Sets the value of the Region of Interest of this parameter
   */
  public void setRoi(int newRoi) {

    roi = newRoi;

  }


  /**
   * Sets the identification number of the detector
   */
  public void setDetectorId(int detId) {

    detectorId = detId;

  }


  /**
   * Sets the value of the critical limit abscissa
   */
  public void setLcAbscissa(double newLc) {

    lcAbscissa = newLc;

  }


  /**
   * Sets the order of the beta energy-to-channel ratio
   */
  public void setBetaEcrOrder(int newBetaOrder) {

    if ((newBetaOrder >= 1) || (newBetaOrder <= 3)) {

      betaEcrOrder = newBetaOrder;

    }

  }


  /**
   * Sets the order of the gamma energy-to-channel ratio
   */
  public void setGammaEcrOrder(int newGammaOrder) {

    if ((newGammaOrder >= 1) || (newGammaOrder <= 3)) {

      gammaEcrOrder = newGammaOrder;

    }

  }


  /**
   * Sets the number of Compton channels
   */
  public void setCompton(int newCompton) {

    if ((newCompton >= 0) && (newCompton <= 5)) {
   
      compton = newCompton;

    }

  }


  /**
   * Sets a 1 if the detector background was used in analysis, else 0
   */
  public void setDetBackUsed(int detUsed) {

    if ((detUsed == 0) || (detUsed == 1)) {

      detBackUsed = detUsed;

    }

  }


  /**
   * Sets a 1 if the gas background was used in analysis, else 0
   */
  public void setGasBackUsed(int gasUsed) {

    if ((gasUsed == 0) || (gasUsed == 1)) {

      gasBackUsed = gasUsed;

    }

  }


  /**
   * Private function used by constructor.
   * If an error occurs, set roi number to 0.
   */
  private void getRoiParams(Connection conn, int detectorId, int rid) {

    String queryString =
      "SELECT lc_abscissa, beta_ecr_order, gamma_ecr_order, compton, " +
             "det_back_used, gas_back_used " +
      "FROM gards_xe_proc_params_template " +
      "WHERE detector_id = " + detectorId + " " +
      "AND   roi = " + rid;

    try {

      Statement stmt = conn.createStatement();
      ResultSet rs   = stmt.executeQuery(queryString);

      rs.next();
      lcAbscissa    = rs.getDouble(1);
      betaEcrOrder  = rs.getInt(2);
      gammaEcrOrder = rs.getInt(3);
      compton       = rs.getInt(4);
      detBackUsed   = rs.getInt(5);
      gasBackUsed   = rs.getInt(6);

      stmt.close();
      rs.close();

    } catch (SQLException e) {

      roi = 0;
      detectorId = 0;

      System.out.println("Failure on gards_xe_proc_params_template select");
      System.out.println("Exception = " + e);

    }
  }





}

