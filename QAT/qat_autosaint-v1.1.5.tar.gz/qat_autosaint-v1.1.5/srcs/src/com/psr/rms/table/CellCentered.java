/*
 * CellCentered.java
 *
 * Created on May 25, 2000, 3:55 PM
 */

package com.psr.rms.table;

/** a StringTable cell that displays its contents centered
 * @author Brett Pettigrew
 * @version 1.0
 */
public class CellCentered extends Cell {

  /** Creates a new CellCentered
   * @param content the contents of the cell
   */
  public CellCentered(String content) {
    super(content);
  }

  /** returns the cell in the proper display format
   * @param width how wide the cell will be displayed
   * @return the contents of the cell, centered
   */
  public String getFormatted(int width) {
    return TextSpacer.center(super.getContent(), width);
  }
}
