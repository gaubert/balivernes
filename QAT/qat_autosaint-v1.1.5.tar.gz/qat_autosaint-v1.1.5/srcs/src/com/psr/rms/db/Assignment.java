/*
 * Assignment.java
 */


package  com.psr.rms.db;

import java.sql.*;
import java.util.*;


public class Assignment
 {

   /**
    *  @param types   list of types querying for.   ie  char[] { 'B', 'P'} 
    */
    public static AssignmentTableModel getAssignedSamples(Connection conn,
                                                          int        userId,
                                                          int        roleId,
                                                          char[]     types)
     {
       AssignmentTableModel atm = new AssignmentTableModel();


       if(types.length == 0)
         return atm;

       StringBuffer typeList = new StringBuffer();
 
       boolean  firstTime = true;
       for(int i=0;i<types.length;i++)
        {
          if(firstTime == false)
           {
             typeList. append(",");
           }
          else
           {
             firstTime = false;
           }
          typeList. append("'");
          typeList. append(types[i]);
          typeList. append("'");
        }

     

       String  queryString = "select gards_sample_data.sample_id, " +
         " gards_sample_status.status, gards_stations.station_code,"+
         " gards_sample_status.auto_category, " + 
         " gards_sample_data.collect_stop, " +
         " gards_dist_sample_queue.user_id,   " +
         " gards_dist_sample_queue.role_id " +
         " from gards_sample_data, gards_sample_status, " +
         " gards_dist_sample_queue, gards_stations where " +
         " gards_dist_sample_queue.user_id = "+ userId + " and " +
         " gards_dist_sample_queue.role_id = "+ roleId + " and " +
         " gards_dist_sample_queue.sample_id = gards_sample_data.sample_id " +
         " and gards_sample_data.sample_type in (" + typeList.toString() +
         ")  and " +
         " gards_sample_data.station_id = gards_stations.station_id and " +
         " gards_sample_data.sample_id = gards_sample_status.sample_id ";

       try
        {
           Statement stmt = conn.createStatement();
           ResultSet rs = stmt.executeQuery(queryString);
           while(rs.next())
            {
              int sampleId = rs.getInt(1);

              String status = rs.getString(2);
              String stationCode = rs.getString(3);
              int autoCat = rs.getInt(4);
              Timestamp t = rs.getTimestamp(5);
              Calendar  collectStart;
              if(t == null)
               {
                 collectStart = null;
               }
              else
               {
                collectStart=new GregorianCalendar(TimeZone.getTimeZone("GMT"));
                collectStart.setTime(t);
               } 
              atm.addEntry(sampleId,collectStart,autoCat, stationCode, status);
            }

           stmt.close();
           rs.close();

        }
       catch(java.sql.SQLException  e)
        {
           System.out.println("getAssignedSamples error: " + e);
        }
       return atm;

     }
    /**
     *  Reassign sample id to a roleId.
     */
    public static void updateAssignment(Connection conn,
                                        int        sid,
                                        int        userId,
                                        int        roleId)
     {
       Statement   stmt;
       String      insertString;

       // Delete old assignment
       deleteAssignment(conn,sid);

       insertString = new String("insert into gards_dist_sample_queue " +
                      "(user_id, role_id, sample_id) values " +
                      " (" + userId + ", "+ roleId + ", " + sid + ")");
       try
        {
          stmt = conn.createStatement();
          int rc = stmt.executeUpdate(insertString);
          stmt.close();
        }
       catch(java.sql.SQLException e)
        {
          System.out.println("Error in Assignment " + e);
        }
     }

    /**
     *  Delete sample id from gards_dist_sample_queue
     */
    public static void deleteAssignment(Connection conn,
                                        int        sid)
     {
       Statement   stmt;
       String      deleteString;

       
       deleteString = new String("delete from gards_dist_sample_queue " +
                      " where sample_id = " + sid);

       try
        {
          stmt = conn.createStatement();
          int rc = stmt.executeUpdate(deleteString);
          stmt.close();
        }
       catch(java.sql.SQLException e)
        {
          System.out.println("Error in Assignment " + e);
        }
     }

}




