/**
 * DataLog.java
 * This class wraps the GARDS_DATA_LOG table
 */


package com.psr.rms.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;



public class DataLog {

  private int      stationId;
  private String   dataType;
  private Calendar dateReceived;
  private Calendar dtg;
  private int      msgId;
  private String   status;
  private int      fileSize;
  private int      auth;
  private int      sampleId;


  public DataLog() {}


  public DataLog(Connection dc, int sid) {

    Timestamp t;

    try {

      String queryString = "select station_id, data_type, date_received, " +
      "dtg, msg_id, status, file_size, auth, rms_id from " +
      "gards_data_log where rms_id = " + sid;

      Statement st = dc.createStatement();
      ResultSet rs = st.executeQuery(queryString);

      while (rs.next() == true) {

        sampleId = sid;
        stationId = rs.getInt(1);
        dataType  = rs.getString(2);
        
        t = (Timestamp) rs.getTimestamp(3);
        if (t == null) {

          dateReceived = null;

        } else {

          dateReceived = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
          dateReceived.setTime(t);

        }      

        t = (Timestamp) rs.getTimestamp(4);
        if (t == null) {

          dtg = null;

        } else {

          dtg = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
          dtg.setTime(t);

        }

        msgId    = rs.getInt(5);
        status   = rs.getString(6);
        fileSize = rs.getInt(7);
        auth     = rs.getInt(8);

      }

      st.close();
      rs.close();

    } catch (java.sql.SQLException e) {

      System.out.println("SQL Error: " + e);

    }

  }


  public final int getStationId() {

    return stationId;

  }

  
  public final String getDataType() {

    return dataType;

  }


  public final Calendar getDateReceived() {

    return dateReceived;

  }


  public final Calendar getDtg() {

    return dtg;

  }


  public final int getMsgId() {

    return msgId;

  }


  public final String getStatus() {

    return status;

  }


  public final int getFileSize() {

    return fileSize;

  }


  public final int getAuth() {
   
    return auth;

  }


  public final int getSampleId() {

    return sampleId;
  
  }



}    
