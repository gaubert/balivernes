

package  com.psr.rms.db;

import   java.util.ArrayList;
import   java.util.Calendar;
import   java.util.GregorianCalendar;
import   java.util.List;
import   java.util.TimeZone;
import   java.text.*;
import   java.sql.*;


/**
 *  Class that wraps gards_sample_description ( station comments).
 */
public class SampleDescription
 {
     private int                 sampleId = -1;
     private String              description= null;


    /**
     *  Create an empty comment.  Database write routines will be undefined
     *  until com.psr.rms.db.SampleDescription.set is called.
     *  @see com.psr.rms.db.SampleDescription#set
     */
     public SampleDescription(Connection conn, int sid)
      {
        readSampleDescription(conn, sid);
      } 

 
    /**
     *  Load in a comment from gards_comments and gards_user_comments with a 
     *  specified comment id.  The text will be loaded from gards_user_comments
     *  if comment_type is 'U', otherwise the text will be loaded from
     *  gards_comments_defs.
     *
     *  @see com.psr.xe.CommentDef
     *  @see com.psr.xe.CommentDefList
     *
     */
     public void readSampleDescription(Connection conn, int sid)
      {

         sampleId = sid;

         try
          {
            String  queryString = new String("select description " +
                    "from gards_sample_description where sample_id = " +
                     sampleId);

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(queryString);

            while(rs.next() == true)
             {
               description = rs.getString(1);
             }

            rs.close();
            stmt.close();
          }
         catch(java.sql.SQLException e)
          {
            System.out.println("Exception in Comment load:  " + e);
          }
      }


     public int getSampleId()
      {
        return sampleId;
      }

     public String getDescription()
      {
        return description;
      }

}
