

package  com.psr.rms.db;

import java.sql.*;
import java.text.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;


/**
 *  Class that wraps gards_comments with the addition of the text field from
 *  gards_user_comments or gards_comment_defs depending on type.
 *  If type is USERS_TYPE, then the text comes from gards_user_comments, 
 *  otherwise the text is taken from gards_comment_defs.
 *
 *  When comments are updated and written to the database, the old comment and
 *  id are deleted and a new comment is inserted.  This makes the code
 *  simpler and easier to implement. The implication is that you should not
 *  have any dependence on the comment id field from gards_comments or 
 *  gards_user_comments. 
 *
 *  Setting fields in Comment does not affect the database until
 *  commitToDB is called.
 *
 *
 *  Example:
 * <pre>
 *        Comment c;
 *        c.set(sampleId,
 *              -1,                      // no associated peak
 *             "PT-440",                 // radioactive pentium 440 
 *             "rmsman",
 *              new GregorianCalendar(),
 *             null,                     // User defined type
 *             "This is a test comment");
 *        System.out.println("Text is: " + c.getText());
 *        c.commitToDB();
 * </pre>
 */
public class Comment {

  private DateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
  private int commentId         = -1;
  private int peakId            = -1;
  private int sampleId          = -1;
  private String analyst        = null;
  private String nuclName       = null;

  private Calendar dtg;
  private String   text;
  private int      commentType;

  public static int USER_TYPE = 0;


  /**
   *  Create an empty comment.  Database write routines will be undefined
   *  until com.psr.xe.Comment.set is called.
   *  @see com.psr.xe.Comment#set
   */
  public Comment() {} 


  /**
   *  Create a comment.
   *  @param   cid    comment id.  This is a one-up number generated from DB
   *  @param   sid    sample id comment goes with.
   *  @param   nucl   nuclide name comment is associated with.  This will
   *                  be null for
   *                  general comments, or comments only associated with
   *                  peak ids
   *  @param   pid    peak id comment is associated with.  This will be null
   *                  for general
   *                  comments, or comments only associated with nuclides.
   *  @param   ana    Login name of analyst who created comment.
   *  @param   d      Date the comment was created.
   *  @param   t      Type of comment.  This is an integer.  Use USER_TYPE
   *                  for user defined types.
   *  @param   txt    comment text.  This is only used when type == USER_TYPE.
   */
  public Comment(int cid, int sid, String nucl, int pid, String ana,
                 Calendar d, int t, String txt) {

    sampleId    = sid;
    peakId      = pid;
    nuclName    = nucl;
    commentId   = cid;
    analyst     = ana;
    dtg         = d;
    commentType = t;
    text        = txt;

  } 


  /** 
   *  Returns true if this will have an entry in gards_user_comments
   *  As of R3, a comment is user defined if its type is the character 'U'.
   *  A user defined comment has a text entry in gards_user_comments, while
   *  a non-user defined comment has an entry in gards_comment_defs.
   *  @see com.psr.xe.Comment#setType
   *  @see com.psr.xe.Comment#setText
   *
   */
  public boolean isUserComment() {

    return (commentType == 0);

  }


  /**
   * Read in all comments for a sample id.
   */
  public static List readSampleComments(Connection conn, int sampleId) {

    Calendar dtg        = new GregorianCalendar();    
    int cid             = 0;
    java.util.List list = new ArrayList();
    
    try {
            
      String queryString = "select comment_id from gards_comments " +
                           "where sample_id = " + sampleId;
	
      Statement stmt = conn.createStatement();
      ResultSet rs   = stmt.executeQuery(queryString);
	
      while (rs.next() == true) {

	cid       = rs.getInt(1);
	Comment c = Comment.readComment(conn, cid);
	list.add(c);
	
      }
        
      rs.close();
      stmt.close();
	
    } catch (SQLException e) {
	
      System.out.println("Error in read sample comments " + e);
	
    }
      
    return list;
      
  }

 
  /**
   *  Load in a comment from gards_comments and gards_user_comments with a 
   *  specified comment id.  The text will be loaded from gards_user_comments
   *  if comment_type is 'U', otherwise the text will be loaded from
   *  gards_comments_defs.
   *
   *  @see com.psr.xe.CommentDef
   *  @see com.psr.xe.CommentDefList
   *
   */
  public static Comment readComment(Connection conn, int commentId) {

    Calendar dtg      = new GregorianCalendar();
    int      peakId   = 0;
    int      sampleId = 0;
    String   analyst  = "";
    String   nuclName = "";
    String   text     = "" ;
    int      type     = Comment.USER_TYPE;

    Timestamp t;

    try {

      String queryString = "select sample_id, nvl(peak_id,-1), " +
                           "nvl(nucl_name, ' '), analyst, dtg, " +
                           "comment_type from gards_comments " + 
                           "where comment_id = " +  commentId;

      Statement stmt = conn.createStatement();
      ResultSet rs   = stmt.executeQuery(queryString);

      while (rs.next() == true) {

        sampleId = rs.getInt(1);
        peakId   = rs.getInt(2);
        nuclName = rs.getString(3);
        analyst  = rs.getString(4);
        t        = (Timestamp) rs.getTimestamp(5);

        if (t == null) {

          dtg = null;

        } else {

          dtg = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
          dtg.setTime(t);

        }

        type = rs.getInt(6);

      }

      rs.close();
      stmt.close();

    } catch (SQLException e) {

      System.out.println("Exception in Comment load:  " + e);

    }

    if (type == Comment.USER_TYPE) {

      try {

        String queryString = "select comment_text from gards_user_comments "
                           + "where comment_id = " + commentId;

        Statement stmt = conn.createStatement();
        ResultSet rs   = stmt.executeQuery(queryString);

        while (rs.next() == true) {

          text = rs.getString(1);

        }

        rs.close();
        stmt.close();

      } catch (SQLException e) {

        System.out.println("Exception gards_user_comments:  " + e);

      }

    } else {

      try {

        String queryString = "select comment_text from gards_comments_defs " +
                             "where comment_type = '" + type + "'";

        Statement stmt = conn.createStatement();
        ResultSet rs   = stmt.executeQuery(queryString);

        while (rs.next() == true) {

          text = rs.getString(1);

        }

        rs.close();
        stmt.close();

      } catch (SQLException e) {

        System.out.println("Exception in gards_comments_defs:  " + e);

      }

    }

    Comment newComment = new Comment(commentId, sampleId, nuclName, peakId,
                                     analyst, dtg,type, text);
    return newComment; 

  }








  /**
   *  Get next unique comment id from sequence.  Return
   *  negative value for failure.
   */
  public static int  getNextCommentId(Connection conn)
   {

     int   commentId = -1;
     try 
      {
       
        Statement stmt = conn.createStatement();

        ResultSet rs   = stmt.executeQuery(
          "select gards_comments_seq.nextval from dual");

        while (rs.next() == true)
         {
          commentId = rs.getInt(1);

         }

        rs.close();
        stmt.close();

      }
     catch(SQLException e)
      {

        System.out.println("Error getting comment sequence value #1: " + e);

      }
     return commentId;

   }

  /** 
   * Insert comment into gards_comments and gards_user_comments
   * if type is 'U'
   * then also add an entry into gards_user_comments.
   */
  public void commitToDB(Connection conn) {

    int rc;

    int  commentId = getNextCommentId(conn);
    if(commentId <0)
     {
       return;
     }
    
    try {

      String updateString =
        "INSERT INTO gards_comments (sample_id, comment_id, analyst, " +
                                    "dtg, comment_type) " +
        "VALUES (" + sampleId + ", " + commentId + ", '" + analyst +
                "', to_date('" + dateFormat.format(dtg.getTime()) +
                "', 'YYYY.MM.DD HH24:MI:SS')" + ", '" + commentType + "')";

      Statement stmt = conn.createStatement();
      rc             = stmt.executeUpdate(updateString);

      if (peakId > 0) {

	updateString = "update gards_comments set peak_id = " + peakId +
                       " where comment_id = " + commentId;
	rc = stmt.executeUpdate(updateString);

      }

      if (nuclName != null) {

	updateString = "update gards_comments set nucl_name = '" + nuclName +
                       "' where comment_id = " + commentId;
	rc = stmt.executeUpdate(updateString);

      }

      if (isUserComment()) {

        PreparedStatement pstmt =
          conn.prepareStatement("insert into gards_user_comments " +
                                "(comment_id, sample_id, comment_text) " +
                                "values(?, ?, ?)");

        pstmt.setInt(1, commentId);
        pstmt.setInt(2, sampleId);
        pstmt.setString(3, text);
	pstmt.executeUpdate();
        pstmt.close();

      }

      stmt.close();
      conn.commit();

    } catch (SQLException e) {

      System.out.println("Error getting comment sequence value #2: " + e);
      return;

    } 

  }


  /**
   * Delete comment from gards_comments and gards_user_comments
   */
  public void deleteComment(int cid, Connection conn) {

    try {
 
      String deleteString = "delete from gards_comments where " +
                            "comment_id = " + cid;

      Statement st = conn.createStatement();
      st.executeUpdate(deleteString);
      st.close();
      conn.commit();

    } catch (SQLException e) {

      System.out.println("Error deleting comment: " + e);

    }

  }


  /**
   *  Set the fields for a comment.  If type is specified, then text should
   *  be set to null.  If text is specified, then type should be null.
   *  @param     sampleId   Sample id this comment belongs to.
   *  @param     peakId     Peak comment is associated with.  If this is <=0
   *                        then comment is not specific to a peak. 
   *  @param     nuclName   Name of nuclide this comment is associated with.
   *                        If this is null, then the comment is not
   *                        specific to a nuclide.
   *  @param     analyst    Name of analyst that created comment. This should
   *                        not be null.
   *  @param     date       Date the comment was created.
   *  @param     type       Type from gards_comments_defs.type.  For R3 this
   *                        is a String.  Set the to null if comment does not
   *                        originate from gards_user_comments. 
   *  @param     text       Comment text for gards_user_comments.
   *                        Only set this if type is user defined, otherwise
   *                        make this null.
   */
  public void set(Connection conn, int sampleId, int peakId, String nuclName,
                  String analyst, Calendar date, int type, String text) {

    this.sampleId = sampleId;
    this.peakId   = peakId;
    this.nuclName = nuclName;
    this.analyst  = analyst;
    this.dtg      = date;
    setCommentType(conn, type);

    if (isUserComment()) {

      this.text = text;

    }

  }


  public final boolean isGeneralComment()
   {
     if((peakId<0) &&
        (nuclName.equals(" ")))
      {
        return true;
      }
     return false;
   }
     
  public final int getSampleId() {

    return sampleId;

  }


  public final int getPeakId() {

    return peakId;

  }


  public void setPeakId(int pid) {

    peakId = pid;

  }


  public final String getNuclideName() {

    return nuclName;

  }


  public void setNuclideName(String n) {

    nuclName = n;

  }


  public final Calendar getDate() {

    return dtg;

  }


  public void setDate(Calendar c) {

    dtg = c;

  }


  public final String getText() {

    return text;

  }


  /**
   *  Set the text to for the comment.  If the comment is currently associated
   *  with a type from gards_comment_defs, then the type will be updated to
   *  an undefined type.
   *
   *  @see com.psr.xe.Comment.setType
   */
  public void setText(String t) {

    text = t;
    commentType = Comment.USER_TYPE;

  }


  /**
   *  Set the comment's text to correspond to an entry in gards_comment_defs.
   *  Calling this will erase any current text associated with the comment.
   *
   *  @see com.psr.xe.Comment.setText
   */
  public void setCommentType(Connection c, int t) {

    commentType = t;

    if (commentType == -1) {

      commentType = Comment.USER_TYPE;

    }
	
    // If the type is in gards_comments_defs, then load in text from table
    if (isUserComment() == false) {

      List commentDefList = CommentDef.getCommentDefs(c);
      CommentDef cd = CommentDef.get(commentDefList, commentType);
      this.text = cd.getText();

    }

  }


  public final int getCommentType() {

    return commentType;

  }


  public final String getAnalyst() {

    return analyst;

  }


  public final int getCommentId() {

    return commentId;

  }


  public String toString() {

    StringBuffer sb = new StringBuffer();

    sb.append("Sample id = "  + sampleId  + "\n");
    sb.append("peak id = "    + peakId    + "\n");
    sb.append("nuclide = "    + nuclName  + "\n");
    sb.append("comment id = " + commentId + "\n");
    sb.append("analyst = "    + analyst   + "\n");
    sb.append("type = "       + commentType + "\n");
    sb.append("text = "       + text      + "\n");
    sb.append("date = "       + dtg       + "\n");

    return new String(sb);

  }

}
