/* 
 * Notify.java
 */
package com.psr.rms.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;





/**
 *  This class wraps  the GARDS_NOTIFY table.
 */
public class Notify
 {


 /* Event types */
  public static String ALERT = "ALERT";
  public static String FISS_FOUND = "FISS_FOUND";
  public static String NIC_SIG5 = "NIC_SIG5";
  public static String QC_ERROR = "QC_ERROR";
  public static String QC_WARNING = "QC_WARNING";
  public static String RADOPSCAL = "RADOPSCAL";
  public static String RMS_ADMIN = "RMS_ADMIN";
  public static String QAT_EMAIL_LIST = "QAT_LIST";
  	

  private String   event;
  private String   emailAddr;
  private String   description;
  private int      pocId;      // point of contact


  public Notify(String   event,
                String   emailAddr,
                String   description,
                int      pocId)
   {
     this.event = event;
     this.emailAddr = emailAddr;
     this.description = description;
     this.pocId = pocId;
   }
 
  /**
   * Read List of GARDS_NOTIFY rows from DB. Only
   * currently active users are read returned.
   * @param  if eventType == null, then read all events
   *         otherwise read only selected events
   */
  public static List   getNotify(Connection conn, String eventType)
   {

    List     list = new ArrayList();  // List of return values
    String   event;
    String   emailAddr;
    String   description;
    int      pocId;      // point of contact

    try
     {

      String queryString;

      // Take note of the lovely spelling error (desciption )
      if(eventType == null)
       {
         queryString = "select event, email_addr, desciption, poc_id " +
                       " from gards_notify where DTG_END is null ";
       }
      else
       {
         queryString = "select event, email_addr, desciption, poc_id " +
                       " from gards_notify where DTG_END is null and " +
                       " EVENT = '" + eventType + "'";
       }
      


      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery(queryString);

      while (rs.next() == true)
       {

         event       = rs.getString(1);
         emailAddr   = rs.getString(2);
         description = rs.getString(3);
         pocId         = rs.getInt(4);

         Notify n = new Notify(event, emailAddr, description, pocId);

         list.add(n);

       }

      st.close();
      rs.close();

     }
    catch (Exception e) 
     {

      System.out.println("Error getting GARDS_NOTIFY " + e);
     }

    return list;
  }



  public String getEvent()
   {
    return event;
   }

  public String getEmailAddr()
   {
    return emailAddr;
   }


  public String getDescription() 
   {
     return description;
   }



  public int getPocId()
   {
     return pocId;
   }

}

