


package  com.psr.rms.db;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.*;


/**
 *  This class wraps  the GARDS_CODES table.
 *
 */
public class Codes
 {


    /** Status strings from DB */
    public static final String        STATUS   = "STATUS"; 
    public static final String        CATEGORY = "CATEGORY"; 
    public static final String        ALL      = null;


    private      String               type;
    private      String               code;
    private      String               description;



    public  Codes(String type, String code, String description)
     {
        this.type = type;
        this.code = code;
        this.description = description;
     }



    /**
     *  Returns a list of Codes.
     *  if codeType == null the retrieve all codes from DB.
     */
    public static List   getCodesByType(Connection  conn,
                                        String      codeType)
     {
       Statement   stmt;
       ResultSet   rs;
       String      queryString;
       List        l = new ArrayList(100);

       if(codeType == null)
        {
          queryString = new String("select type, code, description from " +
                      " gards_codes order by type");
        }
       else
        {
          queryString = new String("select type, code, description from " +
                      " gards_codes where type = '" + codeType +
                      "'");
   
        }
       try
        {
          stmt = conn.createStatement();
          rs = stmt.executeQuery(queryString);
          while(rs.next())
           {
              Codes  c = new Codes(rs.getString(1),
                                   rs.getString(2),
                                   rs.getString(3));
              l.add(c);
           }
   
          stmt.close();
          rs.close();     
 
        }
       catch(java.sql.SQLException e)
        {
          l = null;
        }
       return l;
     }

    /** Return the code */
    public final String  getCode()
     {
       return code;
     }

    /** Return the type*/
    public final String  getType()
     {
       return type;
     }

    /** Return the description */
    public final String  getDescription()
     {
       return description;
     }

}

