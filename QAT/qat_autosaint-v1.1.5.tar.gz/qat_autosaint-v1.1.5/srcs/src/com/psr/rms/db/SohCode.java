/*
 * SohCode.java
 */


package  com.psr.rms.db;

import java.sql.*;
import java.util.*;



/**
 *  This class encapsulates the GARDS_SOH_CODE table.  To read a specific
 *  Code from the database, use the constructor
 *
 *  <code>SohCode(DBConnection, String param)</code>
 *  or
 *  <code>SohCode(DBConnection, int param_code)</code>
 *
 *  To read all SohCode use the static function:
 *  
 *  <code>ArrayList  getSohCode(DBConnection)</code>
 *
 */
public class SohCode 
 {


    // Fields corresponding to columns in database.

    private      String      param;
    private      int         paramCode;
    private      String      paramDisplay;
    private      int         paramDisplayFlag;
    private      int         displayStation;
    private      int         displayDetector;
    private      String      unit;



    /**
     * Construct an SohCode from param.  This will query
     * the database for the rest of the data.
     */
    public SohCode(Connection  conn, String param) 
     {
        int    rc;

        this.param = param;
        rc = getSohCode(conn, param);

        if(rc != 0)
         {
           paramCode = -1;
         }
     }

/**
 *  Construct an SohCode with all of its data.
 */
    public  SohCode(int       paramCode,
                    String    param,
                    String    paramDisplay,
                    int       paramDisplayFlag,
                    int       displayStation, 
                    int       displayDetector,
                    String    unit)
     {
        this.paramCode = paramCode;
        this.param = param;
        this.paramDisplay = paramDisplay;
        this.paramDisplayFlag = paramDisplayFlag;
        this.displayStation = displayStation;
        this.displayDetector = displayDetector;
        this.unit = unit;

     }



    /**
     *  Read all gards_soh_code sorted by PARAM_DISPLAY.
     *
     *  @return   Returns an ArrayList of SohCode
     */
    public static ArrayList  getSohCode(Connection conn)
     {
        Statement    stmt;
        ResultSet    rs;
        String       queryString;
        SohCode      sohCode;
        ArrayList    list;

        try
         {
           list = new ArrayList();

           stmt  = conn.createStatement();

           queryString = "select param_code, param, param_display, " +
                         " param_display_flag, " +
                         " display_station, display_detector, unit " +
                         " from gards_soh_code " +
                         " order by PARAM_DISPLAY";

           stmt.executeQuery(queryString);


           rs = stmt.getResultSet();

           // Put returned data into ArrayList.
           while(rs.next())
            { 
              sohCode = new SohCode(
                          rs.getInt(1),     // param_code
                          rs.getString(2),  // param 
                          rs.getString(3),  // display
                          rs.getInt(4),     // flag
                          rs.getInt(5),     // station
                          rs.getInt(6),     // detector
                          rs.getString(7)); // unit

              list.add(sohCode);
            }

           rs.close();
           stmt.close();
         }
        catch(java.sql.SQLException e)
         {
           System.out.println("SohCode error: " + e);
           list = null;

         }

        return list;
     }


    /**
     *  Read one gards_roi_concs row for a specified sample id.
     *  @return  Returns a 0 on success or  a nonzero DB error code on failure.
     */
    public int getSohCode(Connection conn, String param)
     {
        Statement    stmt;
        ResultSet    rs;
        String       queryString;
        int          rc;

        rc = 0;
        try
         {

           stmt  = conn.createStatement();

           queryString = "select param, param_code,param_display, " +
                         " param_display_flag, " +
                         " display_station, display_detector, unit " +
                         " from gards_soh_code where param = " + param;

           stmt.executeQuery(queryString);


           rs = stmt.getResultSet();

           rs.next();

           param = rs.getString(1);
           paramCode = rs.getInt(2);
           paramDisplay = rs.getString(2);
           paramDisplayFlag  = rs.getInt(3);
           displayStation = rs.getInt(4);
           displayDetector = rs.getInt(5);
           unit = rs.getString(6);

           stmt.close();
           rs.close();
         }
        catch(java.sql.SQLException e)
         {
           rc = e.getErrorCode();  
         }

        return rc;
     }



    /** Get param*/
    public final String   getParam()
     {
        return param;
     }


    /** Get paramCode */
    public final int    getParamCode() 
     {
        return paramCode;
     }


    /** Get paramDisplay */
    public final String getParamDisplay()
     {
        return paramDisplay;
     }

    /** Get paramDisplayFlag */
    public final int getParamDisplayFlag()
     {
        return paramDisplayFlag;
     }



    /** Get displayStation */
    public final int getDisplayStation()
     {
        return displayStation;
     }

    /** Get displayDetector */
    public final int getDisplayDetector()
     {
        return displayDetector;
     }

    /** Get unit */
    public final String getUnit()
     {
        return unit;
     }

}

