/*
 * SampleRatio.java
 */


package  com.psr.rms.db;

import java.sql.*;
import java.util.*;



/**
 *  This class wraps  the GARDS_SAMPLE_RATIOS class
 *
 * @author  Pat Donohoe
 * @version 1.0, 11/30/00
 * @since   RMS4.0
 */
public class SampleRatio
 {

    private    int                     sampleId;
    private    String                  ratioId;
    private    int                     upperRoi;
    private    int                     lowerRoi;
    private    double                  countRatio;
    private    double                  countRatioErr;

    public     static String[]                RATIO = { 
                                     "None", "PB214_352:242",
                                     "PB214_352:80",
                                     "XE133-1_81:30",
                                     "XE133-2_81:30",
                                     "XE133-3_81:30" };


/**
 *  Construct an SampleRatio from a specified ratioId 
 */
  public SampleRatio(Connection conn, int sampleId, String ratioId)
     {

        this.sampleId= sampleId;
        this.ratioId = ratioId;
        getSampleRatio(conn,sampleId, ratioId);

     }



/**
 *  Load sample rataio for a given sample id and ratio
 */
    public void getSampleRatio(Connection  conn,int sampleId,  String ratioId)
     {
        Statement      stmt;
        ResultSet      rs;
        String         queryString;

        this.sampleId= sampleId;
        this.ratioId = ratioId;

        try
         {

           stmt  = conn.createStatement();
           queryString = "select UPPER_ROI_NUMBER,LOWER_ROI_NUMBER," +
                  " COUNT_RATIO,COUNT_RATIO_ERR " +
                  " from GARDS_SAMPLE_RATIOS where " +
                  "  sample_id = " + sampleId + " and RATIO_ID = '" +
                  ratioId + "'";


           stmt.executeQuery(queryString);
           rs = stmt.getResultSet();

           // Fill data in
           rs.next();
           upperRoi = rs.getInt(1);
           lowerRoi = rs.getInt(2);
           countRatio = rs.getDouble(3);
           countRatioErr = rs.getDouble(4);


           stmt.close();
           rs.close();

         }
        catch(java.sql.SQLException e)
         {
          sampleId = 0;
         }
 
     }



    /**
     * get sample id.
     */
    public final int  getSampleId()
     {
        return sampleId;
     }

    /**
     * get detector.
     */
    public final String getRatioId()
     {
        return ratioId;
     }

    /**
     * get upperRoi.
     */
    public final int getUpperRoi()
     {
        return upperRoi;
     }

    /**
     * get lowerRoi.
     */
    public final int getLowerRoi()
     {
        return lowerRoi;
     }

    /**
     * get countRatio.
     */
    public final double getCountRatio()
     {
        return countRatio;
     }
    /**
     * get countRatioErr.
     */
    public final double getCountRatioErr()
     {
        return countRatioErr;
     }

}

