/*
 * QatConfig.java
 * author  Mark Erickson
 * Date 04/03/02
 *
 */

package  com.psr.rms.db;

import java.sql.*;
import java.util.*;

/**
 *
 * This class provides utilities for the gards_qat_config table.  
 * Instances of this class are immutable because the set methods do not
 * update instance variables.  Instead they directly update the database.
 *
*/ 
public class QatConfig 
 {

   private    float  qTime;    // hours
   private    float  tTime;    // hours
   private    float  minTTime; // hours
   private    float  maxTTime; // hours
   private    boolean allowRelease;


   /**
    *  Constructor to initialize variables.  This does not make and database
    *  writes.
    */
   public  QatConfig(float  q_time,
                     float  t_time,
                     float  min_t_time,
                     float  max_t_time,
                     boolean allow_release)
    {
      this.qTime = q_time;
      this.tTime = t_time;
      this.minTTime = min_t_time;
      this.maxTTime = max_t_time;
      this.allowRelease = allow_release;
    }


   /**
    *
    * This class accesses the gards_qat_config table and retrieves table values
    * and places them in the private variables of this class
    *
    * @param   conn  An instance of a data base Connection
    *
   */ 
   public  QatConfig(Connection  conn)
    {
      try
       {
         String  queryString = 
                      "select q_time, t_time, min_t_time, max_t_time, " +
                      " allow_release " + 
                      "from gards_qat_config";
         Statement stmt = conn.createStatement();
         ResultSet  rs = stmt.executeQuery(queryString);
         while(rs.next())
          {
            qTime  = rs.getFloat(1);
            tTime = rs.getFloat(2);
            minTTime = rs.getFloat(3);
            maxTTime = rs.getFloat(4);
            allowRelease = (rs.getInt(5) == 1);
          }

         stmt.close();
         rs.close();

       }
      catch(java.sql.SQLException e)
       {
         System.out.println("error reading gards_qat_config  " + e);
         qTime  = -1; 
         tTime = -1; 
         minTTime = -1; 
         maxTTime = -1; 
         allowRelease = false;
       }

    }


   /**
    *
    * This method returns all the samples from gards_sample_status
    * where the review_date plus the q_time exceeds the current time
    * In other words those samples that have exceeded their q_time.
    *
    * @param   conn  An instance of a data base Connection
    * @param   qTime The q_time value
    *
    *
   */
   public  static List getSamplesForQRelease(Connection  conn,
                                             float       qTime)
    {

      ArrayList sampleList = new ArrayList();

      try
       {
         String  queryString =
                      "select sample_id from gards_sample_status " +
                      "where status = 'Q' " +
                      "and review_date + " + qTime/(24) + " < SYSDATE - (5/60/24)";
         /* NOTE: In the SQL query, the time added to the review_date  
          * must be represented as days. Since qTime is in hpurs, it
          * needs to be converted to days, thus the formula:
          * qTime/(24hrs in a day) */
         
         Statement stmt = conn.createStatement();
         ResultSet  rs = stmt.executeQuery(queryString);
         while(rs.next())
          {
             Integer sampleId = new Integer(rs.getInt(1));
             sampleList.add(sampleId);

          }

         stmt.close();
         rs.close();

       }
      catch(java.sql.SQLException e)
       {
         System.out.println("error reading gards_sample_status  " + e);
         sampleList =  null;
       }

     return(sampleList);

    }



   /**
    *
    * This method returns all the samples from gards_sample_status
    * where the entry_date plus the t_time exceeds the current time
    * In other words those samples that have exceeded their t_time.
    *
    * @param   conn  An instance of a data base Connection
    * @param   tTime The t_time value
    *
    *
   */
   public static List getSamplesForTRelease(Connection  conn,
                                            float       tTime)
    {

      ArrayList sampleList = new ArrayList();

      try
       {
         String  queryString =
                      "select sample_id from gards_sample_status " + 
                      "where status = 'T' " +
                      "and entry_date + " + tTime/(24) + " < SYSDATE " +
		      "and review_date < SYSDATE - (5/60/24)";
         /* NOTE: In the SQL query, the time added to the entry_date  
          * must be represented as days. Since tTime is in hours, it
          * needs to be converted to days, thus the formula:
          * tTime/(24hrs) */
 
         Statement stmt = conn.createStatement();
         ResultSet  rs = stmt.executeQuery(queryString);
         while(rs.next())
          {
             Integer sampleId = new Integer(rs.getInt(1));
             sampleList.add(sampleId);

          }

         stmt.close();
         rs.close();

       }
      catch(java.sql.SQLException e)
       {
         System.out.println("error reading gards_sample_status  " + e);
         sampleList =  null;
       }

     return(sampleList);

    }


   /**
    * This method returns all the samples from gards_sample_status
    * where the entry_date plus 24 hours exceeds the current time
    * and where the status is Q or T.
    *
    * @param   conn  An instance of a data base Connection
    * @param   eTime Number of minutes after entry_date sample must be released
    *
    */
   public static List getSamplesForQorT1DayRelease(Connection conn,
                                                   float      eTime)
   {

      ArrayList sampleList = new ArrayList();

      try
      {
         String queryString =
            "select sample_id from gards_sample_status " +
            "where ((status = 'Q') or (status = 'T'))" +
            "and (entry_date + " + (eTime/24.0) + ") < SYSDATE";

         /* NOTE: In the SQL query, the time added to the entry_date  
          * must be represented as days. Thus 24 hours is represented
          * as 1 day. */
         
         Statement stmt = conn.createStatement();
         ResultSet  rs = stmt.executeQuery(queryString);
         while(rs.next())
         {
             Integer sampleId = new Integer(rs.getInt(1));
             sampleList.add(sampleId);
         }

         rs.close();
         stmt.close();

       }
       catch(java.sql.SQLException e)
       {
          System.out.println("error reading gards_sample_status  " + e);
          sampleList =  null;
       }

       return(sampleList);

   } // end getSamplesForQorT1DayRelease


   /**
    * 
    *  Method that sets the q_time for the gards_qat_config table 
    *
    *  @param  conn  A data base connection
    *  @param  q_time The new float value for the q_time
    *
    */
   public static int setQTime(Connection  conn,
                              float       q_time)
    {

      Statement   stmt;
      String      updateString;
      int         rc = 0;

      try
       {
           updateString =
                      "update gards_qat_config " +
                      "set q_time = " + q_time;

           stmt = conn.createStatement();
           stmt.executeUpdate(updateString);
           stmt.close();
           conn.commit();

       }
      catch(java.sql.SQLException e)
       {
         System.out.println("error updating q_time in gards_qat_config  " + e);
         rc = -1;
       }

     return(rc);

    }


   /**
    * 
    *  Method that sets the t_time for the gards_qat_config table 
    *
    *  @param  conn  A data base connection
    *  @param  t_time The new float value for the t_time
    *  @param  min_t_time The new float value for the min_t_time
    *  @param  max_t_time The new float value for the max_t_time
    *
    */
   public static int setTTimes(Connection  conn,
                               float       t_time,
                               float       min_t_time,
                               float       max_t_time)
    {

      Statement   stmt;
      String      updateString;
      int         rc = 0;


      if((min_t_time > t_time) || (max_t_time < t_time))
        {
          rc = -1;
          return(rc);
        }

      try
       {
           updateString =
                      "update gards_qat_config " +
                      "set t_time = " + t_time + ", " + 
                      "min_t_time = " + min_t_time + ", " +
                      "max_t_time = " + max_t_time;

           stmt = conn.createStatement();
           stmt.executeUpdate(updateString);
           stmt.close();
           conn.commit();

       }
      catch(java.sql.SQLException e)
       {
         System.out.println("error updating t_time in gards_qat_config  " + e);
          rc = -1;
       }

     return(rc);

    }


   /**
    *
    *  Method that sets the allow_release for the gards_qat_config table
    *
    *  @param  conn  A data base connection
    *  @param  allow_release 
    *
    */
   public static int setAllowRelease(Connection  conn,
                                     boolean     allow_release)
    {

      Statement   stmt;
      String      updateString;
      int         ar = 0;
      int         rc = 0;

      if(allow_release == true)
        ar = 1;

      try
       {
           updateString =
                      "update gards_qat_config " +
                      "set allow_release = " + ar;

           stmt = conn.createStatement();
           stmt.executeUpdate(updateString);
           stmt.close();
           conn.commit();

       }
      catch(java.sql.SQLException e)
       {
         System.out.println("error set allow_release in gards_qat_config  "+e);
         rc = -1;
       }

     return(rc);

    }



   /**
    *  Method that retrieves the qTime from a QatConfig 
    *  @returns The q_time value from a row in the gards_qat_config table
    */
   public final float getQTime()
    {
      return qTime;
    }

   /**
    *  Method that retrieves the tTime from a QatConfig 
    *  @returns The t_time value from a row in the gards_qat_config table
    */
   public final float getTTime()
    {
      return tTime;
    }

   /**
    *  Method that retrieves the min_t_time from a QatConfig
    *  @returns The min_t_time value from a row in the gards_qat_config table
    */
   public final float getMinTTime()
    {
      return minTTime;
    }


   /**
    *  Method that retrieves the max_t_time from a QatConfig
    *  @returns The max_t_time value from a row in the gards_qat_config table
    */
   public final float getMaxTTime()
    {
      return maxTTime;
    }



    /**
     * Returns the indication of whether or not automatic sample
     * releasing should be allowed.
     *
     * @return Indication of whether or not automatic releasing
     * should be allowed.
     */
    public boolean allowRelease() {
      return allowRelease;
    } // end allowRelease

  }
