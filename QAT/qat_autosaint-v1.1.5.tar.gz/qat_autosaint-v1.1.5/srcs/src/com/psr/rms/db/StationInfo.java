/*
 * StationInfo.java
 *
 * Created on May 25, 2000, 10:36 AM
 * Brett Pettigrew, Pacific-Sierra Research
 */

package com.psr.rms.db;

import java.sql.*;
import java.util.*;


/**
 * Encapsulates a join on gards_sample_data, gards_stations, and
 * gards_detectors
 */
public class StationInfo {

  //from gards_stations
  private String stationCode;
  private String stationType;
  private String stationDescrip;
  
  //from gards_detectors
  private String detectorCode;
  private String detectorType;
  private String detectorDescrip;


  /**
   * instantiates a StationInfo object
   * @param conn databse connection
   * @param sid sample ID
   * @return a StationInfo with the appropriate information for the sample ID
   */
  public static StationInfo getInstance(Connection conn, int sid) {

    StationInfo si = new StationInfo();
    si.doQuery(conn, sid);
    return si;

  }


  private int doQuery(Connection conn, int sid) {

    int sampleId = sid;
    int rc = 0;

    ResultSet rs;
    Statement stmt;
    String from;
    String select;
    String where;

    try {

      stmt = conn.createStatement();

      select = "select gs.station_id, gs.station_code, gs.type, " + 
               "gs.description, gd.detector_id, gd.detector_code, " +
               "gd.type, gd.description, gsd.sample_id, gsd.station_id, " +
               "gsd.detector_id ";

      from = "from gards_stations gs, gards_detectors gd, " +
             "gards_sample_data gsd ";

      where = "where gsd.sample_id = " + sampleId + " and gsd.station_id " +
              "= gs.station_id " + " and gsd.detector_id = gd.detector_id";

      stmt.executeQuery(select + from + where);
      rs = stmt.getResultSet();
      rs.next();

      stationCode    = rs.getString(2);
      stationType    = rs.getString(3);
      stationDescrip = rs.getString(4);
      detectorCode   = rs.getString(6);
      detectorType   = rs.getString(7);

      if (detectorType == null) { 

        detectorType = "";

      }

      detectorDescrip = rs.getString(8);
      stmt.close();
      rs.close();

    } catch (java.sql.SQLException e) {

      rc = e.getErrorCode();

    }

    return rc;

  }


  /**
   * accesses the station code for this sample
   *
   * @return the code
   */
  public String getStationCode() {

    return stationCode;

  }


  /**
   * accesses the station type for this sample
   *
   * @return the type
   */
  public String getStationType() {

    return stationType;

  }


  /**
   * accesses the station description for this sample
   *
   * @return the description
   */
  public String getStationDescrip() {

    return stationDescrip;

  }


  /**
   * accesses the detector code for this sample
   *
   * @return the code
   */
  public String getDetectorCode() {

    return detectorCode;

  }


  /** 
   * accesses the detector type for this sample
   *
   * @return the type
   */
  public String getDetectorType() {

    return detectorType;

  }


  /**
   * accesses the detector description for this sample
   *
   * @return the decsription
   */
  public String getDetectorDescrip() {

    return detectorDescrip;

  }

}
