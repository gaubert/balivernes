/*
 * Fpe.java
 */

package com.psr.rms.db;

import java.sql.*;
import java.util.*;


/**
 *
 * Fpe.java
 * This class wraps the GARDS_FPE table.
 */
public class Fpe {

  private boolean valid = false;
  private Calendar dtg;
  private int fpId;
  private int revId;
  private int sampleId;

  
  public Fpe(Connection conn, int sid) {

    Timestamp t;
    sampleId = sid;

    try {

      String queryString = "select fpid, revid, dtg, sample_id " +
                           "from gards_fpe where sample_id = " + sampleId;

      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery(queryString);

      while (rs.next() == true) {

        fpId  = rs.getInt(1);
        revId = rs.getInt(2);
      
        t = (Timestamp) rs.getTimestamp(3);
        if (t == null)
         {

           dtg = null;

         }
        else
         {

           dtg = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
           dtg.setTime(t);

         }

        valid = true;

      }

     st.close();
     rs.close();
   
    } catch (Exception e) {

      System.out.println("Fpe Exception : " + e);

    }

  }  


  /**
   *  Insert a new entry into gards_fpe with a 1up revision
   *  @return 0 on success, non-zero on failure
   */
  public static int insertFpe(Connection    conn,
                               int           sampleId)
   {
    int numRows;  // inserted.  should be 1

    try
     {

      int      revId = 0;
      String   queryString = "select max(revid) " +
                           "from gards_fpe where sample_id = " + sampleId;

      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery(queryString);

      if(rs.next())
       {
        revId = rs.getInt(1);
       }
      else
       {
         revId = 0;
       }
      revId++;
 

      String insertString = "insert into gards_fpe (FPID, REVID, " +
                            " DTG, SAMPLE_ID )  values " +
                            " (GARDS_FPID_SEQ.nextval, " + revId + 
                            ", SYSDATE, " + sampleId +  ")";

      numRows = st.executeUpdate(insertString);
      st.close();
      rs.close();
   
     }
    catch (Exception e)
    {

      System.out.println("Fpe Exception on insert : " + e);
      numRows = 0;
    }
  
   if(numRows < 1) 
     return -1;

   return 0;

   }

  public int getSampleId() {

    return sampleId;

  }


  public int getFpId() {

    return fpId;

  }


  public int getRevId() {

    return revId;

  }


  public Calendar getDtg() {

    return dtg;

  }

 
  public boolean isValid() {

    return valid;

  }

}
