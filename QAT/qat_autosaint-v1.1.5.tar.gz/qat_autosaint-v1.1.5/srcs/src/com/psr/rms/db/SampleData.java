/*
 * SampleData.java
 */

package com.psr.rms.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

/**
 *  This class wraps  the GARDS_SAMPLE_DATA table.
 *
 * @author  Pat Donohoe
 * @version 1.0, 05/30/00
 * @since   RMS3.0
 */
public class SampleData
{
  private    int                     sampleId;
  private    int                     stationId;
  private    int                     detectorId;
  private    String                  inputFileName;
  private    String                  sampleType;
  private    String                  dataType;
  private    String                  geometry;
  private    String                  spectralQualifier;
  private    Calendar                collectStart;
  private    Calendar                collectStop;
  private    Calendar                acquisitionStart;
  private    Calendar                acquisitionStop;
  private    double                  acquisitionRealSec;
  private    double                  acquisitionLiveSec;
  private    double                  quantity;


  /**
   *   Read sample from DB.
   */
  public  SampleData(Connection conn, int sid) {

    sampleId = sid;
    getSampleData(conn, sid);

  }



  /**
   *   return input_file_name
   */
  public final String    getInputFileName()
  {
    return inputFileName;
  }

  /**
   *   return sample_id
   */
  public final int        getSampleId()
  {
    return sampleId;
  }

  /**
   *   return station_id
   */
  public final int        getStationId()
  {
    return stationId;
  }

  /**
   *   return detector_id
   */
  public final int        getDetectorId()
  {
    return detectorId;
  }

  /**
   *   return sample_type.  This is will be a "P" for particulate,
   *   a "G" for Lege gas, or a "B" for Beta-Gamma coicidence.
   */
  public String     getSampleType()
  {
    return sampleType;
  }

  /**
   *  Query DB for the single field sample_type
   *  @param      c     database connection
   *  @param      sid   sample id
   */
  public static String getSampleType(Connection c, int sid) {

    String      queryString;
    Statement   stmt;
    ResultSet   rs;
    String      sampleType;

    try
    {
      queryString = new String("select sample_type from " +
      " gards_sample_data where sample_id = " + sid);

      stmt = c.createStatement();
      rs = stmt.executeQuery(queryString);
      rs.next();

      sampleType = rs.getString(1);
      rs.close();
      stmt.close();
    }
    catch(java.sql.SQLException e)
    {
      System.out.println("error in getting sample Type: " + e);
      sampleType = null;
    }
    return sampleType;
  }


  /**
   *  Query DB for the single field data_type.  This will be a "B" for
   *  background, "C" for calibration, "D" for detector background,
   *  "Q" for quality control, and "S" for sample.
   */
  public String     getDataType()
  {
    return dataType;
  }

  /**
   *  Query DB for the single field SAMPLE_TYPE
   *  @param      c     database connection
   *  @param      sid   sample id
   */
  public static String getDataType(Connection  c, int sid) {

    String      queryString;
    Statement   stmt;
    ResultSet   rs;
    String      dataType;

    try
    {
      queryString = new String("select data_type from " +
      " gards_sample_data where sample_id = " + sid);

      stmt = c.createStatement();
      rs = stmt.executeQuery(queryString);
      rs.next();

      dataType = rs.getString(1);
      stmt.close();
      rs.close();

    }
    catch(java.sql.SQLException e)
    {
      System.out.println("error in getting sample Type: " + e);
      dataType = null;
    }
    return dataType;
  }

  /**
   *  return sample geometry.
   */
  public String     getGeometry()
  {
    return geometry;
  }

  /**
   *  return spectral_qualifier.  This will be "FULL" or "PREL" where
   *  PREL is for preliminary.
   */
  public String     getSpectralQualifier()
  {
    return spectralQualifier;
  }


  /**
   *  return collect start
   */
  public Calendar   getCollectStart()
  {
    return collectStart;
  }

  /**
   *  return collect stop
   */
  public Calendar   getCollectStop()
  {
    return collectStop;
  }



  /**
   *  return acquisition start
   */
  public Calendar   getAcquisitionStart()
  {
    return acquisitionStart;
  }

  /**
   *  return acquisition stop
   */
  public Calendar   getAcquisitionStop()
  {
    return acquisitionStop;
  }

  /**
   *  return sample decay time in seconds
   */
  public double getDecayTime()
  {
    double dt = 0.0;
    if((acquisitionStart != null) && (collectStop != null))
    {

      dt = (getAcquisitionStart().getTime().getTime() -
      getCollectStop().getTime().getTime())/1000.0;
    }
    return dt;
  }

  /**
   *  return sample collection time in seconds.
   */
  public double getSamplingTime()
  {
    double st = 0.0;
    if((collectStart != null) && (collectStop != null))
    {
      st = (getCollectStop().getTime().getTime() -
      getCollectStart().getTime().getTime())/1000.0;
    }
    return st;
  }

  /**
   *  return acquisition live time in seconds.
   */
  public double     getAcquisitionLiveSec()
  {
    return acquisitionLiveSec;
  }

  /**
   *  return acquisition time in seconds.
   */
  public double     getAcquisitionRealSec()
  {
    return acquisitionRealSec;
  }

  /**
   *  return quantity in Meters^3
   */
  public double     getQuantity()
  {
    return quantity;
  }


  /**
   *  load sample from a sample id
   */
  public void getSampleData(Connection conn, int sid) {

    Statement            stmt;
    ResultSet            rs;
    String               queryString;
    java.sql.Timestamp   t;

    sampleId = sid;

    try
    {

      queryString = new String("select station_id, detector_id," +
      " input_file_name, sample_type, data_type, geometry, " +
      " spectral_qualifier, collect_start, collect_stop, " +
      " acquisition_start, acquisition_stop, acquisition_real_sec,"+
      " acquisition_live_sec, quantity from " +
      " gards_sample_data where sample_id = " + sampleId);

      stmt = conn.createStatement();
      rs = stmt.executeQuery(queryString);
      rs.next();

      stationId = rs.getInt(1);
      detectorId = rs.getInt(2);
      inputFileName = rs.getString(3);
      sampleType = rs.getString(4);
      dataType = rs.getString(5);
      geometry = rs.getString(6);
      spectralQualifier = rs.getString(7);


      t = rs.getTimestamp(8);
      if(t == null)
      {
        collectStart = null;
      }
      else
      {
        collectStart=new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        collectStart.setTime(t);
      }

      t = rs.getTimestamp(9);
      if(t == null)
      {
        collectStop= null;
      }
      else
      {
        collectStop = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        collectStop.setTime(t);
      }

      t = rs.getTimestamp(10);
      if(t == null)
      {
        acquisitionStart = null;
      }
      else
      {
        acquisitionStart= new GregorianCalendar(
        TimeZone.getTimeZone("GMT"));
        acquisitionStart.setTime(t);
      }

      t = rs.getTimestamp(11);
      if(t == null)
      {
        acquisitionStop = null;
      }
      else
      {
        acquisitionStop= new GregorianCalendar(
        TimeZone.getTimeZone("GMT"));


        acquisitionStop.setTime(t);
      }

      acquisitionRealSec = rs.getDouble(12);
      acquisitionLiveSec = rs.getDouble(13);
      quantity = rs.getDouble(14);

      stmt.close();
      rs.close();

    }
    catch(Exception e)
    {
      System.out.println("Exception: " + e);
    }

  }


 /**
  *  Return the Most Recent Prior sample.
  *  Return 0 on failure.
  */
 public static int getMrpData (Connection conn, int sampleId)
  {

  int         rc;
  int         detId; 
  int         statId;
  Timestamp   curTime;
  ResultSet   rs;
  Statement   stmt;
  int         mrpSampleId = 0;  // The sample id we are looking for
  String      sampleType;
  String      dataType;

  String  queryString = "select gards_sample_data.station_id, " +
           " gards_sample_data.detector_id, " +
           " gards_sample_data.acquisition_start, " +
           " gards_sample_data.data_type, " +
           " gards_sample_data.sample_type " +
           " from gards_sample_data " +
           " where gards_sample_data.sample_id = " + sampleId; 

  try
   {
     stmt = conn.createStatement();
     rs = stmt.executeQuery(queryString);
     rs.next();
 
     statId = rs.getInt(1);
     detId = rs.getInt(2);
     curTime = rs.getTimestamp(3);
     dataType = rs.getString(4);
     sampleType = rs.getString(5);
     
     rs.close();
     stmt.close();


     queryString = "select gards_sample_data.sample_id from " +
          " gards_sample_data,gards_read_sample_status " +
          " where " +
          " gards_sample_data.sample_id = gards_read_sample_status.sample_id " +
          " and gards_sample_data.spectral_qualifier = 'FULL' " +
          " and gards_sample_data.sample_type = '" + sampleType + "' " +
          " and gards_sample_data.data_type  = '" + dataType + "' " +
          " and gards_sample_data.station_id =  ? " +
          " and gards_sample_data.detector_id = ? " +
          " and gards_sample_data.acquisition_start <  ? " +
          " and  gards_read_sample_status.status = 'R' " +
          " order by gards_sample_data.acquisition_start desc, " +
          "          gards_sample_data.sample_id desc ";



     PreparedStatement pstmt = conn.prepareStatement(queryString);

     pstmt.setInt(1, statId);
     pstmt.setInt(2, detId);
     pstmt.setTimestamp(3, curTime);

     rs = pstmt.executeQuery(); 

     rs.next();
     mrpSampleId = rs.getInt(1);

     rs.close();
     pstmt.close();

   }
  catch(java.sql.SQLException e)
   {
     System.out.println(e);
     return 0;
   } 
  return mrpSampleId;
}


 /**
  *  Return the Most Recent Prior sample sample
  *  that has a specified  gards_sample_cat record.
  *  Return 0 on failure.
  */
 public static int getMrpReviewData (Connection conn, int sampleId, String name)
  {

  int         rc;
  int         detId; 
  int         statId;
  Timestamp   curTime;
  ResultSet   rs;
  Statement   stmt;
  int         mrpSampleId = 0;  // The sample id we are looking for
  String      sampleType;
  String      dataType;

  String  queryString = "select gards_sample_data.station_id, " +
           " gards_sample_data.detector_id, " +
           " gards_sample_data.acquisition_start, " +
           " gards_sample_data.data_type, " +
           " gards_sample_data.sample_type " +
           " from gards_sample_data " +
           " where gards_sample_data.sample_id = " + sampleId; 

  try
   {
     stmt = conn.createStatement();
     rs = stmt.executeQuery(queryString);
     rs.next();
 
     statId = rs.getInt(1);
     detId = rs.getInt(2);
     curTime = rs.getTimestamp(3);
     dataType = rs.getString(4);
     sampleType = rs.getString(5);
     
     rs.close();
     stmt.close();


     queryString = "select gards_sample_data.sample_id from " +
          " gards_sample_data,gards_read_sample_status, " +
          " gards_sample_cat " +
          " where " +
          " gards_sample_data.sample_id = gards_read_sample_status.sample_id " +
          " and gards_sample_data.sample_id = gards_sample_cat.sample_id " +
          " and gards_sample_data.spectral_qualifier = 'FULL' " +
          " and gards_sample_data.sample_type = '" + sampleType + "' " +
          " and gards_sample_data.data_type  = '" + dataType + "' " +
          " and gards_sample_data.station_id =  ? " +
          " and gards_sample_data.detector_id = ? " +
          " and gards_sample_data.acquisition_start <  ? " +
          " and  gards_read_sample_status.status = 'R' " +
          " and  gards_sample_cat.name = '" + name + "' " + 
          " and  gards_sample_cat.hold = 0 " + 
          " order by gards_sample_data.acquisition_start desc, " +
          "          gards_sample_data.sample_id desc ";



     PreparedStatement pstmt = conn.prepareStatement(queryString);

     pstmt.setInt(1, statId);
     pstmt.setInt(2, detId);
     pstmt.setTimestamp(3, curTime);

     rs = pstmt.executeQuery(); 

     rs.next();
     mrpSampleId = rs.getInt(1);

     rs.close();
     pstmt.close();

   }
  catch(java.sql.SQLException e)
   {
     return 0;
   } 
  return mrpSampleId;
}


 /**
  *  Return the Most Recent Prior for BG sample.
  *  Return 0 on failure.
  */
 public static int getMrpBGData (Connection conn, int sampleId)
  {

  int         rc;
  int         detId; 
  int         statId;
  Timestamp   curTime;
  ResultSet   rs;
  Statement   stmt;
  int         mrpSampleId = -1;  // The sample id we are looking for

  String  queryString = "select gards_sample_data.station_id, " +
           " gards_sample_data.detector_id, " +
           " gards_sample_data.acquisition_start " +
           " from gards_sample_data " +
           " where gards_sample_data.sample_id = " + sampleId; 

  try
   {
     stmt = conn.createStatement();
     rs = stmt.executeQuery(queryString);
     rs.next();
 
     statId = rs.getInt(1);
     detId = rs.getInt(2);
     curTime = rs.getTimestamp(3);
     
     rs.close();
     stmt.close();


     queryString = "select gards_sample_data.sample_id from " +
          " gards_sample_data,gards_sample_status " +
          " where " +
          " gards_sample_data.sample_id = gards_sample_status.sample_id " +
          " and gards_sample_data.sample_type = 'B' " +
          " and gards_sample_data.data_type  = 'S' " +
          " and gards_sample_data.station_id =  ? " +
          " and gards_sample_data.detector_id = ? " +
          " and gards_sample_data.acquisition_start <  ? " +
          " and  gards_sample_status.status in ('P', 'R') " +
          " and  not(gards_sample_status.status = 'R' and category is null) "+
          " order by gards_sample_data.acquisition_start desc, " +
          "          gards_sample_data.sample_id desc ";




     PreparedStatement pstmt = conn.prepareStatement(queryString);

     pstmt.setInt(1, statId);
     pstmt.setInt(2, detId);
     pstmt.setTimestamp(3, curTime);

     rs = pstmt.executeQuery(); 

     rs.next();
     mrpSampleId = rs.getInt(1);

     rs.close();
     pstmt.close();

   }
  catch(java.sql.SQLException e)
   {
     System.out.println(e);
     return 0;
   } 
  return mrpSampleId;
}


 /**
  *  Generalized the Most Recent Prior
  *  Return 0 on failure.
  */
 public static int getMrpData (Connection  conn,
                               int         sampleId,
                               String      sampleType,
                               String      dataType)
  {

  int         rc;
  int         detId;
  int         statId;
  Timestamp   curTime;
  ResultSet   rs;
  Statement   stmt;
  int         mrpSampleId = -1;  // The sample id we are looking for

  String  queryString = "select gards_sample_data.station_id, " +
           " gards_sample_data.detector_id, " +
           " gards_sample_data.acquisition_start " +
           " from gards_sample_data " +
           " where gards_sample_data.sample_id = " + sampleId;

  try
   {
     stmt = conn.createStatement();
     rs = stmt.executeQuery(queryString);
     rs.next();

     statId = rs.getInt(1);
     detId = rs.getInt(2);
     curTime = rs.getTimestamp(3);

     rs.close();
     stmt.close();


     queryString = "select gards_sample_data.sample_id from " +
          " gards_sample_data,gards_sample_status " +
          " where " +
          " gards_sample_data.sample_id = gards_sample_status.sample_id " +
          " and gards_sample_data.sample_type = '" + sampleType + "' " +
          " and gards_sample_data.data_type  = '" + dataType + "' " +
          " and gards_sample_data.station_id =  ? " +
          " and gards_sample_data.detector_id = ? " +
          " and gards_sample_data.acquisition_start <  ? " +
          " and  gards_sample_status.status in ('P', 'R') " +
          " order by gards_sample_data.acquisition_start desc, " +
          "          gards_sample_data.sample_id desc ";




     PreparedStatement pstmt = conn.prepareStatement(queryString);

     pstmt.setInt(1, statId);
     pstmt.setInt(2, detId);
     pstmt.setTimestamp(3, curTime);

     rs = pstmt.executeQuery();


     rs = pstmt.executeQuery();

     rs.next();
     mrpSampleId = rs.getInt(1);

     rs.close();
     pstmt.close();

   }
  catch(java.sql.SQLException e)
   {
     System.out.println(e);
     return 0;
   }
  return mrpSampleId;
}




 /**
  *  Return the Most Recent Prior Detector Background for BG sample.
  *  Return a 0 on failure.
  */
 public static int getMrpDetBkData (Connection conn, int sample_id)
  {

  int         rc;
  int         detId; 
  int         statId;
  String      detbkId;
  Timestamp   curTime;
  ResultSet   rs;
  Statement   stmt;
  int         backSampleId = -1; // The background sample we are looking for

  String  queryString = "select gards_sample_data.station_id, " +
           " gards_sample_data.detector_id, " +
           " gards_sample_aux.bkgd_measurement_id, " +
           " gards_sample_data.acquisition_start " +
           " from gards_sample_aux, gards_sample_data " +
           " where gards_sample_aux.sample_id = " + sample_id + 
           " and gards_sample_data.sample_id = " + sample_id; 

  try
   {
     stmt = conn.createStatement();
     rs = stmt.executeQuery(queryString);
     rs.next();
 
     statId = rs.getInt(1);
     detId = rs.getInt(2);
     detbkId = rs.getString(3);
     curTime = rs.getTimestamp(4);
     
     rs.close();
     stmt.close();


     queryString = "select gards_sample_aux.sample_id from " +
          " gards_sample_aux,gards_sample_data,gards_sample_status " +
          " where gards_sample_aux.measurement_id = ? " +
          " and gards_sample_aux.sample_id = gards_sample_data.sample_id " +
          " and gards_sample_data.sample_id = gards_sample_status.sample_id " +
          " and gards_sample_data.sample_type = 'B' " +
          " and gards_sample_data.data_type  = 'D' " +
          " and gards_sample_data.station_id =  ? " +
          " and gards_sample_data.detector_id = ? " +
          " and gards_sample_data.acquisition_start <  ? " +
          " and  gards_sample_status.status in ('P', 'R') " +
          " order by gards_sample_data.acquisition_start desc, " +
          "          gards_sample_data.sample_id desc ";


     PreparedStatement pstmt = conn.prepareStatement(queryString);

     pstmt.setString(1, detbkId);
     pstmt.setInt(2, statId);
     pstmt.setInt(3, detId);
     pstmt.setTimestamp(4, curTime);

     rs = pstmt.executeQuery(); 

     rs.next();
     backSampleId = rs.getInt(1);

     rs.close();
     pstmt.close();

   }
  catch(java.sql.SQLException e)
   {
     System.out.println(e);
     return 0;
   } 
  return backSampleId;
}




 /**
  *  Return the Most Recent Prior Gas Background for BG sample.
  *  Return 0 on failure.
  */
 public static int getMrpGasBkData (Connection conn, int sample_id)
  {

  int         rc;
  int         detId; 
  int         statId;
  String      detbkId;
  Timestamp   curTime;
  ResultSet   rs;
  Statement   stmt;
  int         backSampleId = -1; // The background sample we are looking for
  

  String  queryString = "select gards_sample_data.station_id, " +
           " gards_sample_data.detector_id, " +
           " gards_sample_aux.gas_bkgd_measurement_id, " +
           " gards_sample_data.acquisition_start " +
           " from gards_sample_aux, gards_sample_data " +
           " where gards_sample_aux.sample_id = " + sample_id + 
           " and gards_sample_data.sample_id = " + sample_id; 

  try
   {
     stmt = conn.createStatement();
     rs = stmt.executeQuery(queryString);
     rs.next();
 
     statId = rs.getInt(1);
     detId = rs.getInt(2);
     detbkId = rs.getString(3);
     curTime = rs.getTimestamp(4);
     
     rs.close();
     stmt.close();



     queryString = "select gards_sample_aux.sample_id from " +
          " gards_sample_aux,gards_sample_data,gards_sample_status " +
          " where gards_sample_aux.measurement_id = ? " +
          " and gards_sample_aux.sample_id = gards_sample_data.sample_id " +
          " and gards_sample_data.sample_id = gards_sample_status.sample_id " +
          " and gards_sample_data.sample_type = 'B' " +
          " and gards_sample_data.data_type  = 'G' " +
          " and gards_sample_data.station_id =  ? " +
          " and gards_sample_data.detector_id = ? " +
          " and gards_sample_data.acquisition_start <  ? " +
          " and  gards_sample_status.status in ('P', 'R') " +
          " order by gards_sample_data.acquisition_start desc, " +
          "          gards_sample_data.sample_id desc ";



     PreparedStatement pstmt = conn.prepareStatement(queryString);

     pstmt.setString(1, detbkId);
     pstmt.setInt(2, statId);
     pstmt.setInt(3, detId);
     pstmt.setTimestamp(4, curTime);

     rs = pstmt.executeQuery(); 

     rs.next();
     backSampleId = rs.getInt(1);

     rs.close();
     pstmt.close();

   }
  catch(java.sql.SQLException e)
   {
     System.out.println(e);
     return 0;
   } 
  return backSampleId;
}

 


}

