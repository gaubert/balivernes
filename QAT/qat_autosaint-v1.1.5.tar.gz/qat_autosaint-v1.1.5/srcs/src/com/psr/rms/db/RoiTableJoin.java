/*
 * RoiTableJoin.java
 */

package  com.psr.rms.db;

import java.sql.*;
import java.util.*;



/**
 *  This class contains the table join of gards_roi_lib, gards_roi_concs,
 *  and gards_roi_counts.
 *
 *
 *
 */
public class RoiTableJoin
{


  // From gards_roi_lib
  private      int         roi;
  private      String      name;
  private      String      halflife;

  // From gards_roi_concs
  private      int         sampleId;
  private      double      activity;
  private      double      activErr;

  // From gards_roi_concs
  private      int         nidFlag;
  private      double      abundance;
  private      double      mda;

  // From gards_roi_channels
  private      double      betaChanStart;
  private      double      betaChanStop;
  private      double      gammaChanStart;
  private      double      gammaChanStop;

  // From gards_roi_limits
  private      double      gammaEnergyStart;
  private      double      gammaEnergyStop;
  private      double      betaEnergyStart;
  private      double      betaEnergyStop;

  // From gards_roi_counts
  private      double      gross;
  private      double      grossErr;
  private      double      compton;
  private      double      comptonErr;
  private      double      interference;
  private      double      interferenceErr;
  private      double      memory;
  private      double      memoryErr;
  private      double      detectorBack;
  private      double      detectorBackErr;
  private      double      net;
  private      double      netErr;
  private      double      lc;

  // From gards_bg_efficiency_pairs
  private      double      efficiency;


  /**
   */
  public RoiTableJoin()
  {
  }


  public RoiTableJoin(RoiLib roiLib, RoiConc roiConc, RoiCount roiCount,
                      RoiLimit roiLimit, RoiChannel roiChannel,
                      RoiEfficiency efficiencyPairs) {

    abundance = roiLib.getAbundance();
    halflife  = roiLib.getHalflife();;
    name      = roiLib.getName();
    roi       = roiLib.getRoi();

    activErr = roiConc.getActivErr();
    activity = roiConc.getActivity();
    nidFlag  = roiConc.getNidFlag();
    mda      = roiConc.getMda();
    sampleId = roiConc.getSampleId();

    betaChanStart  = roiChannel.getBetaChanStart();
    betaChanStop   = roiChannel.getBetaChanStop();
    gammaChanStart = roiChannel.getGammaChanStart();
    gammaChanStop  = roiChannel.getGammaChanStop();

    betaEnergyStart  = roiLimit.getBetaEnergyStart();
    betaEnergyStop   = roiLimit.getBetaEnergyStop();
    gammaEnergyStart = roiLimit.getGammaEnergyStart();
    gammaEnergyStop  = roiLimit.getGammaEnergyStop();

    compton         = roiCount.getCompton();
    comptonErr      = roiCount.getComptonErr();
    detectorBack    = roiCount.getDetectorBack();
    detectorBackErr = roiCount.getDetectorBackErr();
    gross           = roiCount.getGross();
    grossErr        = roiCount.getGrossErr();
    interference    = roiCount.getInterference();
    interferenceErr = roiCount.getInterferenceErr();
    lc              = roiCount.getLc();
    memory          = roiCount.getMemory();
    memoryErr       = roiCount.getMemoryErr();
    net             = roiCount.getNet();
    netErr          = roiCount.getNetErr();

    efficiency = efficiencyPairs.getEfficiency();

  }


  /**
   *  Read all gards_roi_concs rows for a specified sample id. The
   *  ROIs will be sorted by gards_roi_concs.roi.
   *
   *  @return   Returns an ArrayList of RoiTableJoins.
   */
  public static ArrayList getRoiTableJoin(Connection conn, int sid)
  {
    ArrayList    list;
    int          rc;

    list = new ArrayList();
    for(int i=0;i<6;i++)
    {
      RoiTableJoin  rtj = new RoiTableJoin();
      rc = rtj.getRoiTableJoin(conn, sid, i+1);
      if(rc == 0)
      {
        list.add(rtj);
      }
    }
    return list;
  }


  /**
   */
  public int  getRoiTableJoin(Connection      conn,
  int               sid,
  int               rid)
  {
    Statement    stmt;
    ResultSet    rs;
    String       queryString;
    RoiConc      r;
    int         rc;

    rc = 0;
    sampleId = sid;
    roi = rid;
    try
    {
      if(SampleData.getSampleType(conn, sid).equals("B"))
      {

        // Determine if we are sample of gas
        if (SampleData.getDataType(conn, sid).equals("S"))
        {
          stmt  = conn.createStatement();

          queryString = new String("select  "+
          " gards_roi_lib.name, " +
          " gards_roi_lib.halflife," +
          " gards_roi_lib.abundance, " +
          " b_chan_start," +
          " b_chan_stop,"+
          " g_chan_start, " +
          " g_chan_stop, " +
          " activity, " +
          " mda, " +
          " nid_flag, " +
          " gross,"+
          " net, " +
          " lc, " +
          " b_energy_start, " +
          " b_energy_stop, "+
          " g_energy_start, " +
          " g_energy_stop, " +
          " activ_err, " +
          " bg_efficiency, " +
          " compton,  " +
          " compton_err,  " +
          " interference, " +
          " interference_err, " +
          " memory, " +
          " memory_err, " +
          " detector_back, " +
          " detector_back_err, " +
          " net_err, " +
          " gross_err  " +
          " from gards_roi_lib, " +
                 " gards_roi_channels, gards_roi_concs, "+
                 " gards_roi_counts, gards_roi_limits," +
                 " gards_bg_efficiency_pairs " +
          " where  gards_roi_concs.sample_id = " + sampleId + " and " +
               " gards_roi_limits.sample_id = " + sampleId + " and " +
               " gards_roi_channels.sample_id = " + sampleId + " and " +
               " gards_roi_counts.sample_id = " + sampleId + " and " +
               " gards_bg_efficiency_pairs.sample_id = " + sampleId + " and " +
               " gards_roi_lib.roi = " + roi + " and "  +
               " gards_roi_limits.roi = " + roi + " and "  +
               " gards_roi_channels.roi = " + roi+ " and " +
               " gards_roi_counts.roi = " + roi + " and " +
               " gards_bg_efficiency_pairs.roi = " + roi + " and " +
               " gards_roi_concs.roi =  " + roi);

         rs = stmt.executeQuery(queryString);

          rs.next();
          name = rs.getString(1);
          halflife = rs.getString(2);
          abundance = rs.getDouble(3);
          betaChanStart = rs.getDouble(4);
          betaChanStop= rs.getDouble(5);
          gammaChanStart= rs.getDouble(6);
          gammaChanStop= rs.getDouble(7);
          activity = rs.getDouble(8);
          mda = rs.getDouble(9);
          nidFlag = rs.getInt(10);
          gross = rs.getDouble(11);
          net = rs.getDouble(12);
          lc = rs.getDouble(13);
          betaEnergyStart = rs.getDouble(14);
          betaEnergyStop= rs.getDouble(15);
          gammaEnergyStart = rs.getDouble(16);
          gammaEnergyStop= rs.getDouble(17);
          activErr = rs.getDouble(18);
          efficiency= rs.getDouble(19);
          compton= rs.getDouble(20);
          comptonErr = rs.getDouble(21);
          interference= rs.getDouble(22);
          interferenceErr= rs.getDouble(23);
          memory= rs.getDouble(24);
          memoryErr= rs.getDouble(25);
          detectorBack = rs.getDouble(26);
          detectorBackErr = rs.getDouble(27);
          netErr = rs.getDouble(28);
          grossErr = rs.getDouble(29);
 
          rs.close();
          stmt.close();
        }
        else
        {
          stmt  = conn.createStatement();

          queryString = new String("select  "+
          "gards_roi_lib.name, " +
          " gards_roi_lib.halflife," +
          " gards_roi_lib.abundance," +
          " b_chan_start," +
          " b_chan_stop,"+
          " g_chan_start," +
          " g_chan_stop," +
          "  gross,"+
          " net," +
          " lc, " +
          "  b_energy_start, "+
          " b_energy_stop,"+
          " g_energy_start,"+
          " g_energy_stop, " +
          " bg_efficiency," +
          " compton," +
          " compton_err," +
          " interference,"+
          " interference_err,"+
          "  memory," +
          "  memory_err," +
          " detector_back, " +
          " detector_back_err, " +
          " net_err, " +
          " gross_err " +
          " from gards_roi_lib, gards_roi_channels, "+
             " gards_roi_counts, gards_roi_limits, gards_bg_efficiency_pairs " +
          "where  gards_roi_limits.sample_id = " + sampleId + " and " +
              " gards_roi_channels.sample_id = " + sampleId + " and " +
              " gards_roi_counts.sample_id = " + sampleId + " and " +
              " gards_bg_efficiency_pairs.sample_id = " + sampleId + " and " +
              " gards_roi_lib.roi = " + roi + " and "  +
              " gards_roi_limits.roi = " + roi + " and "  +
              " gards_roi_channels.roi = " + roi+ " and " +
              " gards_roi_counts.roi = " + roi + " and " +
              " gards_bg_efficiency_pairs.roi = " + roi);

          rs = stmt.executeQuery(queryString);

          rs.next();

          name = rs.getString(1);
          halflife = rs.getString(2);
          abundance = rs.getDouble(3);
          betaChanStart = rs.getDouble(4);
          betaChanStop= rs.getDouble(5);
          gammaChanStart= rs.getDouble(6);
          gammaChanStop= rs.getDouble(7);
          gross = rs.getDouble(8);
          net = rs.getDouble(9);
          lc = rs.getDouble(10);
          betaEnergyStart = rs.getDouble(11);
          betaEnergyStop= rs.getDouble(12);
          gammaEnergyStart = rs.getDouble(13);
          gammaEnergyStop= rs.getDouble(14);
          efficiency= rs.getDouble(15);
          compton= rs.getDouble(16);
          comptonErr= rs.getDouble(17);
          interference= rs.getDouble(18);
          interferenceErr= rs.getDouble(19);
          memory= rs.getDouble(20);
          memoryErr= rs.getDouble(21);
          detectorBack = rs.getDouble(22);
          detectorBackErr = rs.getDouble(23);
          netErr = rs.getDouble(24);
          grossErr = rs.getDouble(25);

          activity = -1.0;
          activErr = -1.0;
          nidFlag = 0;
          mda = -1.0;

          rs.close();
          stmt.close();
        }
      }
      else
      {
        rc = -1;  // Replace this with an actual error code
      }
    }
    catch(java.sql.SQLException e)
    {
      rc = e.getErrorCode();
      System.out.println("RoiTableJoin Error: " + e + " " + rc);
    }

    return rc;
  }



  /** Get sample id for Roi */
  public final int    getSampleId()
  {
    return sampleId;
  }


  /** Get roi id for Roi */
  public final int    getRoi()
  {
    return roi;
  }

  /** Get name  for Roi */
  public final String    getName()
  {
    return name;
  }

  /** Get halflife  for Roi */
  public final String    getHalflife()
  {
    return halflife;
  }

  /** Get activity for Roi */
  public final double getActivity()
  {
    return activity;
  }

  /** Get activity error for Roi */
  public final double getActivityError()
  {
    return activErr;
  }
  
  /**Get abundance */
  public final double getAbundance()
  {
    return abundance;
  }

  /** Get Beta start channel */
  public final double getBetaChanStart()
  {
    return betaChanStart;
  }

  /** Get Beta end channel */
  public final double getBetaChanStop()
  {
    return betaChanStop;
  }

  /** Get Beta start energy */
  public final double getBetaEnergyStart()
  {
    return betaEnergyStart;
  }

  /** Get Beta end energy */
  public final double getBetaEnergyStop()
  {
    return betaEnergyStop;
  }

  /** Get Gamma start channel */
  public final double getGammaChanStart()
  {
    return gammaChanStart;
  }

  /** Get Gamma end channel */
  public final double getGammaChanStop()
  {
    return gammaChanStop;
  }

  /** Get Gamma start energy */
  public final double getGammaEnergyStart()
  {
    return gammaEnergyStart;
  }

  /** Get Gamma start end */
  public final double getGammaEnergyStop()
  {
    return gammaEnergyStop;
  }

  /** Get Mda for Roi */
  public final double getMda()
  {
    return mda;
  }

  /** Get nuclide identification flag for Roi */
  public final int    getNidFlag()
  {
    return nidFlag;
  }

  /** Get Gross counts */
  public final double   getGross()
  {
    return gross;
  }

  /** Get Error ( uncertainty ) in Gross counts */
  public final double   getGrossErr()
  {
    return grossErr;
  }

  /** Get Memory counts */
  public final double   getMemory()
  {
    return memory;
  }

  /** Get Memory error counts */
  public final double   getMemoryErr()
  {
    return memoryErr;
  }

  /** Get Compton counts */
  public final double   getCompton()
  {
    return compton;
  }

  /** Get Compton error counts */
  public final double   getComptonErr()
  {
    return comptonErr;
  }

  /** Get Interference counts */
  public final double   getInterference()
  {
    return interference;
  }

  /** Get Interference Error counts */
  public final double   getInterferenceErr()
  {
    return interferenceErr;
  }

  /** Get detector background counts */
  public final double   getDetectorBack()
  {
    return detectorBack;
  }

  /** Get detector background error counts */
  public final double   getDetectorBackErr()
  {
    return detectorBackErr;
  }

  /** Get Net counts */
  public final  double   getNet()
  {
    return net;
  }
  
  /** Get Net Error */
  public final  double   getNetErr()
  {
    return netErr;
  }

  /** Get Lc */
  public final double   getLc()
  {
    return lc;
  }

  /** Get Efficiency*/
  public final double   getEfficiency()
  {
    return efficiency;
  }

}

