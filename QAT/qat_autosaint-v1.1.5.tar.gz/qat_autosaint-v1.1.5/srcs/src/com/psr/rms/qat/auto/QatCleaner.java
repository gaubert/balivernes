package com.psr.rms.qat.auto;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Class providing features to clean the database once the releasse has been done by QAT.
 * Two actions are performed during the cleaning. delete the database (safe as we are in the transaction) 
 * and delete the file from the temp directory.
 * Note that I was forced to remove any 1.5 features and go back to the 1.4 dialect Buhh.
 * @author guillaume.aubert@ctbto.org
 *
 */
public class QatCleaner
{
	public class CleaningElement
	{
		int    m_SID;
		int    m_TypeID;
		File   m_File;
		
		public CleaningElement(int aSampleID,int aTypeID,File aFile)
		{
			m_SID       = aSampleID;
			m_TypeID    = aTypeID;
			m_File      = aFile;
		}

		public int getSID()
		{
			return m_SID;
		}

		public int getTypeID()
		{
			return m_TypeID;
		}

		public File getFile()
		{
			return m_File;
		}
	}
	
	private List                  m_ToClean;
	private Connection            m_DBConnection;

	/**
	 * Default constructor
	 */
	public QatCleaner(Connection c)
	{
		m_ToClean       = new ArrayList();
		m_DBConnection  = c;
	}
	
	public void addReportToClean(int aSampleID,int aTypeID,File aFile)
	{
		CleaningElement e = new CleaningElement(aSampleID,aTypeID,aFile);
		m_ToClean.add(e);
	}
	
	/**
	 * cleaning function.
	 * This clean the database to ensure that there will be no issue
	 * @throws SQLException 
	 */
	public void clean() throws SQLException
	{
		
		//System.out.println("Start cleaning process");
        
		// First pass delete everything for the DB
		Iterator iter = m_ToClean.iterator();
		
		//System.out.println("Cleaning database");
		
		while (iter.hasNext())
		{
			CleaningElement c = (CleaningElement) iter.next();
			
			this._cleanDatabase(c);
		}
		
		// No errors so start deleting files
		iter = m_ToClean.iterator();
			
		while (iter.hasNext())
		{
			CleaningElement c = (CleaningElement) iter.next();
				
			this._cleanFileSystem(c);
		}
		
	}
	
	private void _cleanDatabase(CleaningElement elem) throws SQLException
	{
		 int rc;
	     Statement stmt;
	     String    query;
		 try 
		 { 

		      stmt         = m_DBConnection.createStatement();
		      
		      query        = "delete from gards_product where sample_id=" + elem.getSID() + " and typeid = " + elem.getTypeID();
		      
		      //System.out.println("execute cleaning request: " + query);
		      
		      rc = stmt.executeUpdate(query);
		      
		      stmt.close();
		     
		  } 
		  catch (java.sql.SQLException e) 
		  {

		      System.out.println("Exception in FileProdcut.insertFileName() : " + e);
		      rc = e.getErrorCode();
		      System.out.println("error code " + e.getErrorCode());
		      throw e;
		   }
	}
	
	/** 
	 * delete files
	 * @param aFilePath the path pointing to the file to delete
	 */
	private void _cleanFileSystem(CleaningElement elem)
	{
		File f = elem.getFile();
		
		if (f.exists())
		{
			/*try
			{
				System.out.println("delete file: " + f.getCanonicalPath());
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}*/
		      
			f.delete();	
		}
	}
		
}
