/*
 * CellFactory.java
 *
 * Created on May 25, 2000, 11:39 AM
 */

package com.psr.rms.table;

/** a factory for instantiating the proper type of Cells for use in
 * a StringTable
 * @author Brett Pettigrew, Pacific-Sierra Research
 */
public class CellFactory {

  /** left-justified Cell constant */
  public static final int LEFT =0;
  
  /** centered Cell constant */
  public static final int CENTERED = 1;
  
  /** right-justified Cell constant */
  public static final int RIGHT = 2;
  
  /** repeated character-bar Cell constant */
  public static final int BAR = 3;
  
  /** centered-decimal Cell constant */
  public static final int DECIMAL = 4;

  /** Creates a new CellFactory */
  public CellFactory() {
  }

  /** manufactures a cell with the default justification
   * @param content the String contents of the Cell
   * @return the Cell
   */
  public static Cell getCell(String content) {
    return new CellLeft(content);
  }

  /** manufactures a cell with a specific justification
   * @return the Cell
   * @param content the String contents of the Cell
   * @param type the justification of the Cell
   */
  public static Cell getCell(String content, int type) {
    Cell tc;
    switch (type) {
      case 0:
      tc = new CellLeft(content);
      break;
      case 1:
      tc = new CellCentered(content);
      break;
      case 2:
      tc = new CellRight(content);
      break;
      case 3:
      tc = new CellBar(content);
      break;
      case 4:
      tc = new CellDecimal(content);
      break;
      default:
      tc = new CellLeft(content);
      break;
    }
    return tc;
  }
}
