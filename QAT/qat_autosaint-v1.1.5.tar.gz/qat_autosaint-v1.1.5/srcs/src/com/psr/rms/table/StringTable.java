/*
 * StringTable.java
 *
 * Created on May 25, 2000, 10:36 AM
 * Brett Pettigrew, Pacific-Sierra Research
 */

package com.psr.rms.table;

/** The StringTable class provides a table for the display of
 * elements.  The user can optionally fix a column at a specific
 * width.  All unfixed columns will expand or contract to reflect
 * the fixed column width(s).
 * @author Brett Pettigrew
 */
public class StringTable {

  private static final int UNFIXED = -1;  //flags an unfixed colum
  private static final String BLANK = "(empty)";  //put into empty cells

  private int    numRows;         //the number of rows in the table
  private int    numCols;         // how many cols of fiexed width
  private int    numColsUnfixed;  //how many columns of variable width
  private int    tableWidth;      //the character width of the table
  private int    unfixedWidth;    //width available for unfixed columns
  private int    margin;          //margin between columns
  private int[]  colWidths;       //indexes of unfixed columns
  private int    justification;   //standard justification of table
  private Cell[][]     table;      //the table itself
  private CellFactory  factory;   //produces the table cells






  /** Creates and initializes a new StringTable
   * @param rows number of rows in the table
   * @param cols number of columns in the table
   * @param width the number of characters wide the table is
   */
  public StringTable(int rows, int cols, int width) {
    int defaultMargin = 2;
    initTable(rows, cols, width, defaultMargin);
  }

  /** Creates and initializes a new StringTable
   * @param rows number of rows in the table
   * @param cols number of columns in the table
   * @param width the number of characters wide the table is
   * @param mgin the fixed margin between columns
   */
  public StringTable(int rows, int cols, int width, int mgin) {
    initTable(rows, cols, width, mgin);
  }

  /**
   * @param rows
   * @param cols
   * @param width
   * @param mgin
   */
  private void initTable(int rows,int cols,int width,int mgin) {
    //table dimensions
    numRows = rows;
    numCols = cols;
    numColsUnfixed = cols;

    //table formatting
    tableWidth = width;
    margin = mgin;
    unfixedWidth = width - (margin * (numCols - 1));
    colWidths = new int[numCols];
    for (int c=0; c<numCols; c++) {
      colWidths[c] = UNFIXED;
    }
    justification = CellFactory.LEFT;

    //the guts
    table = new Cell[numRows][numCols];
    factory = new CellFactory();
  }

  /** adds a cell to the table with the default justification
   * @param row the row index (starting at 0)
   * @param col the column index (starting at 0)
   * @param content the String contents of the cell
   */
  public void addCell(int row,int col,String content) {
    table[row][col] = factory.getCell(content, justification);
  }

  /** adds a cell to the table with a specific justification
   * @param row the row index (starting at 0)
   * @param col the column index (starting at 0)
   * @param content the String contents of the cell
   * @param type the justification of the cell from CellFactory
   */
  public void addCell(int row, int col, String content, int type) {
    table[row][col] = factory.getCell(content, type);
  }

  /** sets the default justification of the table
   * @param type the justification from CellFactory
   */
  public void setJustification(int type) {
    justification = type;
  }

  /** sets a column at a fixed width
   * @param col the column index
   * @param width the specific width
   */
  public void fixColumnWidth(int col,int width) {
    if (colWidths[col] == UNFIXED) {
      numColsUnfixed--;
      unfixedWidth -= width;
      colWidths[col] = width;
    }
    else {//need to re-fix column
      unfixedWidth -= (width - colWidths[col]);
      colWidths[col] = width;
    }
  }

  /** assembles the contents of the table into a String
   * @return the table
   */
 public String toString() {
    int uWidth = unfixedWidth / numColsUnfixed;
    StringBuffer buffer = new StringBuffer("");
 
    for (int r=0; r < numRows; r++) {
      for (int c=0; c < numCols; c++) {
        if (table[r][c] == null) {
          table [r][c] = factory.getCell(BLANK, justification);
        }
        if (colWidths[c] == UNFIXED) {
          buffer.append(table[r][c].getFormatted(uWidth));
        }
        else {
          buffer.append(table[r][c].getFormatted(colWidths[c]));
        }
        //add margin
        if(c < numCols) {
          buffer.append(TextSpacer.getSpaces(margin));
        }
      }
      buffer.append("\n");
    }
    return buffer.toString();
  }

}
