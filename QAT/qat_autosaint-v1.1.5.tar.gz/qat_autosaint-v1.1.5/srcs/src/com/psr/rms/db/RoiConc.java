/*
 * RoiConc.java
 */


package  com.psr.rms.db;

import java.sql.*;
import java.util.*;



/**
 *  This class encapsulates the GARDS_ROI_CONCS table.  To read a specific
 *  Roi from the database, use the constructor
 *
 *  <code>RoiConc(DBConnection, sample id, roi id)</code>
 *
 *  To read all RoiConcs for a sample use the static function:
 *  
 *  <code>ArrayList  getSampleRoiConcs(DBConnection, sample id)</code>
 *
 */
public class RoiConc
 {


    // Fields corresponding to columns in database. Note that the report_mda
    // is not used.
    private      int         sampleId;
    private      int         roi;
    private      double      activity;
    private      double      activErr;
    private      double      mda;
    private      int         nidFlag;



    /**
     * Construct an RoiConc from sample_id, roi number.  This will query
     * the database for the rest of the data.  If an error occurs,
     * the sampleId and roi will be reset to 0. 
     */
    public RoiConc(Connection  conn, int sid, int rid)
     {
        int    rc;

        sampleId = sid;
        roi = rid;
        rc = getRoiConc(conn, sampleId, roi);

        if(rc != 0)
         {
           sid = 0;
           roi = 0;
         }
     }

/**
 *  Construct an RoiConc will all of its data.
 */
    public  RoiConc(int      sid,
                     int      rid,
                     double   activ,
                     double   activ_err,
                     double   m,
                     int      n_flag)
     {
        sampleId = sid;
        roi = rid;
        activity = activ;
        activErr = activ_err;
        mda = m;
        nidFlag = n_flag;
     }



    /**
     *  Read all gards_roi_concs rows for a specified sample id. The
     *  ROIs will be sorted by gards_roi_concs.roi.
     *
     *  @return   Returns an ArrayList of RoiConcs.
     */
    public static ArrayList  getSampleRoiConcs(Connection conn, int   sid)
     {
        Statement    stmt;
        ResultSet    rs;
        String       queryString;
        RoiConc      r;
        ArrayList    list;

        try
         {
           list = new ArrayList();

           stmt  = conn.createStatement();

           queryString = "select roi, activity,activ_err,mda, " +
                         " nid_flag from gards_roi_concs where sample_id = " +
                         sid + " order by roi";

           stmt.executeQuery(queryString);


           rs = stmt.getResultSet();

           // Put returned data into ArrayList.
           while(rs.next())
            { 
              r = new RoiConc(
                          sid,
                          rs.getInt(1),
                          rs.getDouble(2),
                          rs.getDouble(3),
                          rs.getDouble(4),
                          rs.getInt(5));

              list.add(r);
            }

           rs.close();
           stmt.close();
         }
        catch(java.sql.SQLException e)
         {
           list = null;
         }

        return list;
     }


    /**
     *  Read one gards_roi_concs row for a specified sample id.
     *  @return  Returns a 0 on success or  a nonzero DB error code on failure.
     */
    public int getRoiConc(Connection conn, int sid, int rid) {

        Statement    stmt;
        ResultSet    rs;
        String       queryString;
        int          rc;

        rc = 0;
        try
         {

           stmt  = conn.createStatement();

           queryString = "select activity,activ_err,mda,nid_flag " +
                           " from gards_roi_concs where sample_id = " +
                             sid + " and roi = " + rid;

           stmt.executeQuery(queryString);


           rs = stmt.getResultSet();

           rs.next();
           sampleId = sid; 
           roi = rid;
           activity = rs.getDouble(1);
           activErr = rs.getDouble(2);
           mda = rs.getDouble(3);
           nidFlag = rs.getInt(4);

           stmt.close();
           rs.close();
         }
        catch(java.sql.SQLException e)
         {
           rc = e.getErrorCode();  
         }

        return rc;
     }


  /**
   * Insert an array of RoiConcs into the database
   *
   * @param conn database connection
   * @param roiConcs array of RoiConcs to be inserted
   */
  public static void insertRoiConcs(Connection conn, RoiConc[] roiConcs) {

    String queryString =
      "INSERT INTO gards_roi_concs (sample_id, roi, activity, activ_err, " +
        "mda, nid_flag)" +
      "VALUES (?, ?, ?, ?, ?, ?)";

    int length = roiConcs.length;

    for (int ii = 0; ii < length; ii++) {

      try {

        PreparedStatement pstmt = conn.prepareStatement(queryString);
        pstmt.setInt(1, roiConcs[ii].getSampleId());
        pstmt.setInt(2, roiConcs[ii].getRoi());
        pstmt.setDouble(3, roiConcs[ii].getActivity());
        pstmt.setDouble(4, roiConcs[ii].getActivErr());
        pstmt.setDouble(5, roiConcs[ii].getMda());
        pstmt.setInt(6, roiConcs[ii].getNidFlag());

        pstmt.executeUpdate();
        pstmt.close();

      } catch (SQLException e) {

        System.out.println("Failure to insert Roi Concs");
        System.out.println("Exception = " + e);

      }

    }

  }


  /**
   * Deletes all the rows for a particular sample in gards_roi_concs
   *
   * @param conn database connection
   * @param sampleId the id of the sample
   */
  public static void deleteRoiConcTable(Connection conn, int sampleId) {

    String deleteString =
      "DELETE FROM gards_roi_concs " +
      "WHERE sample_id = " + sampleId;

    try {

      Statement stmt = conn.createStatement();
      int catcher    = stmt.executeUpdate(deleteString);

      stmt.close();

    } catch (SQLException e) {

      System.out.println("Failure to delete Roi Concs");
      System.out.println("Exception = " + e);

    }

  }


    /** Get sample id for Roi */
    public final int    getSampleId()
     {
        return sampleId;
     }

    /** Set sample id for Roi */
    public void setSampleId(int sid)
     {
        sampleId = sid;
     }


    /** Get roi id for Roi */
    public final int    getRoi() 
     {
        return roi;
     }
    /** Set roi id for Roi */
    public void setRoi(int r) 
     {
        roi = r;
     }



    /** Get activity for Roi */
    public final double getActivity()
     {
        return activity;
     }

    /** Set activity for Roi */
    public void setActivity(double a )
     {
        activity = a;
     }

    /** Get activity error for Roi */
    public final double getActivErr()
     {
        return activErr;
     }

    /** Set activity error for Roi */
    public void setActivErr(double ae)
     {
        activErr = ae;
     }

    /** Get Mda for Roi */
    public final double getMda()
     {
        return mda;
     }

    /** Set Mda for Roi */
    public void setMda(double m)
     {
        mda = m;
     }

    /** Get nuclide identification flag for Roi */
    public final int    getNidFlag()
     {
        return nidFlag;
     }

    /** Set nuclide identification flag for Roi */
    public void  setNidFlag(int  nf)
     {
        nidFlag = nf;
     }

}

