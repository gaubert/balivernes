/*
 * CommentDefList.java
 */

package com.psr.rms.db;

import java.io.*;
import java.sql.*;
import java.util.*;


/**
 *  Class that wraps gards_comments_defs
 *  This class basically associates some identifier with a comment.
 */
public class CommentDefList {

  private List commentDefList;


  public CommentDefList() {}


  public CommentDefList(Connection conn) {

    setConnection(conn);

  } 


  /**
   * Specify the database connecion to use.  Calling this function removes
   * any entries from the current list and rereads values from 
   * gards_comment_defs. 
   */
  public void setConnection(Connection conn) {

    dbRead(conn);

  }


  /**
   *  Add a new CommentDef to list of comment defs.  This does not get written
   *  back to the database.
   */
  public void add(CommentDef cd) {

    commentDefList.add(cd);

  }


  /**
   * Load CommentDefList from database gards_comments_defs
   */
  public void dbRead(Connection conn) {

    CommentDef cd;

    try {
       
      commentDefList = new Vector(); 
      Statement stmt = conn.createStatement();
      ResultSet rs = stmt.executeQuery("select comment_type, comment_text " +
                                       "from gards_comments_defs order by " +
                                       "comment_type");

      while (rs.next() == true) {

        cd = new CommentDef(rs.getInt(1), rs.getString(2));
        commentDefList.add(cd);

      }
  
      stmt.close();
      rs.close();

    } catch (java.sql.SQLException e) {

      System.out.println("Exception in Comment load:  " + e);

    }

  }


  public Iterator iterator() {

    return commentDefList.iterator();

  }


  /**
   * Return the CommentDef with the specified type.  If the type does not
   * exist in the list, then null is returned.
   */
  public CommentDef getFromCommentType(int type) {

    for (int i = 0;i < commentDefList.size(); i++) {

      CommentDef cd = (CommentDef) commentDefList.get(i);
      if (cd.getType() == type) {

        return cd;

      }

    }

    return null;

  }


  /**
   * Return the CommentDef specified by the index number
   */
  public CommentDef getFromCommentId(int index) {

    if ((index < 0) || (index >= commentDefList.size())) {

      return null;

    }

    return (CommentDef) commentDefList.get(index);

  }


  /**
   * Return the number of CommentDefs in the list.
   */
  public int size() {

    return commentDefList.size();

  }

}



