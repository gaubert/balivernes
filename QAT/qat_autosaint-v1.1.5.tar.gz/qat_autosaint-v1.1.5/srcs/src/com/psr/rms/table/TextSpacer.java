/*
 * TextSpacer.java
 *
 * Created on May 25, 2000, 10:36 AM
 * Brett Pettigrew, Pacific-Sierra Research
 */

package com.psr.rms.table;

import java.io.*;
import java.lang.*;
import java.util.StringTokenizer;


/** formats Strings for display at particular widths
 * @author Brett Pettigrew
 */
public class TextSpacer {
  /** returns a String containing the "centered" text
   * @param text the text to be centered
   * @param width the width of the output String
   * @return the properly formatted text
   */
  public static String center(String text,int width) {
    String leftMargin = getSpaces((width - text.length())/2);
    String rightMargin = getSpaces(width - leftMargin.length() - text.length());
    return leftMargin + text + rightMargin;
  }

  /** returns a String containing the "left-justified" text
   * @param text the text to be left-justified
   * @param width the width of the output <CODE>String</CODE>
   * @return the properly formatted text
   */
  public static String left(String text,int width) {
    String rightMargin = getSpaces(width - text.length());
    return text + rightMargin;
  }

  /** returns a String containing the "right-justified" text
   * @param text the text to be right-justified
   * @param width the width of the output <CODE>String</CODE>
   * @return the properly formatted text
   */
  public static String right(String text,int width) {
    String leftMargin = getSpaces(width - text.length());
    return leftMargin + text;
  }

  /** wraps text to a particular width for display
   * @param text the text to be wrapped
   * @param width the width at which the text should be wrapped
   * @return the wrapped text
   */
  public static String wrap(String text,int width) {
    StringTokenizer st = new StringTokenizer(text);
    String out = "";        //the String to return
    int lineLength = 0;    //length of the current line
    String s;               //the current String

    while (st.hasMoreTokens()) {
      s = st.nextToken() + " ";

      if ((s.length() + lineLength) >= width) {
        out += "\n";
        lineLength = 0;
      }

      out += s;
      lineLength += s.length();
    }
    return out;
  }

  /** creates a section title bar of the specified text and a bar of "==="
   * @param text the title text
   * @param width the width of the title bar
   * @return the properly formatted title bar
   */
  public static String getSectionTitle(String text,int width) {
    return text + getChars(width-text.length(), '=') + "\n\n";
  }

  /** returns the specified text underlined by "---"
   * @param text the subtitle text
   * @return the properly formatted subtitle
   */
  public static String getSubTitle(String text) {
    return text + "\n" + getChars(text.length(), '-') + "\n";
  }

  /** returns a <CODE>String</CODE> of spaces of the specified width
   * @param howMany how many many spaces
   * @return a <CODE>String</CODE> of the spaces
   */
  public static String getSpaces(int howMany) {
    return getChars(howMany, ' ');
  }

  /** returns a <CODE>String</CODE> of a repeated character of the specified width
   * @param howMany how many of the characters to return
   * @param c the character
   * @return a <CODE>String</CODE> containing the characters
   */
  public static String getChars(int howMany,char c) {
    if(howMany <= 0){
      return "";
    }

    char[] spacesArray = new char[howMany];

    for (int k=0; k<howMany; k++)
    spacesArray[k] = c;

    return new String(spacesArray);
  }
}
