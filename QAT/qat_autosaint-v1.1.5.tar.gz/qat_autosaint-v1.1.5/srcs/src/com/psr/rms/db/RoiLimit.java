/*
 * RoiLimit.java
 */


package  com.psr.rms.db;

import java.sql.*;
import java.util.*;



/**
 *  This class encapsulates the GARDS_ROI_LIMITS table.  To read a specific
 *  Roi from the database, use the constructor
 *
 *  <code>RoiLimit(DBConnection, sample id, roi id)</code>
 *
 *  To read all RoiLimit for a sample use the static function:
 *  
 *  <code>ArrayList  getSampleRoiLimit (DBConnection, sample id)</code>
 *
 */
public class RoiLimit
 {

    private      int         sampleId;
    private      int         roi;
    private      double      betaEnergyStart;
    private      double      betaEnergyStop;
    private      double      gammaEnergyStart;
    private      double      gammaEnergyStop;


    /**
     * Construct an RoiLimit from sample_id, roi number.  This will query
     * the database for the rest of the data.  If an error occurs,
     * the sampleId and roi will be reset to 0. 
     */
    public RoiLimit(Connection  conn, int sid, int rid)
     {
        int    rc;

        sampleId = sid;
        roi = rid;
        rc = getRoiLimit(conn, sampleId, roi);

        if(rc != 0)
         {
           sid = 0;
           roi = 0;
         }
     }

/**
 *  Construct an RoiLimit will all of its data.
 */
    public  RoiLimit(int      sid,
                     int      rid,
                     double   gstart,
                     double   gstop,
                     double   bstart,
                     double   bstop)
     {
        sampleId = sid;
        roi = rid;
        betaEnergyStart= bstart;
        betaEnergyStop = bstop;
        gammaEnergyStart= gstart;
        gammaEnergyStop = gstop;
     }



    /**
     *  Read all gards_roi_limit rows for a specified sample id. The
     *  ROIs will be sorted by roi
     *
     *  @return   Returns an ArrayList of RoiLimit.
     */
    public static ArrayList  getSampleRoiLimit(Connection conn, int   sid)
     {
        Statement    stmt;
        ResultSet    rs;
        String       queryString;
        RoiLimit     r;
        ArrayList    list;

        try
         {
           list = new ArrayList();

           stmt  = conn.createStatement();

           queryString = "select roi, g_energy_start,g_energy_stop, " +
                         " b_energy_start, b_energy_stop " +
                         " from gards_roi_limits where sample_id = " +
                         sid + " order by roi";

           stmt.executeQuery(queryString);


           rs = stmt.getResultSet();

           // Put returned data into ArrayList.
           while(rs.next())
            { 
              r = new RoiLimit(
                          sid,
                          rs.getInt(1),
                          rs.getDouble(2),
                          rs.getDouble(3),
                          rs.getDouble(4),
                          rs.getDouble(5));

              list.add(r);
            }

           rs.close();
           stmt.close();
         }
        catch(java.sql.SQLException e)
         {
           list = null;
         }

        return list;
     }


    /**
     *  Read one gards_roi_limits row for a specified sample id.
     *  @return  Returns a 0 on success or  a nonzero DB error code on failure.
     */
    public int getRoiLimit(Connection conn, int sid, int rid) {

        Statement    stmt;
        ResultSet    rs;
        String       queryString;
        int          rc;

        rc = 0;
        try
         {

           stmt  = conn.createStatement();

           queryString = "select  g_energy_start,g_energy_stop, " +
                         " b_energy_start, b_energy_stop " +
                           " from gards_roi_limits where sample_id = " +
                             sid + " and roi = " + rid;

           stmt.executeQuery(queryString);


           rs = stmt.getResultSet();

           rs.next();
           sampleId = sid; 
           roi = rid;
           gammaEnergyStart = rs.getDouble(1);
           gammaEnergyStop = rs.getDouble(2);
           betaEnergyStart = rs.getDouble(3);
           betaEnergyStop = rs.getDouble(4);

           stmt.close();
           rs.close();
         }
        catch(java.sql.SQLException e)
         {
           rc = e.getErrorCode();  
         }

        return rc;
     }



    /** Get sample id for Roi */
    public final int    getSampleId()
     {
        return sampleId;
     }

    /** Set sample id for Roi */
    public void setSampleId(int sid)
     {
        sampleId = sid;
     }


    /** Get roi id for Roi */
    public final int    getRoi() 
     {
        return roi;
     }
    /** Set roi id for Roi */
    public void setRoi(int r) 
     {
        roi = r;
     }



    /** Get Gamma Start for Roi */
    public final double getGammaEnergyStart()
     {
        return gammaEnergyStart;
     }

    /** Set Gamma Start for Roi */
    public void setGammaEnergyStart(double a )
     {
        gammaEnergyStart = a;
     }

    /** Get Gamma Stop for Roi */
    public final double getGammaEnergyStop()
     {
        return gammaEnergyStop;
     }

    /** Set Gamma Stop for Roi */
    public void setGammaEnergyStop(double ae)
     {
        gammaEnergyStop = ae;
     }


    /** Get Beta Start for Roi */
    public final double getBetaEnergyStart()
     {
        return betaEnergyStart;
     }

    /** Set Beta Start for Roi */
    public void setBetaEnergyStart(double a )
     {
        betaEnergyStart = a;
     }

    /** Get Beta Stop for Roi */
    public final double getBetaEnergyStop()
     {
        return betaEnergyStop;
     }

    /** Set Beta Stop for Roi */
    public void setBetaEnergyStop(double ae)
     {
        betaEnergyStop = ae;
     }


}

