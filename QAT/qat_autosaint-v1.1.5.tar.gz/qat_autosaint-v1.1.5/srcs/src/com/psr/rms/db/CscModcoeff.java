/*
 * CscModcoeff.java
 */

package com.psr.rms.db;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;



/**
 *  This class wraps  the GARDS_CSC_MODCOEFF table
 */
public class CscModcoeff
 {


    private    int                     detectorId;
    private    String                  detectorCode;
    private    String                  name;
    private    String                  daughter;
    private    double                  energy;
    private    double                  abundance;
    private    double                  abundanceApp;
    private    double                  abundanceAppErr;
    private    double                  cscRatio;
    private    double                  cscRatioErr;

    public  CscModcoeff(int          detectorId, 
                        String       detectorCode,
                        String       name,
                        String       daughter,
                        double       energy,
                        double       abundance,
                        double       abundanceApp,
                        double       abundanceAppErr,
                        double       cscRatio,
                        double       cscRatioErr)
     {
        this.detectorId = detectorId;
        this.detectorCode = detectorCode;
        this.name = name;
        this.daughter = daughter;
        this.energy = energy;
        this.abundance = abundance;
        this.abundanceApp = abundanceApp;
        this.abundanceAppErr = abundanceAppErr;
        this.cscRatio = cscRatio;
        this.cscRatioErr = cscRatioErr;
     }




/**
 *   Read all CscModcoeffs from database;  sort by detector code, name, energy
 *   return null on error
 */
    public static int insertDB(Connection conn, CscModcoeff c)
     {

        int      status = 0;

        String   insertStmt = "insert into gards_csc_modcoeff_lib( " +
                       " detector_id, name, name_d, energy, " +
                       " abundance, app_abundance, app_abundance_err, " +
                       " csc_ratio, csc_ratio_err) values  " +
                       " (?,?,?,?,?,?,?,?,?) ";


        try
         {

          PreparedStatement pstmt = conn.prepareStatement(insertStmt);

          pstmt.setInt(1, c.getDetectorId());
          
          if(c.getName() != null)
           {           
             pstmt.setString(2, c.getName());
           }
          else
           {
             pstmt.setNull(2, java.sql.Types.VARCHAR);
           } 

          if(c.getDaughter() != null)
           {           
             pstmt.setString(3, c.getDaughter());
           }
          else
           {
             pstmt.setNull(3, java.sql.Types.VARCHAR);
           } 

          pstmt.setDouble(4, c.getEnergy());


          if(Double.isNaN(c.getAbundance()) == false)
           {
             pstmt.setDouble(5, c.getAbundance());
           }
          else
           {
             pstmt.setNull(5, java.sql.Types.NUMERIC);
           } 

          if(Double.isNaN(c.getAbundanceApp()) == false)
           {
             pstmt.setDouble(6, c.getAbundanceApp());
           }
          else
           {
             pstmt.setNull(6, java.sql.Types.NUMERIC);
           } 

          if(Double.isNaN(c.getAbundanceAppErr())== false)
           {
             pstmt.setDouble(7, c.getAbundanceAppErr());
           }
          else
           {
             pstmt.setNull(7, java.sql.Types.NUMERIC);
           } 

          if(Double.isNaN(c.getCscRatio())== false)
           {
             pstmt.setDouble(8, c.getCscRatio());
           }
          else
           {
             pstmt.setNull(8, java.sql.Types.NUMERIC);
           }

          if(Double.isNaN(c.getCscRatioErr()) == false)
           {
             pstmt.setDouble(9, c.getCscRatioErr());
           }
          else
           {
             pstmt.setNull(9, java.sql.Types.NUMERIC);
           }

          pstmt.executeUpdate();
          pstmt.close();
         }
        catch(java.sql.SQLException e)
         {
            status = -1;
            System.out.println("Error inserting into gards_csc_modcoeff_lib");
            System.out.println(e);
         }
        return status;

      }









/**
 *   Read all CscModcoeffs from database;  sort by detector code, name, energy
 *   return null on error
 */
    public static List   getAllCscModcoeff(Connection conn, String detCode)
     {

        int                     detectorId;
        String                  detectorCode;
        String                  name;
        String                  daughter;
        double                  energy;
        double                  abundance;
        double                  abundanceApp;
        double                  abundanceAppErr;
        double                  cscRatio;
        double                  cscRatioErr;

        ArrayList               list = new ArrayList();

        String                  whereClause = 
                 " where gards_detectors.detector_id = gards_csc_modcoeff_lib.detector_id ";

        if(detCode != null)
         {
           whereClause = whereClause + " and gards_detectors.detector_code = '" +
                                       detCode + "' ";
         }

        try
         {

          String queryString = "select  gards_csc_modcoeff_lib.detector_id, " +
                      " gards_detectors.detector_code, " +
                      " name, name_d, energy,  "+
                      " abundance, app_abundance, app_abundance_err, " +
                      " csc_ratio, csc_ratio_err " +
                      " from gards_csc_modcoeff_lib, gards_detectors  " +
                      whereClause +
                      " order by gards_detectors.detector_code, name, energy";


          Statement st = conn.createStatement();
	  ResultSet rs = st.executeQuery(queryString);

          while (rs.next() == true)
           {

            detectorId =  rs.getInt(1);
            detectorCode = rs.getString(2);
            name = rs.getString(3);
            daughter = rs.getString(4);
            energy = rs.getDouble(5);
            abundance = rs.getDouble(6);
            abundanceApp =  rs.getDouble(7);

            if(rs.wasNull())
             {
                abundanceApp = Double.NaN;
             }
            abundanceAppErr = rs.getDouble(8);

            if(rs.wasNull())
             {
                abundanceAppErr = Double.NaN;
             }

            cscRatio =  rs.getDouble(9);

            if(rs.wasNull())
             {
                cscRatio =  Double.NaN;
             }

            cscRatioErr = rs.getDouble(10);
            if(rs.wasNull())
             {
                cscRatioErr =  Double.NaN;
             }


            CscModcoeff  c = new CscModcoeff(detectorId,
                                             detectorCode,  
                                             name,
                                             daughter,
                                             energy,
                                             abundance,
                                             abundanceApp,
                                             abundanceAppErr,
                                             cscRatio,
                                             cscRatioErr);
             list.add(c);

           }

          st.close();
          rs.close();

        } 
       catch (Exception e)
        {

          System.out.println("Error in getAllCscModcoeff. " + e);

        }

       return list;

     }




/**
 *   Remove all CscModcoeffs from for a detector code.  Does not commit.
 *   Return 0 on success.
 */
    public static int removeDetector(Connection conn, String detCode)
     {


        int     status = 0;
        try
         {

          String deleteString = "delete from gards_csc_modcoeff_lib where " +
                      " detector_id = (select detector_id from gards_detectors " + 
                      "                where detector_code = '" + detCode + "' )";


          Statement st = conn.createStatement();
          st.executeUpdate(deleteString);

         }
        catch(java.sql.SQLException e)
         {
           status = -1;
           System.out.println("Error on deleting " + detCode);
           System.out.println(e);

         }
        return status;
      }



    public int     getDetectorId()
     {
        return detectorId;
     }
    public void setDetectorId(int i)
     {
        detectorId = i;
     }


    public String     getDetectorCode() 
     {
        return detectorCode;
     }

    public String     getName() 
     {
        return name;
     }

    public String getDaughter() 
     {
        return daughter;
     }

    public double     getEnergy()
     {
        return energy;
     }


    public double getAbundance()
     {
        return abundance;
     }

    public double getAbundanceApp()
     {
        return abundanceApp;
     }

    public double getAbundanceAppErr()
     {
        return abundanceAppErr;
     }


    public double getCscRatio()
     {
        return cscRatio;
     }
    public double getCscRatioErr()
     {
        return cscRatioErr;
     }


}

