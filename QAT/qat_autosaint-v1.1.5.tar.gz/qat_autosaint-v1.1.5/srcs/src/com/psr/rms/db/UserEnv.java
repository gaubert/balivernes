/*
 * UserEnv.java
 */

package  com.psr.rms.db;

import java.sql.*;
import java.util.*;


public class UserEnv
 {

    private    Properties    userEnv;
    private    String        name;
    private    String        type;   // Fission, Activation, ..
    private    String        sampleType;



    public  UserEnv()
     {
        userEnv = new Properties();
     }

    public  UserEnv(Connection  conn)
     {
        userEnv = new Properties();
        try
         {
           String  queryString = "select name, value from gards_userenv";
           Statement stmt = conn.createStatement();
           ResultSet  rs = stmt.executeQuery(queryString);
           while(rs.next())
            {
              String  name = rs.getString(1); 
              String  value = rs.getString(2);
              userEnv.setProperty(name, value);
            }

           stmt.close();
           rs.close();

          }
         catch(java.sql.SQLException e)
          {
             System.out.println("error reading gards_userenv  " + e);
          }
     }

    public Properties getUserEnv()
     {
       return userEnv;
     }
 }

