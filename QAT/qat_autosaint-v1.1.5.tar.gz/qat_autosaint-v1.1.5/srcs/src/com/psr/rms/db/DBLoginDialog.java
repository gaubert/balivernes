
package com.psr.rms.db;


import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;



public class DBLoginDialog extends JDialog
 {
    DBLoginPanel    dbPanel;
    JPanel          buttonPanel;
    JButton         okButton;
     
    public DBLoginDialog()
     {
        setModal(true);
        getContentPane().setLayout(new BorderLayout());
        dbPanel = new DBLoginPanel();
        getContentPane().add(dbPanel, BorderLayout.CENTER);
      
        String  hostname = System.getProperty("TWO_TASK", "");
        dbPanel.setHostname(hostname);
 
        buttonPanel = new JPanel();
        okButton = new JButton("Ok");
        buttonPanel.add(okButton);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
     }

    public void addActionListener(ActionListener  al)
     {
         okButton.addActionListener(al);
     }

    public DBLoginPanel  getDBLoginPanel()
     {
        return dbPanel;
     }
  }


