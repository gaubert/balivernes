/*
 *  RoiEfficiency.java
 */


package  com.psr.rms.db;

import java.sql.*;
import java.util.*;



/**
 *  This class encapsulates the gards_bg_efficiency_pairs table.
 *  To read a specific
 *  Roi from the database, use the constructor
 *
 *  <code>RoiConc(DBConnection, sample id, roi id)</code>
 *
 *  To read all RoiConcs for a sample use the static function:
 *  
 *  <code>ArrayList  getSampleRoiConcs(DBConnection, sample id)</code>
 *
 */
public class RoiEfficiency
 {


    // Fields corresponding to columns in database. 
    private      int         sampleId;
    private      int         roi;
    private      double      efficiency;
    private      double      efficiencyErr;



    /**
     * Construct an RoiConc from sample_id, roi number.  This will query
     * the database for the rest of the data.  If an error occurs,
     * the sampleId and roi will be reset to 0. 
     */
    public RoiEfficiency(Connection  conn, int sid, int rid)
     {
        int    rc;

        sampleId = sid;
        roi = rid;
        rc = getRoiEfficiency(conn, sampleId, roi);

        if(rc != 0)
         {
           sid = 0;
           roi = 0;
         }
     }

/**
 *  Construct an RoiEfficiency will all of its data.
 */
    public  RoiEfficiency(
                     int      sid,
                     int      rid,
                     double   bgEffic,
                     double   bgEfficErr)
     {
        sampleId = sid;
        roi = rid;
        efficiency= bgEffic;
        efficiencyErr= bgEfficErr;
     }



    /**
     *  Read all gards_roi_concs rows for a specified sample id. The
     *  ROIs will be sorted by gards_roi_concs.roi.
     *
     *  @return   Returns an ArrayList of RoiConcs.
     */
    public static ArrayList  getSampleRoiEfficiency(Connection conn, int   sid)
     {
        Statement      stmt;
        ResultSet      rs;
        String         queryString;
        RoiEfficiency  r;
        ArrayList      list;

        try
         {
           list = new ArrayList();

           stmt  = conn.createStatement();

           queryString = "select roi, BG_EFFICIENCY,BG_EFFIC_ERROR " +
                         " from gards_bg_efficiency_pairs where sample_id = " +
                         sid + " order by roi";

           stmt.executeQuery(queryString);


           rs = stmt.getResultSet();

           // Put returned data into ArrayList.
           while(rs.next())
            { 
              r = new RoiEfficiency(
                          sid,
                          rs.getInt(1),
                          rs.getDouble(2),
                          rs.getDouble(3));

              list.add(r);
            }

           rs.close();
           stmt.close();
         }
        catch(java.sql.SQLException e)
         {
           list = null;
         }

        return list;
     }


    /**
     *  Read all specified efficiency row for a sample id.
     *  @return  Returns a 0 on success or  a nonzero DB error code on failure.
     */
    public int getRoiEfficiency(Connection conn, int sid, int rid) {

        Statement    stmt;
        ResultSet    rs;
        String       queryString;
        RoiConc      r;
        int          rc;

        rc = 0;
        try
         {

           stmt  = conn.createStatement();

           queryString = "select BG_EFFICIENCY,BG_EFFIC_ERROR " +
                         " from gards_bg_efficiency_pairs where sample_id = " +
                             sid + " and roi = " + rid;

           stmt.executeQuery(queryString);


           rs = stmt.getResultSet();

           rs.next();
           sampleId = sid; 
           roi = rid;
           efficiency = rs.getDouble(1);
           efficiencyErr = rs.getDouble(2);

           stmt.close();
           rs.close();
         }
        catch(java.sql.SQLException e)
         {
           rc = e.getErrorCode();  
         }

        return rc;
     }



    /** Get sample id for Roi */
    public final int    getSampleId()
     {
        return sampleId;
     }

    /** Set sample id for Roi */
    public void setSampleId(int sid)
     {
        sampleId = sid;
     }


    /** Get roi id for Roi */
    public final int    getRoi() 
     {
        return roi;
     }
    /** Set roi id for Roi */
    public void setRoi(int r) 
     {
        roi = r;
     }



    /** Get activity for Roi */
    public final double getEfficiency()
     {
        return efficiency;
     }

    /** Set efficiency for Roi */
    public void setEfficiency(double a )
     {
        efficiency = a;
     }

    /** Get efficiency error for Roi */
    public final double getEfficiencyErr()
     {
        return efficiencyErr;
     }

    /** Set efficiencyErr error for Roi */
    public void getActivErr(double ae)
     {
        efficiencyErr = ae;
     }


}

