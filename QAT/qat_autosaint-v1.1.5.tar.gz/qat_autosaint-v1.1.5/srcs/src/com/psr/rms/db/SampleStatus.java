/*
 * SampleStatus.java
 */


package  com.psr.rms.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;


/**
 *  This class wraps  the GARDS_SAMPLE_STATUS table.
 *
 */
public class SampleStatus
 {

    /** Status strings from DB */
    public static final String        UNPROCESSED   = "U"; 
    public static final String        ANALYSIS      = "A"; 
    public static final String        PROCESSED     = "P"; 
    public static final String        QUEUE_RELEASE = "Q";
    public static final String        RELEASED      = "R"; 
    public static final String        TEMP_HOLD     = "T";
    public static final String        PERM_HOLD     = "H";
    public static final String        VIEWED        = "V"; 


    private      int                  sampleId;
    private      Calendar             entryDate;
    private      Calendar             cnfBeginDate;
    private      Calendar             cnfEndDate;
    private      Calendar             reviewDate;
    private      Calendar             releaseDate;
    private      String               analyst;
    private      String               status; 
    private      int                  category; 
    private      int                  autoCategory; 
 
   
  /** Simple Date format of query dates. */ 
    private static final SimpleDateFormat SIMPLE_DATE_FORMAT = 
        new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 

  /** Database format of dates. */
    private static final String DB_DATE_FORMAT = 
        "'YYYY/MM/DD HH24:MI:SS'";


    /**
     * Construct a new SampleStatus.  On error, set sampleId to -1
     */
    public SampleStatus(Connection conn, int sid)
     {
       sampleId = sid;
       int rc = getSampleStatus(conn,sampleId);
       if(rc !=  0)
        {
          sampleId = -1;
        }
     }

/**
 *   Read sample from DB.  Returns Oracle error or 0 if success.
 *
 */
    public int getSampleStatus(Connection conn, int  sid) {

        int                  rc = 0;
        Statement            stmt;
        ResultSet            rs;
        String               queryString;
        java.sql.Timestamp   t;

        sampleId = sid;

        try
         {
            stmt = conn.createStatement();
            queryString = new String("Select entry_date,cnf_begin_date," +
                        " cnf_end_date,review_date,analyst,status, " +
                        " nvl(category, 0), " +
                        " nvl(auto_category, 0), release_date " + 
                        "  from gards_read_sample_status " +
                        " where sample_id = " + sampleId);

            rs = stmt.executeQuery(queryString);
            rs.next();


            t = rs.getTimestamp(1);
            if(t == null)
             {
              entryDate = null;
             }
            else
             {
               entryDate = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
               entryDate.setTime(t);
             }



  
            t = rs.getTimestamp(2);
            if(t == null)
             {
              cnfBeginDate = null;
             }
            else
             {
               cnfBeginDate= new GregorianCalendar(TimeZone.getTimeZone("GMT"));
               cnfBeginDate.setTime(t);
             }

            t = rs.getTimestamp(3);
            if(t == null)
             {
              cnfEndDate= null;
             }
            else
             {
               cnfEndDate = new GregorianCalendar(
                                            TimeZone.getTimeZone("GMT"));
               cnfEndDate.setTime(t);
             }

            t = rs.getTimestamp(4);
            if(t == null)
             {
               reviewDate = null;
             }
            else
             {
               reviewDate= new GregorianCalendar(
                                            TimeZone.getTimeZone("GMT"));
               reviewDate.setTime(t);
             }

            analyst = rs.getString(5);
            status = rs.getString(6);
            category = rs.getInt(7);
            autoCategory= rs.getInt(8);

            t = rs.getTimestamp(9);
            if(t == null)
             {
               releaseDate = null;
             }
            else
             {
               releaseDate = new GregorianCalendar(
                                            TimeZone.getTimeZone("GMT"));
               releaseDate.setTime(t);
             }

            rs.close();
            stmt.close();
         }
        catch(java.sql.SQLException  e)
         {
            System.out.println("Exception in SampleStatus: " + e);
            rc = e.getErrorCode();
         }

        return rc;
     }

  /**
   * Changes the status of the Sample with the given ID to "Released"
   * and sets the release time to the current system time.
   *
   * @param conn Data store connection.
   * @param ID of the Sample for which to update the status.
   */
  public static void updateStatusToReleased(
      Connection conn, int sampleID) {

    try {

      String query = "update gards_sample_status " +
        "set status = '" + SampleStatus.RELEASED + "', " +
        "release_date = SYSDATE " +
        "where sample_id = " + sampleID;
      Statement stmt = conn.createStatement();
      stmt.executeUpdate(query);
      stmt.close();

    } catch (SQLException e) {

      System.out.println("Error updating status to Released.");
      System.out.println("Exception = " + e);

    }

  } // end updateStatusToReleased
 


    /**
     *  Function to update the status for a particular sample id.  If status
     *  is 'R', then also update the review time to the current GMT time.
     *  An analyst name can be provided to indicate which user last modified
     *  the sample status.
     *
     * @param category   if < 0  the category is left null
     * @param updateStatusOnly   tells function to only modify status field
     */
    public static int updateStatus(Connection    conn, 
                                   int           sampleId,
				   String        status,
                                   String        analyst,
                                   int           category,
                                   boolean       updateStatusOnly) {

        PreparedStatement   stmt;
        String              updateString;
        int                 rc;

        rc = 0;

        try
         {
            if(updateStatusOnly == false)
             {

               updateString = new String("update gards_sample_status set " +
                       " status = ?, review_date = SYSDATE, analyst = ?, " +
                       " category = ? " + 
                       "  where sample_id = ?");

               stmt = conn.prepareStatement(updateString);
               stmt.setString(1,status);

               if(analyst == null)
                {
                   stmt.setNull(2, java.sql.Types.VARCHAR);
                }
               else
                {
                   stmt.setString(2, analyst);
                }

               if(category < 0)
                {
                   stmt.setNull(3,java.sql.Types.INTEGER);
                }
               else
                {
                   stmt.setInt(3,category);
                }

               stmt.setInt(4,sampleId);

               rc = stmt.executeUpdate();
               stmt.close();

             }
            else
             {   
               updateString = new String("update gards_sample_status set " +
                      " status = ?  where sample_id = ?");

               stmt = conn.prepareStatement(updateString);
               stmt.setString(1,status);
               stmt.setInt(2,sampleId);
               rc = stmt.executeUpdate();
               stmt.close();

             }
         }
        catch(java.sql.SQLException  e)
         {

           System.out.println("gards_sample_status Error:   " + e);
           rc = e.getErrorCode();
         }

        return rc;
     }

  /**
   * Updates the auto_category of the sample 
   *
   * @param conn database connection
   * @param sampleId id of the sample
   * @param sampleCategory new auto_category of the sample
   */
  public static void updateSampleAutoCategory(Connection  conn,
                                              int         sampleId,
                                              int         sampleCategory) {


    try {
 
      String updateString = 
        "UPDATE gards_sample_status " +
        "SET auto_category = " + sampleCategory + ", " +
        "category = null " +
        "WHERE sample_id = " + sampleId;

      Statement stmt = conn.createStatement();
      stmt.executeUpdate(updateString);
      stmt.close();

    } catch (SQLException e) {

      System.out.println("Error updating gards_sample_status");
      System.out.println("Exception = " + e);

    }

  }


  /**
   * Updates a particular sample's review date
   *
   * @param conn database connection
   * @param sampleId id of the sample
   * @param reviewDate new review date of the sample
   */
  public static void updateReviewDate(Connection   conn,
                                      int          sampleId, 
                                      Timestamp    reviewDate) {

    try {

      String updateString =
        "UPDATE gards_sample_status " +
        "SET review_date = ? " +
        "WHERE sample_id = ?";

      PreparedStatement pstmt = conn.prepareStatement(updateString);
      pstmt.setTimestamp(1, reviewDate);
      pstmt.setInt(2, sampleId);
  
      int catcher = pstmt.executeUpdate();
      pstmt.close();

    } catch (SQLException e) {

      System.out.println("Failure to update review date");
      System.out.println("Exception = " + e);

    }

  }


    /** Return sample id */
    public final int      getSampleId()
     {
        return sampleId;
     }

    /** Return date that this sample was created by rms_input process */
    public final Calendar getEntryDate()
     {
        return entryDate;
     }

    /** Return date that analysis started */
    public final Calendar getCnfBeginDate() 
     {
        return cnfBeginDate;
     }

    /** Return date that analysis ended */
    public final Calendar getCnfEndDate() 
     {
        return cnfEndDate;
     }

    /** Return date that analyst reviewed the sample */
    public final Calendar getReviewDate() 
     {
        return reviewDate;
     }

    /** Return date that QatAuto released sample to 'R' */
    public final Calendar getReleaseDate() 
     {
        return releaseDate;
     }


    /** Return the analyst's name that reviewed sample */
    public final String getAnalyst() 
     {
        return analyst;
     }

    /** set the analyst's name that reviewed sample */
    public void setAnalyst(String s)
     {
        analyst = s;
     }

    /** Return the current sample status */
    public final String getStatus() 
     {
        return status;
     }

    /** set the current sample status */
    public void setStatus(String s) 
     {
        status = s;
     }

    /** Return the current characterization */
    public final int    getCategory() 
     {
        return category;
     }

    /** set the current characterization */
    public void setCategory(int  c) 
     {
        category = c;
     }

    /** Return the characterization from the initial analysis */
    public final int    getAutoCategory() 
     {
        return autoCategory;
     }

    /** Return true if sample has been released */
    public final boolean isReleased() 
     {
        return status.equals(RELEASED);
     }

    /** Return true if sample has been released */
    public final boolean isProcessed() 
     {
        return status.equals(PROCESSED);
     }

    /** Return true if sample has been viewed */
    public final boolean isViewed() 
     {
        return status.equals(VIEWED);
     }








//////////////////////////////////////
// Queries used by rms_QAT_report   //
//////////////////////////////////////
  /**
   * Returns the number of samples released between the given dates
   * for the given station IDs.
   *
   * @param conn Data store connection.
   * @param begin Begin date of the time range to be queried.
   * @param end End date of the time range to be queried.
   * @param stationIDs List of station IDs to be queried.
   * NOTE: List of Station IDs contains Integer objects.
   * @return Number of samples released during the given dates for the
   * given station IDs.
   */
  public static int getNumSamplesReleased(Connection  conn,
                                          Calendar    begin, 
                                          Calendar    end, 
                                          List        stationIDs) {

    /* format dates for query  */
    String beginDate = SIMPLE_DATE_FORMAT.format(begin.getTime());
    String endDate = SIMPLE_DATE_FORMAT.format(end.getTime());

    /* number of samples released */
    int numSamplesReleased = 0;
    try {
      StringBuffer query = new StringBuffer(
        "SELECT COUNT(*) " +
        "FROM gards_read_sample_status, gards_sample_data " +
        "WHERE ((status = 'R') AND " +
        "(release_date >= " +
        "to_date('" + beginDate + "', " + DB_DATE_FORMAT + ")) AND " +
        "(release_date <= " +
        "to_date('" + endDate + "', " + DB_DATE_FORMAT + ")) " +
     "AND (gards_read_sample_status.sample_id = gards_sample_data.sample_id) ");

        int numStationIDs = stationIDs.size();
        if(numStationIDs > 0) {

           query.append("AND station_id IN(");


           for(int index = 0; index < numStationIDs; index++) {

             query.append(((Integer)stationIDs.get(index)).toString());

             if(index != numStationIDs-1) {

               query.append(", ");

             }
           }
          query.append("))");

        } else {

          query.append(")");

        }

      Statement stmt = conn.createStatement();
      ResultSet  rs = stmt.executeQuery(query.toString());
      if(rs.next()) {
        numSamplesReleased = rs.getInt(1);
      }

      rs.close();
      stmt.close();

    } catch (SQLException e) {
      System.out.println(
        "Error retrieving number of samples released.");
      System.out.println("Exception = " + e);
    }


    return numSamplesReleased;
  } // end getNumSamplesReleased

  /**
   * Returns the maximum time elapsed (in days) before a status change
   * of R(eleased) occurred for the samples with a collection stop
   * date that falls between the given dates for the given station IDs.
   *
   * @param conn Data store connection.
   * @param begin Begin date of the time range to be queried.
   * @param end End date of the time range to be queried.
   * @param stationIDs List of station IDs to be queried.
   * NOTE: List of Station IDs contains Integer objects.
   * @return Maximum release delay during the given dates for the
   * given station IDs.
   */
  public static float getMaxReleaseDelay(Connection  conn,
                                         Calendar    begin,
                                         Calendar    end,
                                         List        stationIDs) {

    /* format dates for query  */
    String beginDate = SIMPLE_DATE_FORMAT.format(begin.getTime());
    String endDate = SIMPLE_DATE_FORMAT.format(end.getTime());

    /* maximum release delay */
    float maxReleaseDelay = 0;
    try {
      StringBuffer query = new StringBuffer(
        "SELECT MAX(release_date - review_date) " +
        "FROM gards_read_sample_status, gards_sample_data " +
        "WHERE ((release_date is not null) AND (review_date is not null) " +
        "AND (collect_stop is not null) " +
        "AND (collect_stop >= " +
        "to_date('" + beginDate + "', " + DB_DATE_FORMAT + ")) " +
        "AND (collect_stop <= " +
        "to_date('" + endDate + "', " + DB_DATE_FORMAT + ")) " +
      "AND (gards_read_sample_status.sample_id = gards_sample_data.sample_id)");

        int numStationIDs = stationIDs.size();
        if(numStationIDs > 0) {

           query.append(" AND station_id IN(");


           for(int index = 0; index < numStationIDs; index++) {

             query.append(((Integer)stationIDs.get(index)).toString());

             if(index != numStationIDs-1) {

               query.append(", ");

             }
           }
          query.append("))");

        } else {

          query.append(")");

        }



      Statement stmt = conn.createStatement();
      ResultSet  rs = stmt.executeQuery(query.toString());
      if(rs.next()) {
        maxReleaseDelay = rs.getFloat(1);
      }

      rs.close();
      stmt.close();

    } catch (SQLException e) {
      System.out.println(
        "Error retrieving maximum release delay.");

      System.out.println("Exception = " + e);
    }

    return maxReleaseDelay;
  } // end getMaxReleaseDelay

  /**
   * Returns the minimum time elapsed (in days) before a status change
   * of R(eleased) occurred for the samples with a collection stop
   * date that falls between the given dates for the given station IDs.
   *
   * @param conn Data store connection.
   * @param begin Begin date of the time range to be queried.
   * @param end End date of the time range to be queried.
   * @param stationIDs List of station IDs to be queried.
   * NOTE: List of Station IDs contains Integer objects.
   * @return Minimum release delay during the given dates for the
   * given station IDs.
   */
  public static float getMinReleaseDelay(Connection  conn,
                                         Calendar    begin,
                                         Calendar    end, 
                                         List        stationIDs) {

    /* format dates for query  */
    String beginDate = SIMPLE_DATE_FORMAT.format(begin.getTime());
    String endDate = SIMPLE_DATE_FORMAT.format(end.getTime());

    /* minimum release delay */
    float minReleaseDelay = 0;
    try {
      StringBuffer query = new StringBuffer(
        "SELECT MIN(release_date - review_date) " +
        "FROM gards_read_sample_status, gards_sample_data " +
        "WHERE ((release_date is not null) AND (review_date is not null) " +
        "AND (collect_stop is not null) " +
        "AND (collect_stop >= " +
        "to_date('" + beginDate + "', " + DB_DATE_FORMAT + ")) " +
        "AND (collect_stop <= " +
        "to_date('" + endDate + "', " + DB_DATE_FORMAT + ")) " +
     "AND (gards_read_sample_status.sample_id = gards_sample_data.sample_id) ");




        int numStationIDs = stationIDs.size();
        if(numStationIDs > 0) {

           query.append("AND station_id IN(");


           for(int index = 0; index < numStationIDs; index++) {

             query.append(((Integer)stationIDs.get(index)).toString());

             if(index != numStationIDs-1) {

               query.append(", ");

             }
           }
          query.append("))");

        } else {

          query.append(")");

        }



      Statement stmt = conn.createStatement();
      ResultSet  rs = stmt.executeQuery(query.toString());
      if(rs.next()) {
        minReleaseDelay = rs.getFloat(1);
      }

      rs.close();

      stmt.close();

    } catch (SQLException e) {
      System.out.println(
        "Error retrieving minimum release delay.");
      System.out.println("Exception = " + e);
    }

    return minReleaseDelay;
  } // end getMinReleaseDelay

  /**
   * Returns the average time elapsed (in days) before a status change
   * of R(eleased) occurred for the samples with a collection stop
   * date that falls between the given dates for the given station IDs.
   *
   * @param conn Data store connection.
   * @param begin Begin date of the time range to bequeried.
   * @param end End date of the time range to be queried.
   * @param stationIDs List of station IDs to be queried.
   * NOTE: List of Station IDs contains Integer objects.
   * @return Average release delay during the given dates for the
   * given station IDs.
   */
  public static float getAvgReleaseDelay(Connection  conn,
                                         Calendar    begin,
                                         Calendar    end,
                                         List        stationIDs) {

    /* format dates for query  */
    String beginDate = SIMPLE_DATE_FORMAT.format(begin.getTime());
    String endDate = SIMPLE_DATE_FORMAT.format(end.getTime());

    /* average release delay */
    float avgReleaseDelay = 0;
    try {
      StringBuffer query = new StringBuffer(
        "SELECT AVG(release_date - review_date) " +
        "FROM gards_read_sample_status, gards_sample_data " +
        "WHERE ((release_date is not null) AND (review_date is not null) " +
        "AND (collect_stop is not null) " +
        "AND (collect_stop >= " +
        "to_date('" + beginDate + "', " + DB_DATE_FORMAT + ")) " +
        "AND (collect_stop <= " +
        "to_date('" + endDate + "', " + DB_DATE_FORMAT + ")) " +
     "AND (gards_read_sample_status.sample_id = gards_sample_data.sample_id) ");



        int numStationIDs = stationIDs.size();
        if(numStationIDs > 0) {

           query.append(" AND station_id IN(");


           for(int index = 0; index < numStationIDs; index++) {

             query.append(((Integer)stationIDs.get(index)).toString());

             if(index != numStationIDs-1) {

               query.append(", ");

             }
           }
          query.append("))");

        } else {

          query.append(")");

        }


      Statement stmt = conn.createStatement();
      ResultSet  rs = stmt.executeQuery(query.toString());

      if(rs.next()) {
        avgReleaseDelay = rs.getFloat(1);
      }

      rs.close();
      stmt.close();

    } catch (SQLException e) {
      System.out.println(
        "Error retrieving average release delay.");
      System.out.println("Exception = " + e);
    }

    return avgReleaseDelay;
  } // end getAvgReleaseDelay

  /**
   * Returns the number of samples released later than 1 day from
   * its entry date for the samples with a collection stop date that
   * falls between the given dates for the given station IDs.
   *
   * @param conn Data store connection.
   * @param begin Begin date of the time range to be queried.
   * @param end End date of the time range to be queried.
   * @param stationIDs List of station IDs to be queried.
   * NOTE: List of Station IDs contains Integer objects.
   * @return Number of samples released later than 1 day from the
   * entry date during the given dates for the given station IDs.
   */
  public static int getNumSamplesReleasedGT1Day(Connection  conn,
                                                Calendar    begin,
                                                Calendar    end,
                                                List        stationIDs) {

    /* format dates for query  */
    String beginDate = SIMPLE_DATE_FORMAT.format(begin.getTime());
    String endDate = SIMPLE_DATE_FORMAT.format(end.getTime());

    /* number of samples released */
    int numSamplesReleased = 0;
    try {
      StringBuffer query = new StringBuffer(
        "SELECT COUNT(*) " +
        "FROM gards_read_sample_status, gards_sample_data " +
        "WHERE (((release_date - entry_date) > 1) " +
        "AND (collect_stop is not null) " +
        "AND (collect_stop >= " +
        "to_date('" + beginDate + "', " + DB_DATE_FORMAT + ")) " +
        "AND (collect_stop <= " +
        "to_date('" + endDate + "', " + DB_DATE_FORMAT + ")) " +
        "AND (gards_read_sample_status.sample_id = gards_sample_data.sample_id) ");


        int numStationIDs = stationIDs.size();
        if(numStationIDs > 0) {

           query.append("AND station_id IN(");


           for(int index = 0; index < numStationIDs; index++) {

             query.append(((Integer)stationIDs.get(index)).toString());

             if(index != numStationIDs-1) {

               query.append(", ");

             }
           }
          query.append("))");

        } else {

          query.append(")");

        }


      Statement stmt = conn.createStatement();
      ResultSet  rs = stmt.executeQuery(query.toString());
      if(rs.next()) {
        numSamplesReleased = rs.getInt(1);
      }

      rs.close();
      stmt.close();

    } catch (SQLException e) {
      System.out.println("Error retrieving number of samples released " +
        "later than 1 day.");
      System.out.println("Exception = " + e);
    }

    return numSamplesReleased;
  } // end getNumSamplesReleasedGT1Day

  /**
   * Returns the number of reviewed samples released later than 1 day
   * from its entry date for the samples with a collection stop date
   * that falls between the given dates for the given station IDs.
   *
   * @param conn Data store connection.
   * @param begin Begin date of the time range to be queried.
   * @param end End date of the time range to be queried.
   * @param stationIDs List of station IDs to be queried.
   * NOTE: List of Station IDs contains Integer objects.
   * @return Number of reviewed samples released later than 1 day from
   * the entry date during the given dates for the given station IDs.
   */
  public static int getNumReviewedSamplesReleasedGT1Day(Connection  conn,
                                                        Calendar    begin,
                                                        Calendar    end,
                                                        List        stationIDs)
  {

    /* format dates for query  */
    String beginDate = SIMPLE_DATE_FORMAT.format(begin.getTime());
    String endDate = SIMPLE_DATE_FORMAT.format(end.getTime());

    /* number of samples released */
    int numSamplesReleased = 0;
    try {
      StringBuffer query = new StringBuffer(
        "SELECT COUNT(*) " +
        "FROM gards_read_sample_status, gards_sample_data, gards_status_history " +
        "WHERE (((release_date - entry_date) > 1) " +
        "AND (collect_stop is not null) " +
        "AND (collect_stop >= " +
        "to_date('" + beginDate + "', " + DB_DATE_FORMAT + ")) " +
        "AND (collect_stop <= " +
        "to_date('" + endDate + "', " + DB_DATE_FORMAT + ")) " +
        "AND (gards_read_sample_status.sample_id = gards_sample_data.sample_id) " +
        "AND (new_status = 'T' OR new_status = 'H') " +
        "AND (gards_read_sample_status.sample_id = gards_status_history.sample_id) "); 


        int numStationIDs = stationIDs.size();
        if(numStationIDs > 0) {

           query.append(" AND station_id IN(");


           for(int index = 0; index < numStationIDs; index++) {

             query.append(((Integer)stationIDs.get(index)).toString());

             if(index != numStationIDs-1) {

               query.append(", ");

             }
           }
          query.append("))");

        } else {

          query.append(")");

        }




      Statement stmt = conn.createStatement();
      ResultSet  rs = stmt.executeQuery(query.toString());
      if(rs.next()) {
        numSamplesReleased = rs.getInt(1);
      }

      rs.close();
      stmt.close();

    } catch (SQLException e) {
      System.out.println("Error retrieving number of samples released " +
        "later than 1 day due to QC Review.");
      System.out.println("Exception = " + e);
    }

    return numSamplesReleased;
  } // end getNumReviewedSamplesReleasedGT1Day


}

