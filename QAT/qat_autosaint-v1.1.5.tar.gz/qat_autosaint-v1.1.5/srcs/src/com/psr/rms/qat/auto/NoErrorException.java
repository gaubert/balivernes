package com.psr.rms.qat.auto;

public class NoErrorException extends Exception
{
	/**
	 * 
	 */
	private static final long	serialVersionUID	= -872328267399644459L;

	public NoErrorException(String aMessage)
	{
		super(aMessage);
	}
}
