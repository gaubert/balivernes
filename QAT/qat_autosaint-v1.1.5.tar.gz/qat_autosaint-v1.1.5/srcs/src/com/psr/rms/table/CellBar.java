/*
 * CellCentered.java
 *
 * Created on May 25, 2000, 3:55 PM
 * Brett Pettigrew, Pacific-Sierra Research
 */

package com.psr.rms.table;

/** a StringTable cell that displays a bar of repeated characters
 * @author Brett Pettigrew
 */
public class CellBar extends Cell {

  /** Creates a new CellCentered
   * @param content the contents of the cell
   */
  public CellBar(String content) {
    super(content);
  }

  /** returns the cell in the proper display format
   * @param width how wide the cell will be displayed
   * @return the contents of the cell, centered
   */
  public String getFormatted(int width) {
    char c = super.getContent().charAt(0);
    return TextSpacer.getChars(width, c);
  }
}
