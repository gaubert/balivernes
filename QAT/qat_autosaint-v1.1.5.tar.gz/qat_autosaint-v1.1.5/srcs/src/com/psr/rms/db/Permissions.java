/*
 * Permissions.java
 */


package  com.psr.rms.db;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.*;


/**
 *  This class wraps  the GARDS_PERMISSIONS table.
 *
 */
public class Permissions
 {

    /**
     * Check to see if a role has a specified permission in the
     * database.
     * @return   true if an entry exists, otherwise return false
     */
    public static boolean  checkRolePermission(Connection      conn,
                                               PermissionType  type,
                                               int             sampleId,
                                               String          username,
                                               String          rolename)
     {
       boolean     permissionOk = false;
       Statement   stmt;
       ResultSet   rs;
       String      queryString;


       try
        {

          stmt = conn.createStatement();


        // First determine if we own sample or our rolename owns sample

          String   roleIdSelectString = " (select gards_roles.role_id from " +
                        " gards_roles where role_name = '" + rolename + "')";

          String   userIdSelectString = " (select gards_users.user_id from " +
                        " gards_users where user_name = '" + username + "')";

          queryString = "select 1 from GARDS_DIST_SAMPLE_QUEUE where  " +
                        "GARDS_DIST_SAMPLE_QUEUE.sample_id = " + sampleId +
                        " and " +
                        "( GARDS_DIST_SAMPLE_QUEUE.role_id = " +
                        roleIdSelectString  + " or " + 
                        "GARDS_DIST_SAMPLE_QUEUE.user_id = " +
                        userIdSelectString +  " )";

          rs   = stmt.executeQuery(queryString);

          // If a row is returned, then we own sample.
          if(rs.next() == true)
           {

        // Now determine if our role has the correct permissions

            queryString = "select 1 from GARDS_ROLES_PERMISSIONS, " +
            " GARDS_ROLES,GARDS_PERMISSIONS " + " where " +
            " GARDS_ROLES.role_name = '" + rolename + "'" +
            " and GARDS_ROLES.role_id = GARDS_ROLES_PERMISSIONS.role_id " +
            " and GARDS_ROLES_PERMISSIONS.PERMISSION_ID = GARDS_PERMISSIONS.PERMISSION_ID " +
            " and GARDS_PERMISSIONS.permission_name = '" + type.getPermissionType() + "'";
 
            rs   = stmt.executeQuery(queryString);

            if(rs.next() == true)
             {
              // We own the sample, and we have permission for operation
              permissionOk = true;
             }
            else 
             {
              permissionOk = false;
             }
           }
          else   // We don't even own sample
           {
             permissionOk = false;
           }

          rs.close();
          stmt.close();

         }
        catch(java.sql.SQLException  e)
         {
           System.out.println("Error in read checkRolePermission: " + e);
         }
        return permissionOk;
     }

    /**
     * Get list of permissions a role has
     * @return  List of Strings 
     */
    public static List getPermissions(Connection      conn,
                                             String          roleName)
     {
       List list = new ArrayList();

       try
        {
         String queryString = "select GARDS_ROLES_PERMISSIONS.permission_name,"+
         " from " +
         " GARDS_ROLES_PERMISSIONS,GARDS_ROLES,GARDS_PERMISSIONS " + " where " +
         " GARDS_ROLES.role_name = '" + roleName + "'" +
         " and GARDS_ROLES.role_id = GARDS_ROLES_PERMISSIONS.role_id ";

         Statement stmt = conn.createStatement();
         ResultSet rs   = stmt.executeQuery(queryString);
         while ( rs.next() == true )
          {
            list.add(rs.getString(1)); 
          }

          rs.close();
          stmt.close();

         }
        catch(java.sql.SQLException  e)
         {
           System.out.println("Error in read getPermissions()" + e);
         }
        return list;
     }

   /**
    * Return true if any of the specified user's roles have the
    * permission.
    */
   public static boolean  checkIfUserHasPermission(
                                            Connection      conn,
                                            String          user,
                                            PermissionType  p)
    {
      String    permission = p.getPermissionType();
      boolean   permissionOk = false;


       String     queryString =
           "select 1 from gards_users where user_id in " +
           " (select user_id from gards_users_roles where role_id in " +
           "   (select role_id from gards_roles_permissions " +
           "    where PERMISSION_ID in " +
           "     ( select PERMISSION_ID from gards_permissions where  " +
           "       permission_name = '" + permission + "'))) " +
           " and USER_NAME = '" + user + "'";


       try
        {

          Statement stmt = conn.createStatement();
          ResultSet rs   = stmt.executeQuery(queryString);
          if(rs.next() == true)
           {
            // We have permission
              permissionOk = true;
           }
          else 
           {
              permissionOk = false;
           }

          rs.close();
          stmt.close(); 

         }
        catch(java.sql.SQLException  e)
         {
           System.out.println("Error in checkIfUserHasPermission() " + e);
         }
        return permissionOk;

     }
     

}

