/*
 * CommentDef.java
 */


package   com.psr.rms.db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class CommentDef
 {

   /** Minimum Insectra predefined type */
   public static  int    MIN_INSP= 1;

   /** Maximum Insectra predefined type */
   public static  int    MAX_INSP= 999;
   
   /** Minimum Insectra General predefined type */
   public static  int    MIN_INSP_GEN = 1000;

   /** Maximum Insectra General predefined type */
   public static  int    MAX_INSP_GEN = 1999;

   /** Minimum QAT predefined type */
   public static  int    MIN_QAT = 2000;

   /** Maximum QAT predefined type */
   public static  int    MAX_QAT = 2999;

   private  String     text;
   private  int        type;





   public CommentDef(int type, String text)
    {
        this.type = type;
        this.text = text;
    }

   public int getType()
    {
        return type;
    }

   public String getText()
    {
        return text;
    }

   public void setText(String text)
    {
        this.text = text;
    }

   public void setType(int type)
    {
        this.type= type;
    }
/**
 * Load CommentDefList from database gards_comments_defs
 */
     public static List getCommentDefs(Connection conn)
      {
         List  commentDefList = new ArrayList();

         try
          {
         // Smoke old comment def list and create a new one

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select comment_type, " +
                    " comment_text from gards_comments_defs  " +
                    " order by comment_type");

           while(rs.next() == true)
            {
              CommentDef cd  = new CommentDef(rs.getInt(1), rs.getString(2));
              commentDefList.add(cd);
            }

           stmt.close();
           rs.close();

          }
         catch(java.sql.SQLException e)
          {
            System.out.println("Exception in Comment load:  " + e);
          }
         return commentDefList;
      }




/**
 * Load CommentDefList from database gards_comments_defs in a range
 * inclusive
 */
     public static List getCommentDefs(Connection conn,
                                       int        minType,
                                       int        maxType)
      {
         List  commentDefList = new ArrayList();

         try
          {
         // Smoke old comment def list and create a new one

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select comment_type, " +
                    " comment_text from gards_comments_defs  " +
                    " where comment_type >= " + minType + 
                    " and comment_type <= " + maxType + 
                    " order by comment_type");

           while(rs.next() == true)
            {
              CommentDef cd  = new CommentDef(rs.getInt(1), rs.getString(2));
              commentDefList.add(cd);
            }

           stmt.close();
           rs.close();

          }
         catch(java.sql.SQLException e)
          {
            System.out.println("Exception in Comment load:  " + e);
          }
         return commentDefList;
      }


/**
 * Return the CommentDef with the specified type.  If the type does not
 * exist in the list, then null is returned.
 */
     public static CommentDef  get(List commentDefList, int type)
      {
        int   size = commentDefList.size();

        for(int i=0;i<size;i++)
         {
            CommentDef cd =(CommentDef) commentDefList.get(i);
            if(cd.getType() == type)
             {
                return cd;
             }
         }
        return null;
      }


   public String toString()
    {
      return getText();
    }

 }


