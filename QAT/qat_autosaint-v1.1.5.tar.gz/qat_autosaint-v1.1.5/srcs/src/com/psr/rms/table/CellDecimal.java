/*
 * CellCentered.java
 *
 * Created on May 25, 2000, 3:55 PM
 * Brett Pettigrew, Pacific-Sierra Research
 */

package com.psr.rms.table;

/** a StringTable cell that displays its contents centered on the decimal
 * @author Brett Pettigrew
 * @version 1.0
 */
public class CellDecimal extends Cell {

  /** Creates a new CellCentered
   * @param content the contents of the cell
   */
  public CellDecimal(String content) {
    super(content);
  }

  /** returns the cell in the proper display format
   * @param width how wide the cell will be displayed
   * @return the contents of the cell, centered
   */
  public String getFormatted(int width) {
    String out = "";
    String s = super.getContent();
    int center = (width / 2);
    int decimal = s.indexOf('.');
    
    out += TextSpacer.getSpaces(center - decimal - 1);
    out += s;
    if (out.length() < width) {
      out += TextSpacer.getSpaces(width - out.length());
    }
    return out;
   }
}
