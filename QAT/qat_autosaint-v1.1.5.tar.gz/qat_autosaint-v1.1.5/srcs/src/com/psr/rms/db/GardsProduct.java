/*
 * GardsProduct.java
 */

package com.psr.rms.db;

import java.io.*;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.GregorianCalendar;

import javax.swing.*;

/**
 * Class wraps gards_product table.  This tables stores filenames of
 * RRR and SSREB reports released from Inspectra and Coriant.  This 
 * table closely resembles the fileproduct table.
 *
 */
public class GardsProduct{

  private int foff     = 0;
  private int dsize;
  private int revision;
  private int sampleId;
  private int typeId;
  private String author;
  private String dfile;
  private String dir;

  /** No RRR changes. (during specified dates). */
  public static final int NO_CHANGES = 0;
   
  /** Simple Date format of query dates. */ 
  private static final SimpleDateFormat SIMPLE_DATE_FORMAT = 
    new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 

  /** Database format of dates. */
  private static final String DB_DATE_FORMAT = 
    "'YYYY/MM/DD HH24:MI:SS'";



  private static DateFormat dateFormat =
    new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");

  public static final String RRR_REPORT     = "RRR";
  public static final String SSREB_REPORT   = "SSREB";
  public static final String SCAC           = "SCAC";
  public static final String BASELINE       = "BASELINE";


  public  GardsProduct(
                int sampleId,
                int typeId,
                int foff,
                int dsize,
                String dfile,
                String dir,
                int revision,
                String author)
     {
       this.foff = foff;
       this.dsize = dsize;
       this.revision = revision;
       this.sampleId = sampleId;
       this.typeId = typeId;
       this.author = author;
       this.dfile = dfile;;
       this.dir = dir;
     }


  public int getRevision() {

    return revision;

  }


  /**
   * Get fully qualified Unix filename
   */
  public String getFullFilename() {

    return dir + "/" + dfile;

  }


  public String getFile() {

    return dfile;

  }

  public int getOffset() {

    return foff;

  }


  public String getDirectory() {

    return dir;

  }


  public void setDirectory(String f) {

    dir = f;

  }


  public void setFile(String f) {

    dfile = f;

  }


  public void setSize(int size) {

    dsize = size;

  }

  public int getSize() {

    return dsize;

  }




  public void setAuthor(String a) {

    author = a;

  }

 

  /** 
   * 
   */
  public void insert(Connection conn) {

    insertFileName(conn, typeId, dir, dfile, foff, dsize, author,
                   revision, sampleId);

  }


  /** 
   * 
   */
  public static void insertFileName(Connection conn, int typeId, String dir,
                                    String dfile, int foff, int dsize,
                                    String author,
                                    int revision,
                                    int sampleId) {

    int rc;
    PreparedStatement pstmt;
    String updateString;
  
    try { 


      updateString = "insert into gards_product(typeid, dir, dfile, " +
                     "foff, dsize, author, revision, sample_id) " +
                     "  values( ?,?,?,?,?,?,?,?)";


      pstmt = conn.prepareStatement(updateString);

      pstmt.setInt(1, typeId);
      pstmt.setString(2, dir);
      pstmt.setString(3, dfile);
      pstmt.setInt(4, foff);
      pstmt.setInt(5, dsize);
      pstmt.setString(6, author);
      pstmt.setInt(7, revision);
      pstmt.setInt(8, sampleId);

      rc = pstmt.executeUpdate();

      pstmt.close();

    } catch (java.sql.SQLException e) {

      System.out.println("Exception in GardsProduct.insertFileName() : " + e);
      rc = e.getErrorCode();
      System.out.println("error code " + rc);

    }
  }


  /**
   * Read typeid from GARDS_PRODUCT_TYPES
   * @param prodType   prodtype from GARDS_PRODUCT_TYPES
   */
  public static int findTypeId(Connection   conn,
                               String       prodType) throws Exception
   {

    int typeId = -1;

    Statement stmt;
    ResultSet rs;
    String queryString;

    try
     {

      stmt        = conn.createStatement();
      queryString = "select typeid from gards_product_type  " +
                    " where prodtype = '" + prodType + "'";

      rs = stmt.executeQuery(queryString);
      rs.next();
      typeId = rs.getInt(1);

      rs.close();
      stmt.close();

     }
    catch(java.sql.SQLException e)
     {
      throw new Exception("Error getting typeid from GardsProduct " +
                          prodType +  "\n" + e);
    
     }  
    return typeId;
   }



  public static List openAll(Connection conn, int sid, String prodType) {


    Statement stmt;
    ResultSet rs;
    String    queryString;
    List      list = new ArrayList();

    int foff     = 0;
    int dsize;
    int revision;
    int sampleId;
    int typeId;
    String author;
    String dfile;
    String dir;
  
   try {

      stmt        = conn.createStatement();

      typeId = findTypeId(conn, prodType);

      queryString = "select dir, dfile, revision, " +
                    "dsize, author, foff,sample_id  from " +
                    " gards_product " +
                    "where typeid = " + typeId  + " and sample_id = " +
                     sid  + " order by revision desc";

      rs = stmt.executeQuery(queryString);
      if(rs.next())
       {
         dir      = rs.getString(1);
         dfile    = rs.getString(2);
         revision = rs.getInt(3);
         dsize    = rs.getInt(4);
         author   = rs.getString(5);
         foff     = rs.getInt(6);
         sampleId = rs.getInt(7);
     
         GardsProduct gp = new GardsProduct(
                                      sampleId,
                                      typeId,
                                      foff,
                                      dsize,
                                      dfile,
                                      dir,
                                      revision,
                                      author);

         list.add(gp);
        }


      stmt.close();
      rs.close();

    }
    catch(java.sql.SQLException e)
     {
      System.out.println("SQL Exception in GardsProduct.open(): " + e);
     }
    catch(Exception e)
     {
      System.out.println("Exception in GardsProduct.open(): " + e);
     }

   return list; 
  }
 
  /**
   * Read specified type from from disk. This will get the latest revision
   * @param sid         sample_id 
   * @param prodType    prodtype from FPDESCRIPTION
   */
  public static GardsProduct open(Connection conn, int sid, String prodType) {


    Statement stmt;
    ResultSet rs;
    String    queryString;


    GardsProduct  gp;


    List list  = GardsProduct.openAll(conn, sid, prodType);

    if(list.size() == 0)
     {
        return null;
     }
  
    gp = (GardsProduct)list.get(0);

    return gp;

  }
  
//////////////////////////////////////
// Queries used by rms_QAT_report   //
//////////////////////////////////////
  /**
   * Returns the number of RRR changes occuring after QC review for
   * samples collected between the given dates for the given 
   * station IDs.
   *
   * @param conn Data store connection.
   * @param begin Begin date of the time range to be queried.
   * @param end End date of the time range to be queried.
   * @param stationIDs List of station IDs to be queried.
   * NOTE: List of Station IDs contains Integer objects.
   * @return Number of RRR changes occuring after QC review for
   * samples collected between the given dates for the given 
   * station IDs
   */
  public static int getQCReviewNumRRRChanged(Connection  conn,
                                             Calendar    begin,
                                             Calendar    end,
                                             List        stationIDs) {


    /* format dates for query  */
    String beginDate = SIMPLE_DATE_FORMAT.format(begin.getTime());
    String endDate = SIMPLE_DATE_FORMAT.format(end.getTime());
   
    /* number of RRR changes */
    int numRRRChanges = NO_CHANGES;    

    try {

      // Get "RRR" typeid in gards_product_type
      int typeId = findTypeId(conn, RRR_REPORT);


      StringBuffer query = new StringBuffer(
        "SELECT gards_product.sample_id, dir||'/'||dfile, revision " +
        "FROM gards_product , gards_sample_data " +
        "WHERE ( ((revision = " +
        "(SELECT MAX(revision) FROM gards_product " +
                "WHERE sample_id = gards_product.sample_id AND typeid = " +
                typeId + ")) " +
        "OR (revision = " +
        "(SELECT MIN(revision) FROM gards_product " +
          "WHERE sample_id = gards_product.sample_id AND typeid = " + typeId + "))) " +
        "AND (collect_stop is not null) " + 
        "AND (collect_stop >= " +
        "to_date('" + beginDate + "', " + DB_DATE_FORMAT + ")) " +
        "AND (collect_stop <= " +
        "to_date('" + endDate + "', " + DB_DATE_FORMAT + ")) " +
        "AND gards_product.typeid = " + typeId + 
        " AND (gards_product.sample_id = gards_sample_data.sample_id) ");

        int numStationIDs = stationIDs.size();
        if(numStationIDs > 0) {

           query.append("AND station_id IN(");


           for(int index = 0; index < numStationIDs; index++) {

             query.append(((Integer)stationIDs.get(index)).toString());

             if(index != numStationIDs-1) {

               query.append(", ");

             }
           }
          query.append(")) ");

        } else {

          query.append(") ");

        }
      query.append(" ORDER BY gards_product.sample_id, revision");


      Statement stmt = conn.createStatement();
      ResultSet  rs = stmt.executeQuery(query.toString());
      int prevSampleID = 0;
      String prevFilename = "";
      while(rs.next()) {
        int sampleID = rs.getInt("sample_id");
        String filename = rs.getString("dir||/||dfile");
        if(sampleID == prevSampleID) {
          /* compare the current file with the previous file */
          numRRRChanges = numRRRChanges + 
                          diffFiles(prevFilename,filename);
        }
        prevSampleID = sampleID;
        prevFilename = filename;
      }

      rs.close();
      stmt.close();

    } catch (SQLException e) {
      System.out.println(
        "Error getting number of updated RRRs");
      System.out.println("Exception = " + e);

    } catch(Exception e) {

      System.out.println("Exception in GardsProduct.open(): " + e);
    }
      
    return numRRRChanges;
  } // end getQCReviewNumRRRChanged

 /**
  *  Compares 2 RRR reports from the General Comments section and
  *  down.  If the are different, return 1 otherwise return 0.
  */
 public static int diffFiles(String oldFilename, String newFilename)
  {

     try
      {
         File  oldFile = new File(oldFilename);
         File  newFile = new File(newFilename);

         BufferedInputStream oldIS = new BufferedInputStream(
                                           new FileInputStream(oldFile));
         BufferedInputStream newIS = new BufferedInputStream(
                                           new FileInputStream(newFile));

         byte[] oldB  = new byte[(int)oldFile.length()]; 
         byte[] newB = new byte[(int)newFile.length()]; 

         oldIS.read(oldB,0, (int)oldFile.length());
         newIS.read(newB,0, (int)newFile.length());



         oldIS.close(); 
         newIS.close(); 

         String  oldString = new String(oldB);
         String  newString = new String(newB);


         int oldIndex = oldString.indexOf("SAMPLE INFORMATION");
         int newIndex = newString.indexOf("SAMPLE INFORMATION");
      
         oldString = oldString.substring(oldIndex);
         newString = newString.substring(newIndex);

         if(oldString.equals(newString) == true)
          {
            return 0;
          }
         return 1;

      }
     catch(Exception e)
      {
        System.out.println("Error comparing " + oldFilename + 
                           ", " + newFilename);
        System.out.println("Exception = " + e);
      }
     return 0;
  }

}

