/*
 * DBLoginPanel
 */

package com.psr.rms.db;

import javax.swing.*;
import java.awt.*;


public class DBLoginPanel extends   JPanel
 {

    JPanel           buttonPanel;
    JButton          okButton;
    JPanel           textPanel;
    JTextField       userNameField; 
    JPasswordField   passwordField; 
    JTextField       hostnameField; 

    public DBLoginPanel()
     {

       textPanel = new JPanel();
       textPanel.setLayout(new GridLayout(3,2));
       textPanel.add(new JLabel("User name:"));
       userNameField = new JTextField(10);
       textPanel.add(userNameField);

       textPanel.add(new JLabel("Password:"));
       passwordField= new JPasswordField(10);
       textPanel.add(passwordField);

       textPanel.add(new JLabel("Host name:"));
       hostnameField = new JTextField(10);
       textPanel.add(hostnameField);

       add(textPanel);
     }

    public String   getUserName()
     {
       return userNameField.getText();
     }

    public String   getPassword()
     {
       return passwordField.getText();
     }

    public String   getHostname()
     {
       return hostnameField.getText();
     }

    public void setHostname(String host)
     {
        hostnameField.setText(host);
     }
  }

