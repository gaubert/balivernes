


package  com.psr.rms.db;

import java.sql.*;
import java.util.*;



/**
 *
 */
public class RelevantNuclides
 {


    private    String        name;
    private    String        type;   // Fission, Activation, ..
    private    String        sampleType;



    public  RelevantNuclides(String   name, String type, String sampleType)
     {
        this.name = name;
        this.type = type;
        this.sampleType = sampleType;
     }

    public String  getName()
     {
       return name;
     }

    public String  getType()
     {
       return type;
     }

    public String  getSampleType()
     {
       return sampleType;
     }

    public static boolean   isRelevantNuclide(List    relevantNuclides,
                                              String  name)
     {
       for(int i=0;i<relevantNuclides.size();i++)
        {
           RelevantNuclides   rn = (RelevantNuclides)relevantNuclides.get(i);

           if(rn.getName().equals(name))
            {
              return true;
            }
         }
        return false;
     }

    public  static List    getRelevantNuclides(Connection conn,
                                               String sampleType)
     {
        List         nuclideList = new ArrayList();
        Statement    stmt;
        ResultSet    rs;
        String       queryString;


        try
         {
           stmt  = conn.createStatement();

           queryString = "select name, type from gards_relevant_nuclides " +
                         " where sample_type = '" +
                          sampleType + "' order by name";


           stmt.executeQuery(queryString);


           rs = stmt.getResultSet();

           while(rs.next())
            { 
              String  name = rs.getString(1);
              String  type  = rs.getString(2);

              RelevantNuclides r = new RelevantNuclides(name, type,sampleType);

              nuclideList.add(r);
            }

           rs.close();
           stmt.close();
         }
        catch(java.sql.SQLException e)
         {
           nuclideList= null;
         }

        return nuclideList;
     }


 }

