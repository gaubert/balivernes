

package  com.psr.rms.db;


import   java.sql.*;
import   java.util.*;


/**
 * Singleton class that holds gards_comments_defs from database
 * This class uses the Default database connection.
 */
public class DefaultCommentDefList extends CommentDefList
 {

/**
 *  Comment type that indicates it was specified by user.
 */
    private static DefaultCommentDefList instance=new DefaultCommentDefList();


     private DefaultCommentDefList()
      {
//         dbRead();
      }

/**
 * Return the singleton instance of this class.
 */
     public static DefaultCommentDefList getInstance()
      {
         return instance;
      }

 }
