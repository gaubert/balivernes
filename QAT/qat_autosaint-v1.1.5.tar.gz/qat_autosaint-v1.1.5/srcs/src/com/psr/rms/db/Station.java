/* 
 * Station.java
 */
package com.psr.rms.db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;


/**
 *  This class wraps  the GARDS_STATIONS table.
 */
public class Station {

  private Calendar dateBegin;
  private Calendar dateEnd;
  private double lat;
  private double lon;
  private int pocid;
  private int stationId;
  private String countryCode;
  private String description;
  private String stationCode;
  private String status;
  private String type;


  /**
   * Constructor with known station values.  This is used by
   * getAllStations() method.
   */
  public Station(int       stationId,
                 String    stationCode,
                 Calendar  dateBegin,
                 Calendar  dateEnd,
                 double    lat,
                 double    lon,
                 int       pocid,
                 String    countryCode,
                 String    description,
                 String    status,
                 String    type)
    {
      this.stationId = stationId ;
      this. stationCode = stationCode;
      this.dateBegin = dateBegin;
      this.dateEnd = dateEnd;
      this.lat = lat;
      this.lon = lon ;
      this.pocid = pocid;
      this.countryCode =countryCode ;
      this.description = description;
      this.status = status;
      this.type = type;

    }




  /**
   * Read station from DB
   * If error occurs, stationId will be set to -1
   */
  public Station(Connection conn, int sid) {

    Timestamp t;

    try {

      String queryString = "select station_id, station_code, " +
                           "country_code, type, description, lat, lon, " +
                           "date_begin, date_end, status, pocid from " +
                           "gards_stations where station_id = " + sid;

      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery(queryString);

      while (rs.next() == true) {

        stationId   = sid;
        stationCode = rs.getString(2);
        countryCode = rs.getString(3);
        type        = rs.getString(4);
        description = rs.getString(5);
        lat         = rs.getDouble(6);
        lon         = rs.getDouble(7);


        t = (java.sql.Timestamp) rs.getTimestamp(8);
        if (t == null) {

          dateBegin = null;

        } else {

          dateBegin = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
          dateBegin.setTime(t);
 
        }

        t = (java.sql.Timestamp) rs.getTimestamp(9);
        if (t == null) {
 
	  dateEnd = null;
 
	} else {

          dateBegin = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
          dateBegin.setTime(t);

        }
 
        status = rs.getString(10);
        pocid  = rs.getInt(11);
    
      }

      st.close();
      rs.close();


    } catch (Exception e) {

      
      System.out.println("Error getting station for station_id " + sid);
      System.out.println("Error: " + e);
      stationId = -1;


    }

  }

 /**
   *  Read from the gards_station table and populate the
   *  array list with the all the station codes
   *
   *  @param  conn:  The connection to the database
   *
   *  @return Returns an ArrayList Strings.
   */
  public static ArrayList getAllStationCodes(Connection conn)
    {
      ArrayList           list;
      Statement           stmt;
      ResultSet           rs;
      String              stationCode;
      String              queryString;

      try
       {
         list = new ArrayList();

         stmt  = conn.createStatement();

         queryString = "select unique " +
            "station_code " +
            "from gards_stations";

         stmt.executeQuery(queryString);

         rs = stmt.getResultSet();

        // load data into list as long as there are rows
         while(rs.next() == true)
           {
             // create a new list in the array for each row returned
             stationCode  = (rs.getString(1));       //stationCode

             // add the value to the array list
             list.add(stationCode);

            }

         // close out the result set
         rs.close();

         // close out the data base connection
         stmt.close();

       }
    catch(java.sql.SQLException e)
       {
         System.out.println("getAllStationCodes error: " + e);
         list = null;
       }

     return list;
    }


 
 /**
   *  Read from the gards_station table and populate the
   *  array list with a Station class for every station.
   *
   *  @param  conn:  The connection to the database
   *
   *  @return Returns an List of Stations.
   */
  public static List getAllStations(Connection conn)
    {
      List                list =  new ArrayList(200);
      Statement           stmt;
      ResultSet           rs;
      String              queryString;

      Calendar dateBegin;
      Calendar dateEnd;
      double lat;
      double lon;
      int pocid;
      int stationId;
      String countryCode;
      String description;
      String stationCode;
      String status;
      String type;
      Timestamp t;

      try
       {


         queryString = "select station_id, station_code, " +
                              "country_code, type, description, lat, lon, " +
                              "date_begin, date_end, status, pocid from " +
                              "gards_stations order by station_code";

         stmt = conn.createStatement();
         rs = stmt.executeQuery(queryString);

         while (rs.next() == true)
          {

           stationId   = rs.getInt(1);
           stationCode = rs.getString(2);
           countryCode = rs.getString(3);
           type        = rs.getString(4);
           description = rs.getString(5);
           lat         = rs.getDouble(6);
           lon         = rs.getDouble(7);


           t = (java.sql.Timestamp) rs.getTimestamp(8);
           if (t == null) {

             dateBegin = null;

           } else {

             dateBegin = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
             dateBegin.setTime(t);

           }

           t = (java.sql.Timestamp) rs.getTimestamp(9);
           if (t == null) {

             dateEnd = null;

           } else {

             dateEnd = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
             dateEnd.setTime(t);

           }

           status = rs.getString(10);
           pocid  = rs.getInt(11);

           Station stat = new Station(  
                                 stationId,
                                 stationCode,
                                 dateBegin,
                                 dateEnd,
                                 lat,
                                 lon,
                                 pocid,
                                 countryCode,
                                 description,
                                 status,
                                 type);


           list.add(stat);
         }

         stmt.close();
         rs.close();



       }
    catch(java.sql.SQLException e)
       {
         System.out.println("getAllStations() error: " + e);
         list = null;
       }

     return list;
    }






  public int getStationId() {

    return stationId;

  }


  public String getStationCode() {

    return stationCode;

  }


  public String getCountryCode() {

    return countryCode;

  }


  public String getType() {

    return type;

  }


  public String getDescription() {

    return description;

  }


  public double getLat() {

    return lat;

  }


  public double getLon() {

    return lon;

  }


  public Calendar getDateBegin() {

    return dateBegin;

  }

  /**
   *  Returns null if station is currently used.
   */
  public Calendar getDateEnd() {

    return dateEnd;

  }


  public String getStatus() {

    return status;

  }


  /**
   *  Returns index into gards_poc table.
   */
  public int getPocid() {

    return pocid;

  }

}

