/*
 * GeneralUtilities.java
 *
 */

package com.psr.utils;

import java.util.Date;

/** This class maintains the logic for General utilities.
 *
 * @author  kpagano
 * @version R3 
 */
public class GeneralUtilities extends Object {
  
  /** Creates new GeneralUtilities */
  public GeneralUtilities() {
  } // end constructor
  
  /** Calculates the number of days between the given start and end Dates. 
   * @param startDate Start Date
   * @param endDate End Date
   * @return Number of days betweent the given Start and End Dates 
   */
  public static int getNumberOfDays(Date startDate, Date endDate) {
    return ((int) ((( endDate.getTime() - startDate.getTime() ) /
      ( 24 * 60 * 60 * 1000)) + 1));
  } // end getNumberOfDays
  
  /** Returns true if the given string is a valid double value.
   * @param doubleString String in question
   * @return Indication of whether or not the string is a valid double value.
   */
  public static boolean isValidDouble(String doubleString) { 
    /* indication of whether or not the given string is a valid double */
    boolean validDouble = false;
    
    try {
      /* NOTE: the following variable is irrelevant, it is the instantiation
       * that is important
       */
      Double junk = new Double(doubleString);
      /* The following line is only executed if the instantiation of a Double
       * with the given string succeeded, which would indicate the string is 
       * a valid double value.
       */
      validDouble = true; 
    } 
    catch(NumberFormatException nfe) { 
      /* The instantiation of a Double with the given string failed, thus the
       * string is not a valid double value.
       */
    } // cannot be formatted to a double 
    
    return validDouble;
  } // end isValidDouble

  
} // end GeneralUtilities class