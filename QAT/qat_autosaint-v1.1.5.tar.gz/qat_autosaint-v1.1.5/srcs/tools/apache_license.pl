#!/usr/bin/perl
use strict;

my $LICENSE = <<"EOF";
Copyright 2005-2007 ECMWF

Licensed under the Apache License, Version 2.0 (the "License"); you may
not use this file except in compliance with the License. You may obtain a
copy of the License at http://www.apache.org/licenses/LICENSE-2.0 Unless
required by applicable law or agreed to in writing, software distributed
under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES
OR CONDITIONS OF ANY KIND, either express or implied. See the License
for the specific language governing permissions and limitations under
the License.
EOF

my %COMMENTS = (

		java       => { start => "/**\n"  , end => "*/\n\n"  , comment => "* " },
		xml        => { start => "<!--\n", end => "-->\n\n" , after => "\<\?xml[^<]*\>" },
#		xsd        => { start => "<!--\n", end => "-->\n\n" },
#		jsp        => { start => "<!--\n", end => "-->\n\n" },
		sh         => { comment => "# ", end => "\n", after => "^#!/.*\n" },
		pl         => { comment => "# ", end => "\n", after => "^#!/.*\n" },
		js         => { start => "/**\n"  , end => "*/\n\n"  , comment => "* " },
		css        => { start => "/**\n"  , end => "*/\n\n"  , comment => "* " },
		sql        => { comment => "-- ", end => "\n" },
		properties => { comment => "# ", end => "\n" },

		);


foreach my $file ( @ARGV )
{
	$file =~ /\.(\w+)/;
	my $ext = $1;

	my $c = $COMMENTS{$ext};

	unless($c)
	{
		print "$file: unsupported extension. File ignored\n";
		next;
	}

	open(IN,"<$file") or die "$file: $!";
	my @text = <IN>;
	close(IN);

	if(join("",@text) =~ /Licensed under the Apache License/gs) 
	{
		print "$file: License already stated. File ignored\n";
		next;
	}

	open(OUT,">$file") or die "$file: $!";

	if($c->{after})
	{
		my @x;
		my $re = $c->{after};
		loop: while(@text)
		{
			if($text[0] =~ m/$re/)
			{
				print OUT @x, shift @text;
				@x = ();
				last loop;
			}
			push @x,shift @text;
		}
		@text = (@x,@text);
	}

	print OUT $c->{start};
	foreach my $line ( split("\n",$LICENSE) )
	{
		print OUT $c->{comment}, $line,"\n";
	}
	print OUT $c->{end};

	print OUT @text;
	close(OUT) or die "$file: $!";

}


