#!/bin/sh
#trap "echo Booh!" SIGINT SIGTERM

TEST_HOME=.

#################################
## build the absolute path
#################################
D=`dirname "$TEST_HOME"`
B=`basename "$TEST_HOME"`
TEST_HOME="`cd \"$D\" 2>/dev/null && pwd || echo \"$D\"`/$B"

# create reference data
# dir where to write the eps files
REF_DIR=$TEST_HOME/reference-data
export REF_DIR
TST_DIR=$TEST_HOME/test-data
export TST_DIR

TST=test-1

echo "Test dir = $REF_DIR/$TST"
echo ""

for file in `ls $REF_DIR/$TST/*.eps`; do
  baseName=`basename $file`
  #echo "got reference $basename in REF_DIR. look for test the same file in TST_DIR"
  if [ -f $TST_DIR/$TST/$baseName ]; then
    diff $file $TST_DIR/$TST/$baseName
	res="$?"
	if [ $res -ne 0 ]; then
	 echo "The two files differs. See logs. Err = $res"
	 echo ""
	 exit $res
	fi

    echo "The two files $baseName in the reference and test dir are identical"

  else
    echo "Could not find $baseName in $TST_DIR/$TST. There is something fishy, please investigate"
	exit 10;
  fi
done

TST=test-2
echo ""
echo "Test dir = $REF_DIR/$TST"
echo ""

for file in `ls $REF_DIR/$TST/*.eps`; do
  baseName=`basename $file`
  #echo "got reference $basename in REF_DIR. look for test the same file in TST_DIR"
  if [ -f $TST_DIR/$TST/$baseName ]; then
    diff $file $TST_DIR/$TST/$baseName
	res="$?"
	if [ $res -ne 0 ]; then
	 echo "The two files differs. See logs. Err = $res"
	 echo ""
	 exit $res
	fi

    echo "The two files $baseName in the reference and test dir are identical"

  else
    echo "Could not find $baseName in $TST_DIR/$TST. There is something fishy, please investigate"
	exit 10;
  fi
done

exit
