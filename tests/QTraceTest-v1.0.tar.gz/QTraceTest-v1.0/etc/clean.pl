#!/usr/bin/perl -w

use strict;

# list directory content
my $dir = "$ENV{EPS_DIR_TOCLEAN}";
#my $dir = "/home/smd/aubert/QTraceTest/test-data/test-1";

my @not_sorted = <$dir/*.eps>;

my @sorted = sort { lc($a) cmp lc($b) } @not_sorted;

my $arrsize = @sorted;

if ($arrsize <=0)
{
 printf "No eps files found into %s\n",$dir;
 exit 1;
}

foreach my $file (@sorted)
{
  open DATA, "$file" or die "can't open $file $!";
  #print "File = $file\n";
  my $wFilename="$file".'.new';
  #print "New filename $wFilename\n";
  open(OUT,">$wFilename") or die "can't open $wFilename $!";
  foreach my $line (<DATA>) 
  {
     # any action here will be applied to each line of the file.
     next if ($line =~ m/%%CreationDate:/ ); 
	 
	 print OUT $line;
  }
  close (DATA);
  close (OUT);

  # move files
  my $mvcommand ="mv $wFilename $file";

  system($mvcommand);

  if ( $? != 0)
  {
    print "mv command failed: $!\n";
     exit 1;
  }
} 


