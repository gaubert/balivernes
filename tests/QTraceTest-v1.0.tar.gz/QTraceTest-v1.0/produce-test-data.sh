#!/bin/sh
#trap "echo Booh!" SIGINT SIGTERM
#set -x

TEST_HOME=.

#################################
## build the absolute path
#################################
D=`dirname "$TEST_HOME"`
B=`basename "$TEST_HOME"`
TEST_HOME="`cd \"$D\" 2>/dev/null && pwd || echo \"$D\"`/$B"

# create reference data
# dir where to write the eps files
EPS_DIR="$TEST_HOME/test-data"
export EPS_DIR

echo "delete test data"
rm -Rf $TEST_HOME/test-data

mkdir -p $EPS_DIR/test-1
mkdir -p $EPS_DIR/test-2

echo "Create reference data for test 1"

QTrace par=$TEST_HOME/etc/par-files/test-1.par orid_where_clause="time between 1137542400.0 and 1137556800.000" database=segment/segment_dev@idcdev

res="$?"

if [ $res -ne 0 ]; then
 echo "QTrace failed. Err = $res"
 exit $res
fi

echo "reference dataset 1 created"

echo "Create reference data for test 2"

# test
QTrace par=$TEST_HOME/etc/par-files/test-2.par orid_where_clause="time between 1205352000.000 and 1205366400.000"

res="$?"
if [ $res -ne 0 ]; then

 echo "QTrace failed. Err = $res"
 exit $res
fi

echo "reference dataset 2 created"

echo "clean files"

EPS_DIR_TOCLEAN=$EPS_DIR/test-1
export EPS_DIR_TOCLEAN

$TEST_HOME/etc/clean.pl

EPS_DIR_TOCLEAN=$EPS_DIR/test-2
export EPS_DIR_TOCLEAN

$TEST_HOME/etc/clean.pl
exit
